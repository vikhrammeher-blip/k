import { Router, type IRouter } from "express";
import healthRouter from "./health.js";
import ticketsRouter from "./tickets.js";
import authRouter from "./auth.js";
import settingsRouter from "./settings.js";
import rewardsRouter from "./rewards.js";

const router: IRouter = Router();

router.use(healthRouter);
router.use("/auth", authRouter);
router.use(ticketsRouter);
router.use("/settings", settingsRouter);
router.use("/rewards", rewardsRouter);

export default router;
