import { promises as fs } from 'fs';
import path from 'path';
import { logger } from '../lib/logger.js';

interface UserCreditRecord {
  balance: number;
  /** epoch ms of the last successful /credits daily claim */
  lastDailyAt?: number;
  /** epoch ms of the last message that earned passive credits (for cooldown) */
  lastMessageEarnAt?: number;
}

type GuildCredits = Record<string, UserCreditRecord>; // userId -> record

// Persisted to disk so balances survive bot restarts, same pattern as
// guildConfigs.json — mount a persistent volume at DATA_DIR on hosts with an
// ephemeral filesystem (e.g. Railway without a volume) or this resets on redeploy.
const DATA_DIR  = process.env['DATA_DIR'] ?? path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'chatCredits.json');

let store: Record<string, GuildCredits> = {}; // guildId -> GuildCredits
let loaded = false;
let saveQueue: Promise<void> = Promise.resolve();

async function load(): Promise<void> {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    store = JSON.parse(raw);
    logger.info({ guilds: Object.keys(store).length, dataFile: DATA_FILE }, 'Loaded chat credit balances from disk');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    if (code === 'ENOENT') {
      logger.info({ dataFile: DATA_FILE }, 'No existing chat credits file found — starting fresh (this is expected on first run)');
    } else {
      logger.warn({ err, dataFile: DATA_FILE }, 'Failed to read chat credits file — starting fresh');
    }
    store = {};
  }
}

function persist(): void {
  saveQueue = saveQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.writeFile(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
    })
    .catch((err) => logger.error({ err, dataFile: DATA_FILE }, 'Failed to persist chat credits'));
}

/** Must be awaited once before the bot starts handling events. */
export async function initChatCreditsStore(): Promise<void> {
  await load();
}

function getRecord(guildId: string, userId: string): UserCreditRecord {
  const guild = store[guildId] ?? (store[guildId] = {});
  return guild[userId] ?? (guild[userId] = { balance: 0 });
}

export function getBalance(guildId: string, userId: string): number {
  return store[guildId]?.[userId]?.balance ?? 0;
}

export function addCredits(guildId: string, userId: string, amount: number): number {
  const rec = getRecord(guildId, userId);
  rec.balance = Math.max(0, rec.balance + amount);
  persist();
  return rec.balance;
}

export function removeCredits(guildId: string, userId: string, amount: number): { ok: boolean; balance: number } {
  const rec = getRecord(guildId, userId);
  if (rec.balance < amount) return { ok: false, balance: rec.balance };
  rec.balance -= amount;
  persist();
  return { ok: true, balance: rec.balance };
}

export interface DailyClaimResult {
  ok: boolean;
  amount: number;
  balance: number;
  /** Only set when ok is false — how long until the next claim is available */
  msRemaining?: number;
}

const DAY_MS = 24 * 60 * 60 * 1000;

export function claimDaily(guildId: string, userId: string, amount: number): DailyClaimResult {
  const rec = getRecord(guildId, userId);
  const now = Date.now();
  if (rec.lastDailyAt && now - rec.lastDailyAt < DAY_MS) {
    return { ok: false, amount: 0, balance: rec.balance, msRemaining: DAY_MS - (now - rec.lastDailyAt) };
  }
  rec.lastDailyAt = now;
  rec.balance += amount;
  persist();
  return { ok: true, amount, balance: rec.balance };
}

// ── Activity tracking (for /flurry — "everyone active recently") ────────────
// Kept in memory only, separate from the persisted balance store: this is
// short-lived presence data, not something that needs to survive a restart,
// and tracking it wouldn't be worth writing to disk on every single message.
const lastActive: Record<string, Record<string, number>> = {}; // guildId -> userId -> epoch ms

/** Call on every human message so /flurry knows who's "active". Not cooldown-gated. */
export function recordActivity(guildId: string, userId: string): void {
  const guild = lastActive[guildId] ?? (lastActive[guildId] = {});
  guild[userId] = Date.now();
}

/** Returns userIds seen in the guild within the last `windowMs` milliseconds. */
export function getActiveUserIds(guildId: string, windowMs: number): string[] {
  const guild = lastActive[guildId];
  if (!guild) return [];
  const cutoff = Date.now() - windowMs;
  return Object.entries(guild)
    .filter(([, ts]) => ts >= cutoff)
    .map(([userId]) => userId);
}

/**
 * Awards a random amount of credits (between min and max, inclusive) for a
 * qualifying message, respecting the per-member cooldown. Returns the amount
 * credited — 0 if the member is still on cooldown, so callers can skip
 * sending any feedback for the common case.
 */
export function recordMessageEarn(
  guildId: string,
  userId: string,
  min: number,
  max: number,
  cooldownSeconds: number,
): number {
  const rec = getRecord(guildId, userId);
  const now = Date.now();
  if (rec.lastMessageEarnAt && now - rec.lastMessageEarnAt < cooldownSeconds * 1000) return 0;

  rec.lastMessageEarnAt = now;
  const lo = Math.min(min, max);
  const hi = Math.max(min, max);
  const amount = Math.floor(Math.random() * (hi - lo + 1)) + lo;
  if (amount > 0) rec.balance += amount;
  persist();
  return amount;
}
