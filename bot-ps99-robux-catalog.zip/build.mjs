import { createRequire } from "node:module";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { build as esbuild } from "esbuild";
import esbuildPluginPino from "esbuild-plugin-pino";
import { rm, cp } from "node:fs/promises";

globalThis.require = createRequire(import.meta.url);

const rootDir = path.dirname(fileURLToPath(import.meta.url));
const distDir = path.resolve(rootDir, "dist");

async function buildAll() {
  await rm(distDir, { recursive: true, force: true });

  await esbuild({
    entryPoints: [path.resolve(rootDir, "src/index.ts")],
    platform: "node",
    bundle: true,
    format: "esm",
    outdir: distDir,
    outExtension: { ".js": ".mjs" },
    logLevel: "info",
    external: [
      "*.node",
      "bufferutil",
      "utf-8-validate",
      "sharp",
      "canvas",
      "fsevents",
      "pg-native",
    ],
    sourcemap: "linked",
    plugins: [
      esbuildPluginPino({ transports: ["pino-pretty"] }),
    ],
    banner: {
      js: `import { createRequire as __crReq } from 'node:module';
import __path from 'node:path';
import __url from 'node:url';
globalThis.require = __crReq(import.meta.url);
globalThis.__filename = __url.fileURLToPath(import.meta.url);
globalThis.__dirname = __path.dirname(globalThis.__filename);
`,
    },
  });

  // Copy the dashboard's static assets alongside the bundle so
  // express.static(path.join(__dirname, "public")) finds them at runtime.
  const publicSrc = path.resolve(rootDir, "public");
  const publicDest = path.resolve(distDir, "public");
  await cp(publicSrc, publicDest, { recursive: true });

  console.log("✅ Build complete → dist/index.mjs");
  console.log("✅ Dashboard assets → dist/public");
}

buildAll().catch((err) => {
  console.error(err);
  process.exit(1);
});
