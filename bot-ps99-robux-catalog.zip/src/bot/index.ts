import {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
} from 'discord.js';
import { handleInteraction } from './handlers/interactions.js';
import { handleMessage } from './handlers/messages.js';
import { postAllRestockPanels, handleRestockPanelDelete } from './restockPanel.js';
import { postAllTicketPanels, handleTicketPanelDelete } from './panel.js';
import { buildSetupCommand } from './setupCommand.js';
import { buildCustomCommandCommand } from './customCommand.js';
import { buildAdminNukeCommand } from './adminNuke.js';
import { buildActivateCommand } from './activateCommand.js';
import { buildCreditsCommand } from './creditsCommand.js';
import { buildNukeCommand } from './nukeCommand.js';
import { buildFlurryCommand } from './flurryCommand.js';
import { buildShopCommand } from './shopCommand.js';
import { initConfigStore } from './config.js';
import { initChatCreditsStore } from './chatCredits.js';
import { initShopStore } from './shop.js';
import { initRewardsStore } from './data/rewards.js';
import { initInviteGamesStore } from './data/inviteGames.js';
import { logger } from '../lib/logger.js';

let botClient: Client | null = null;

export function getBotClient(): Client | null {
  return botClient;
}

export function buildCommands() {
  return [
    new SlashCommandBuilder()
      .setName('panel')
      .setDescription('Post the ticket selection panel in this channel')
      .setDefaultMemberPermissions('0') // Admins only
      .toJSON(),
    buildSetupCommand(),
    buildCustomCommandCommand(),
    buildAdminNukeCommand(),
    buildActivateCommand(),
    buildCreditsCommand(),
    buildNukeCommand(),
    buildFlurryCommand(),
    buildShopCommand(),
  ];
}

export async function startBot(): Promise<void> {
  const token = process.env['DISCORD_BOT_TOKEN'];

  if (!token) {
    logger.warn('DISCORD_BOT_TOKEN not set — Discord bot will not start');
    return;
  }

  await initConfigStore();
  await initChatCreditsStore();
  await initShopStore();
  await initRewardsStore();
  await initInviteGamesStore();

  const client = new Client({
    intents: [
      GatewayIntentBits.Guilds,
      GatewayIntentBits.GuildMessages,
      GatewayIntentBits.MessageContent,
      GatewayIntentBits.GuildMembers,
    ],
    partials: [Partials.Channel, Partials.Message],
  });

  const rest = new REST().setToken(token);
  const commands = buildCommands();

  client.once('clientReady', async (c) => {
    logger.info({ tag: c.user.tag }, 'Discord bot is online');

    // Register commands globally so the bot works out of the box in any server
    // it's invited to — no per-server code changes needed anymore.
    try {
      await rest.put(Routes.applicationCommands(c.application.id), { body: commands });
      logger.info('Global slash commands registered (/panel, /setup, /customcommand, /adminnuke, /activate, /credits, /nuke, /flurry, /shop)');
    } catch (err) {
      logger.error({ err }, 'Failed to register global slash commands');
    }

    // Clear any leftover per-guild command registrations from previous
    // versions of the bot. Having the same command registered both globally
    // AND per-guild makes Discord show it TWICE in the command picker — this
    // wipes the guild-scoped copies so only the single global command shows.
    for (const guild of c.guilds.cache.values()) {
      try {
        await rest.put(Routes.applicationGuildCommands(c.application.id, guild.id), { body: [] });
      } catch (err) {
        logger.error({ err, guildId: guild.id }, 'Failed to clear guild-scoped slash commands');
      }
    }

    // Post the restock panel in every server that already has one configured
    await postAllRestockPanels(c);

    // Re-post the ticket panel in every server that's run /panel before —
    // this is what makes it "come back" automatically after a redeploy.
    await postAllTicketPanels(c);
  });

  // Clear any guild-scoped commands Discord may auto-create when the bot
  // joins a new server, so only the global commands show (see note above).
  client.on('guildCreate', async (guild) => {
    try {
      await rest.put(Routes.applicationGuildCommands(client.application!.id, guild.id), { body: [] });
    } catch (err) {
      logger.error({ err, guildId: guild.id }, 'Failed to clear guild-scoped slash commands for new guild');
    }
  });

  client.on('interactionCreate', (interaction) => {
    handleInteraction(interaction).catch((err) =>
      logger.error({ err }, 'Unhandled interaction error'),
    );
  });

  client.on('messageCreate', (message) => {
    handleMessage(message).catch((err) =>
      logger.error({ err }, 'Unhandled message error'),
    );
  });

  // Auto-repost a guild's restock panel if it gets deleted
  client.on('messageDelete', (message) => {
    if (!message.guildId) return;
    handleRestockPanelDelete(client, message.guildId, message.id).catch((err) =>
      logger.error({ err }, 'Error handling restock panel deletion'),
    );
    handleTicketPanelDelete(client, message.guildId, message.id).catch((err) =>
      logger.error({ err }, 'Error handling ticket panel deletion'),
    );
  });

  client.on('error', (err) => logger.error({ err }, 'Discord client error'));

  await client.login(token);
  botClient = client;
}
