import {
  type ChatInputCommandInteraction,
  SlashCommandBuilder,
  PermissionFlagsBits,
} from 'discord.js';
import { getGuildConfig, setCustomCommand, removeCustomCommand } from './config.js';
import { buildEmbed, COLORS } from './utils/embeds.js';

const TRIGGER_PATTERN = /^[a-z0-9_-]{1,32}$/i;
const RESERVED_TRIGGERS = new Set(['close', 'claim', 'unclaim', 'unlock', 'setinvites']);

export function buildCustomCommandCommand() {
  return new SlashCommandBuilder()
    .setName('customcommand')
    .setDescription('Manage custom !commands (e.g. !killer)')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand((sub) =>
      sub
        .setName('add')
        .setDescription('Add or update a custom !command')
        .addStringOption((opt) =>
          opt
            .setName('trigger')
            .setDescription('Word that triggers it, without "!" (e.g. "killer" for !killer)')
            .setRequired(true),
        )
        .addUserOption((opt) =>
          opt.setName('user').setDescription('User to mention').setRequired(true),
        )
        .addStringOption((opt) =>
          opt
            .setName('text')
            .setDescription('Message text. Use {user} for the mention (e.g. "{user} is god")')
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('remove')
        .setDescription('Remove a custom !command')
        .addStringOption((opt) =>
          opt.setName('trigger').setDescription('Trigger word to remove').setRequired(true),
        ),
    )
    .addSubcommand((sub) => sub.setName('list').setDescription('List all custom commands'))
    .toJSON();
}

export async function handleCustomCommandCommand(
  interaction: ChatInputCommandInteraction,
): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const sub = interaction.options.getSubcommand();

  if (sub === 'add') {
    const rawTrigger = interaction.options.getString('trigger', true).trim().replace(/^!/, '');
    const user        = interaction.options.getUser('user', true);
    const text         = interaction.options.getString('text', true);

    if (!TRIGGER_PATTERN.test(rawTrigger)) {
      await interaction.reply({
        content: '❌ Trigger must be 1-32 characters, letters/numbers/underscores/hyphens only (no spaces or "!").',
        ephemeral: true,
      });
      return;
    }

    if (RESERVED_TRIGGERS.has(rawTrigger.toLowerCase())) {
      await interaction.reply({
        content: `❌ \`!${rawTrigger.toLowerCase()}\` is a reserved bot command and can't be overridden.`,
        ephemeral: true,
      });
      return;
    }

    const template = text.includes('{user}') ? text : `{user} ${text}`;
    setCustomCommand(guildId, rawTrigger, user.id, template);

    const preview = template.replace('{user}', `<@${user.id}>`);
    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '✅ Custom Command Added',
          description: [
            `**Trigger:** \`!${rawTrigger.toLowerCase()}\``,
            `**Preview:** ${preview}`,
          ].join('\n'),
          color: COLORS.success,
        }),
      ],
      ephemeral: true,
    });
    return;
  }

  if (sub === 'remove') {
    const rawTrigger = interaction.options.getString('trigger', true).trim().replace(/^!/, '').toLowerCase();
    const removed = removeCustomCommand(guildId, rawTrigger);
    await interaction.reply({
      content: removed
        ? `✅ Removed custom command \`!${rawTrigger}\`.`
        : `❌ No custom command found for \`!${rawTrigger}\`.`,
      ephemeral: true,
    });
    return;
  }

  if (sub === 'list') {
    const cfg = getGuildConfig(guildId);
    const entries = Object.entries(cfg.customCommands ?? {});

    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '📜 Custom Commands',
          description:
            entries.length === 0
              ? '*No custom commands set. Use `/customcommand add` to create one.*'
              : entries
                  .map(([trigger, cmd]) => `\`!${trigger}\` → ${cmd.template.replace('{user}', `<@${cmd.targetUserId}>`)}`)
                  .join('\n'),
          color: COLORS.neutral,
        }),
      ],
      ephemeral: true,
    });
    return;
  }
}
