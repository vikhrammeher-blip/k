import {
  type Client,
  type TextChannel,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { getGuildConfig, getChatRewardsConfig, updateGuildConfig } from './config.js';
import { logger } from '../lib/logger.js';

/** Tracks the current ticket panel message ID per guild so we can detect deletion. */
const panelMessageIds = new Map<string, string>();

function buildTicketPanel(guildId: string) {
  const chatRewardsEnabled = getChatRewardsConfig(guildId).enabled;

  const descLines = [
    'Welcome! Please select the type of ticket you need below.',
    '',
    '**🎟️ Invite Rewards** — Claim rewards for inviting members',
    '**🎉 Giveaway Winner** — Claim your giveaway prize',
    '**💬 Chat Rewards** — Claim your chat activity rewards',
    '**📦 Chest Rewards** — Claim your chest rewards',
    '**🗣️ Yapper Rewards** — Claim your yapper rewards',
    '**🛠️ General Support** — Get help from our staff team',
  ];
  if (chatRewardsEnabled) {
    descLines.push('**💳 Chat Credits** — Redeem your chat rewards credits');
  }

  const embed = buildEmbed({
    title: '🎫 Support Tickets',
    description: descLines.join('\n'),
    color: COLORS.primary,
    footer: 'Please only open one ticket at a time',
  });

  const row1 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('create_ticket_invite')
      .setLabel('Invite Rewards')
      .setEmoji('🎟️')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('create_ticket_giveaway')
      .setLabel('Giveaway Winner')
      .setEmoji('🎉')
      .setStyle(ButtonStyle.Success),
    new ButtonBuilder()
      .setCustomId('create_ticket_chat')
      .setLabel('Chat Rewards')
      .setEmoji('💬')
      .setStyle(ButtonStyle.Secondary),
  );

  const row2 = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('create_ticket_chest')
      .setLabel('Chest Rewards')
      .setEmoji('📦')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('create_ticket_yapper')
      .setLabel('Yapper Rewards')
      .setEmoji('🗣️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('create_ticket_support')
      .setLabel('General Support')
      .setEmoji('🛠️')
      .setStyle(ButtonStyle.Danger),
  );

  // Chat Credits redeem ticket only makes sense once the chat rewards system
  // is actually turned on (/activate enable) — otherwise members would open
  // a ticket to redeem credits that don't exist yet.
  const components = chatRewardsEnabled
    ? [row1, row2, new ActionRowBuilder<ButtonBuilder>().addComponents(
        new ButtonBuilder()
          .setCustomId('create_ticket_credit_redeem')
          .setLabel('Chat Credits')
          .setEmoji('💳')
          .setStyle(ButtonStyle.Secondary),
      )]
    : [row1, row2];

  return { embeds: [embed], components };
}

/**
 * Posts the ticket panel to a channel via /panel, and remembers that channel
 * so it's auto-reposted there on every future bot restart/redeploy — see
 * postAllTicketPanels, called once from the 'clientReady' handler.
 */
export async function sendTicketPanel(channel: TextChannel): Promise<void> {
  const msg = await channel.send(buildTicketPanel(channel.guild.id));
  panelMessageIds.set(channel.guild.id, msg.id);
  updateGuildConfig(channel.guild.id, { panelChannelId: channel.id });
  logger.info({ guildId: channel.guild.id, channelId: channel.id, messageId: msg.id }, 'Ticket panel posted and remembered for auto-repost');
}

/** Posts (or re-uses) the ticket panel for a single guild. No-op if /panel has never been run there. */
export async function postTicketPanel(client: Client, guildId: string): Promise<void> {
  const channelId = getGuildConfig(guildId).panelChannelId;
  if (!channelId) return; // /panel has never been run in this server yet

  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (!channel || !channel.isTextBased()) {
      logger.warn({ guildId, channelId }, 'Ticket panel channel not found or not a text channel');
      return;
    }

    // Check recent messages for an existing panel — scan up to 50 so we catch it
    // even if the channel has activity since the last bot restart.
    const recent = await channel.messages.fetch({ limit: 50 });
    const botPanels = recent.filter(
      m => m.author.id === client.user!.id && m.components.length > 0,
    );
    if (botPanels.size > 0) {
      // Keep the newest one, delete any extras so we never have duplicate panels.
      const sorted = [...botPanels.values()].sort(
        (a, b) => b.createdTimestamp - a.createdTimestamp,
      );
      panelMessageIds.set(guildId, sorted[0]!.id);
      logger.info({ guildId, messageId: sorted[0]!.id }, 'Ticket panel already present — tracking existing message');
      for (const extra of sorted.slice(1)) {
        await extra.delete().catch(() => {});
        logger.info({ guildId, messageId: extra.id }, 'Deleted duplicate ticket panel');
      }
      return;
    }

    const msg = await channel.send(buildTicketPanel(guildId));
    panelMessageIds.set(guildId, msg.id);
    logger.info({ guildId, messageId: msg.id }, 'Ticket panel auto-reposted after bot restart');
  } catch (err) {
    logger.error({ guildId, err }, 'Failed to auto-repost ticket panel');
  }
}

/** Posts the ticket panel for every guild that has run /panel before. Call once on startup. */
export async function postAllTicketPanels(client: Client): Promise<void> {
  for (const guild of client.guilds.cache.values()) {
    await postTicketPanel(client, guild.id);
  }
}

/**
 * Call this from the messageDelete event handler.
 * If the deleted message was a tracked ticket panel, re-post it automatically.
 */
export async function handleTicketPanelDelete(
  client: Client,
  guildId: string,
  deletedMessageId: string,
): Promise<void> {
  if (panelMessageIds.get(guildId) !== deletedMessageId) return;

  logger.info({ guildId, deletedMessageId }, 'Ticket panel was deleted — re-posting automatically');
  panelMessageIds.delete(guildId); // clear before re-posting so we don't double-track

  const channelId = getGuildConfig(guildId).panelChannelId;
  if (!channelId) return;

  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (!channel || !channel.isTextBased()) return;

    const msg = await channel.send(buildTicketPanel(guildId));
    panelMessageIds.set(guildId, msg.id);
    logger.info({ guildId, messageId: msg.id }, 'Ticket panel re-posted after deletion');
  } catch (err) {
    logger.error({ guildId, err }, 'Failed to re-post ticket panel after deletion');
  }
}
