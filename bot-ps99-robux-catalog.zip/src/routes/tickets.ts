import { Router, type NextFunction, type Request, type Response } from "express";
import { ticketStates } from "../bot/state.js";
import { getBotClient, buildCommands } from "../bot/index.js";
import { isOwner } from "../lib/owner.js";

const router = Router();

// Every route below requires a logged-in Discord admin session (see
// routes/auth.ts) — ticket data includes real usernames and IDs.
function requireSession(req: Request, res: Response, next: NextFunction): void {
  if (req.dashboardSession) {
    next();
    return;
  }
  res.status(401).json({ error: "unauthorized", loginUrl: "/api/auth/login" });
}
router.use(requireSession);

router.get("/tickets", (_req, res) => {
  const tickets = Array.from(ticketStates.entries()).map(([channelId, state]) => ({
    channelId,
    ticketType: state.ticketType,
    ownerUsername: state.ownerUsername,
    ownerId: state.ownerId,
    phase:
      state.invitePhase ??
      (state.ticketType === "general-support" ? "open" : "awaiting_screenshot"),
    selectedReward: state.selectedReward ?? null,
    verifiedInvites: state.autoDetectedInvites ?? null,
    createdAt: state.createdAt.toISOString(),
  }));
  res.json(tickets);
});

router.get("/bot-status", (req, res) => {
  const client = getBotClient();
  const owner = isOwner(req.dashboardSession?.userId);
  const allGuilds = client
    ? [...client.guilds.cache.values()].map((g) => ({
        id: g.id,
        name: g.name,
        memberCount: g.memberCount ?? null,
        iconUrl: g.iconURL({ size: 64 }) ?? null,
        ownerId: g.ownerId ?? null,
        joinedAt: g.joinedAt ? g.joinedAt.toISOString() : null,
      }))
    : [];
  res.json({
    online: client !== null && client.isReady(),
    ticketCount: ticketStates.size,
    // Aggregate count is always visible (other panels rely on it), but the
    // actual list of servers — which would reveal who administers what,
    // and thus this account's identity — is owner-only. See routes/auth.ts.
    guildCount: allGuilds.length,
    guildIds: owner ? allGuilds.map((g) => g.id) : [],
    guilds: owner ? allGuilds : [],
    uptime: client?.uptime ?? null,
  });
});

// The bot's full registered slash-command catalog, straight from the same
// builder used to register them with Discord — always matches what's
// actually live, no risk of the dashboard listing stale/renamed commands.
// Owner-only: not itself sensitive, but grouped with the servers panel as
// a single "bot info" view that other server admins shouldn't see.
router.get("/bot-commands", (req, res) => {
  if (!isOwner(req.dashboardSession?.userId)) {
    res.status(403).json({ error: "Only the bot owner can view this." });
    return;
  }
  res.json({ commands: buildCommands() });
});

router.get("/stats", (_req, res) => {
  const tickets = Array.from(ticketStates.values());

  const byType: Record<string, number> = {};
  const byPhase: Record<string, number> = {};

  for (const t of tickets) {
    byType[t.ticketType] = (byType[t.ticketType] ?? 0) + 1;
    const phase =
      t.invitePhase ??
      (t.ticketType === "general-support" ? "open" : "awaiting_screenshot");
    byPhase[phase] = (byPhase[phase] ?? 0) + 1;
  }

  res.json({
    total: tickets.length,
    byType,
    byPhase,
    claimedCount: tickets.filter((t) => t.claimedBy).length,
    unclaimedCount: tickets.filter((t) => !t.claimedBy).length,
  });
});

export default router;
