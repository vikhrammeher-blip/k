import app from "./app.js";
import { logger } from "./lib/logger.js";
import { startBot } from "./bot/index.js";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Express 5: listen callback receives no error argument
app.listen(port, () => {
  logger.info({ port }, "Server listening");
});

// Start the Discord bot (logs a warning and skips if token is not set)
startBot().catch((err: unknown) => logger.error({ err }, "Discord bot startup error"));
