import {
  type ChatInputCommandInteraction,
  type GuildMember,
  type TextChannel,
  SlashCommandBuilder,
} from 'discord.js';
import { getGuildConfig, getChatRewardsConfig } from './config.js';
import { addCredits, getActiveUserIds } from './chatCredits.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { logChatRewardsEvent } from './utils/ticketLog.js';

function isChatRewardsStaff(member: GuildMember): boolean {
  const guildCfg   = getGuildConfig(member.guild.id);
  const rewardsCfg = getChatRewardsConfig(member.guild.id);
  return (
    (!!guildCfg.staffRoleId && member.roles.cache.has(guildCfg.staffRoleId)) ||
    (!!rewardsCfg.staffRoleId && member.roles.cache.has(rewardsCfg.staffRoleId)) ||
    member.permissions.has('Administrator')
  );
}

export function buildFlurryCommand() {
  return new SlashCommandBuilder()
    .setName('flurry')
    .setDescription('Trigger a bonus credit flurry for everyone currently active in chat (Staff only)')
    .setDMPermission(false)
    .addIntegerOption((opt) =>
      opt.setName('amount').setDescription('Bonus credits to give each active member').setRequired(true).setMinValue(1),
    )
    .addIntegerOption((opt) =>
      opt
        .setName('minutes')
        .setDescription('How recently a member must have chatted to count as active (default 15)')
        .setRequired(false)
        .setMinValue(1)
        .setMaxValue(180),
    )
    .toJSON();
}

export async function handleFlurryCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId || !interaction.guild) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const member = interaction.member as GuildMember;
  if (!isChatRewardsStaff(member)) {
    await interaction.reply({ content: '❌ Only Chat Rewards staff can trigger a flurry.', ephemeral: true });
    return;
  }

  const rewardsCfg = getChatRewardsConfig(guildId);
  if (!rewardsCfg.enabled) {
    await interaction.reply({
      content: '❌ Chat rewards isn\'t enabled on this server yet. Ask an admin to run `/activate enable` first.',
      ephemeral: true,
    });
    return;
  }

  const amount  = interaction.options.getInteger('amount', true);
  const minutes = interaction.options.getInteger('minutes') ?? 15;

  await interaction.deferReply();

  const activeUserIds = getActiveUserIds(guildId, minutes * 60 * 1000)
    // Don't hand out credits to the bot itself if it somehow ended up tracked.
    .filter((id) => id !== interaction.client.user?.id);

  if (activeUserIds.length === 0) {
    await interaction.editReply({
      content: `❌ No members have chatted in the last **${minutes} minutes** — nothing to flurry.`,
    });
    return;
  }

  for (const userId of activeUserIds) {
    addCredits(guildId, userId, amount);
  }

  const total = amount * activeUserIds.length;

  await interaction.editReply({
    embeds: [
      buildEmbed({
        title: '❄️ Credit Flurry!',
        description: [
          `**${activeUserIds.length}** member${activeUserIds.length !== 1 ? 's' : ''} active in the last **${minutes} minutes** just received **${amount}** bonus credits each!`,
          '',
          `Triggered by <@${interaction.user.id}>.`,
        ].join('\n'),
        color: COLORS.info,
        footer: `Total distributed: ${total} credits`,
      }),
    ],
  });

  // Ping the channel so it feels like an event, without spamming everyone individually.
  const channel = interaction.channel as TextChannel | null;
  await channel?.send({
    content: `❄️ **A credit flurry just hit!** Everyone active in the last ${minutes} minutes got **${amount}** bonus credits. Check your balance with \`/credits balance\`.`,
    allowedMentions: { parse: [] },
  }).catch(() => {});

  await logChatRewardsEvent(
    interaction.client,
    guildId,
    `❄️ <@${interaction.user.id}> triggered a flurry: **${amount}** credits to **${activeUserIds.length}** active members (**${total}** total).`,
  );
}
