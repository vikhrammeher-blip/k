import {
  type Guild,
  type GuildMember,
  type TextChannel,
  ChannelType,
  PermissionFlagsBits,
} from 'discord.js';
import type { TicketType } from '../state.js';

const CHANNEL_PREFIX: Record<TicketType, string> = {
  'invite-rewards':  'invite',
  'giveaway':        'giveaway',
  'chat-rewards':    'chat',
  'chest-rewards':   'chest',
  'yapper-rewards':  'yapper',
  'general-support': 'support',
  'restock':         'restock',
  'credit-redeem':   'credits',
};

const STAFF_PERMS = [
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.SendMessages,
  PermissionFlagsBits.AttachFiles,
  PermissionFlagsBits.EmbedLinks,
  PermissionFlagsBits.ReadMessageHistory,
  PermissionFlagsBits.ManageMessages,
  PermissionFlagsBits.ManageChannels,
];

const MEMBER_PERMS = [
  PermissionFlagsBits.ViewChannel,
  PermissionFlagsBits.SendMessages,
  PermissionFlagsBits.AttachFiles,
  PermissionFlagsBits.EmbedLinks,
  PermissionFlagsBits.ReadMessageHistory,
];

export async function createTicketChannel(opts: {
  guild: Guild;
  member: GuildMember;
  ticketType: TicketType;
  staffRoleId: string;
  categoryId?: string;
  extraRoleId?: string;
}): Promise<TextChannel> {
  const { guild, member, ticketType, staffRoleId, categoryId, extraRoleId } = opts;
  const prefix = CHANNEL_PREFIX[ticketType];
  const safeName =
    member.user.username
      .toLowerCase()
      .replace(/[^a-z0-9]/g, '')
      .slice(0, 20) || 'user';

  const botId = guild.members.me?.id ?? guild.client.user.id;

  const overwrites: {
    id: string;
    allow?: bigint[];
    deny?: bigint[];
  }[] = [
    { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
    { id: member.id,   allow: MEMBER_PERMS },
    { id: staffRoleId, allow: STAFF_PERMS },
    // The bot's own user must always be explicitly allowed here — without this,
    // a bot that lacks server-wide Administrator inherits the @everyone deny
    // above and can no longer see or send messages in tickets it just created.
    { id: botId, allow: STAFF_PERMS },
  ];

  if (extraRoleId && extraRoleId !== staffRoleId) {
    overwrites.push({ id: extraRoleId, allow: STAFF_PERMS });
  }

  return (await guild.channels.create({
    name: `${prefix}-${safeName}`,
    type: ChannelType.GuildText,
    parent: categoryId,
    permissionOverwrites: overwrites,
    topic: `Ticket for ${member.user.tag} | Type: ${ticketType}`,
  })) as TextChannel;
}

export async function lockChannel(
  channel: TextChannel,
  memberId: string,
): Promise<void> {
  await channel.permissionOverwrites.edit(memberId, { SendMessages: false });
}

export async function unlockChannel(
  channel: TextChannel,
  memberId: string,
): Promise<void> {
  await channel.permissionOverwrites.edit(memberId, {
    SendMessages:       true,
    ViewChannel:        true,
    AttachFiles:        true,
    EmbedLinks:         true,
    ReadMessageHistory: true,
  });
}

export async function closeTicketChannel(
  channel: TextChannel,
  closedByTag: string,
): Promise<void> {
  await channel.send({
    embeds: [
      {
        description: `🔒 Ticket closed by **${closedByTag}**. Channel will be deleted in 5 seconds.`,
        color: 0xED4245,
      },
    ],
  });
  setTimeout(() => channel.delete('Ticket closed').catch(() => {}), 5_000);
}
