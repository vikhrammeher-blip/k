import { Router, type NextFunction, type Request, type Response } from "express";
import { ChannelType, PermissionFlagsBits } from "discord.js";
import { getBotClient } from "../bot/index.js";
import type { TicketType } from "../bot/state.js";
import {
  getGuildConfig,
  updateGuildConfig,
  setGuildCategory,
  setCustomCommand,
  removeCustomCommand,
  getChatRewardsConfig,
  updateChatRewardsConfig,
  addExcludedChannel,
  removeExcludedChannel,
  getMissingSetupItems,
  type ChatRewardsConfig,
} from "../bot/config.js";
import { listItems, upsertItem, editItem, removeItem, type ShopItem } from "../bot/shop.js";
import { postRestockPanel } from "../bot/restockPanel.js";
import { logger } from "../lib/logger.js";

const router = Router();

const TICKET_TYPES: TicketType[] = [
  "invite-rewards",
  "giveaway",
  "chat-rewards",
  "chest-rewards",
  "yapper-rewards",
  "general-support",
  "restock",
  "credit-redeem",
];

// Every route below requires a logged-in Discord admin session AND that the
// session's admin lists this exact guild (a user can be admin of servers the
// bot manages while not being allowed to touch every one of them).
function requireGuildAdmin(req: Request, res: Response, next: NextFunction): void {
  const session = req.dashboardSession;
  if (!session) {
    res.status(401).json({ error: "unauthorized", loginUrl: "/api/auth/login" });
    return;
  }
  const guildId = req.params["guildId"];
  const allowed = session.adminGuilds.some((g) => g.id === guildId);
  if (!allowed) {
    res.status(403).json({ error: "You aren't an admin on that server." });
    return;
  }
  next();
}
router.use("/:guildId", requireGuildAdmin);

router.get("/:guildId/overview", (req, res) => {
  const guildId = req.params["guildId"]!;
  const config = getGuildConfig(guildId);
  const chatRewards = getChatRewardsConfig(guildId);
  const missing = getMissingSetupItems(guildId);
  res.json({ config, chatRewards, missing, ticketTypes: TICKET_TYPES });
});

router.get("/:guildId/roles", (req, res) => {
  const guildId = req.params["guildId"]!;
  const client = getBotClient();
  const guild = client?.guilds.cache.get(guildId);
  if (!guild) {
    res.json({ roles: [] });
    return;
  }
  const roles = [...guild.roles.cache.values()]
    .filter((r) => r.id !== guild.roles.everyone.id && !r.managed)
    .sort((a, b) => b.position - a.position)
    .map((r) => ({ id: r.id, name: r.name, color: r.hexColor }));
  res.json({ roles });
});

router.get("/:guildId/channels", (req, res) => {
  const guildId = req.params["guildId"]!;
  const client = getBotClient();
  const guild = client?.guilds.cache.get(guildId);
  if (!guild) {
    res.json({ textChannels: [], categories: [] });
    return;
  }
  const all = [...guild.channels.cache.values()];
  const textChannels = all
    .filter((c) => c.type === ChannelType.GuildText)
    .map((c) => ({ id: c.id, name: c.name }));
  const categories = all
    .filter((c) => c.type === ChannelType.GuildCategory)
    .map((c) => ({ id: c.id, name: c.name }));
  res.json({ textChannels, categories });
});

// ── General setup ───────────────────────────────────────────────────────────

type SetupField =
  | "staffRoleId"
  | "giveawayHosterRoleId"
  | "restockPingRoleId"
  | "logChannelId"
  | "restockPanelChannelId";

const SETUP_FIELDS: SetupField[] = [
  "staffRoleId",
  "giveawayHosterRoleId",
  "restockPingRoleId",
  "logChannelId",
  "restockPanelChannelId",
];

router.put("/:guildId/setup", (req, res) => {
  const guildId = req.params["guildId"]!;
  const body = req.body as Partial<Record<SetupField, string>>;

  const patch: Partial<Record<SetupField, string>> = {};
  for (const key of SETUP_FIELDS) {
    const value = body[key];
    if (typeof value === "string" && value.trim()) patch[key] = value.trim();
  }

  const previousChannel = getGuildConfig(guildId).restockPanelChannelId;
  const config = updateGuildConfig(guildId, patch);

  // Mirror /setup restock-panel-channel: repost the panel when it changes.
  const client = getBotClient();
  if (
    client &&
    patch["restockPanelChannelId"] &&
    patch["restockPanelChannelId"] !== previousChannel
  ) {
    postRestockPanel(client, guildId).catch(() => {});
  }

  res.json({ config });
});

router.put("/:guildId/category", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { type, categoryId } = req.body as { type?: string; categoryId?: string };
  if (!type || !TICKET_TYPES.includes(type as TicketType) || !categoryId) {
    res.status(400).json({ error: "type and categoryId are required" });
    return;
  }
  const config = setGuildCategory(guildId, type as TicketType, categoryId);
  res.json({ config });
});

// Creates a brand new Discord category channel with its own permission
// overwrites (dashboard-only — deliberately not exposed as a slash command),
// optionally assigning it straight to a ticket type.
router.post("/:guildId/create-category", async (req, res) => {
  const guildId = req.params["guildId"]!;
  const { name, viewRoleId, private: isPrivate, type } = req.body as {
    name?: string;
    viewRoleId?: string;
    private?: boolean;
    type?: string;
  };

  if (!name?.trim()) {
    res.status(400).json({ error: "name is required" });
    return;
  }
  if (type && !TICKET_TYPES.includes(type as TicketType)) {
    res.status(400).json({ error: "invalid ticket type" });
    return;
  }

  const client = getBotClient();
  const guild = client?.guilds.cache.get(guildId);
  if (!client || !guild) {
    res.status(503).json({ error: "The bot isn't connected to this server right now." });
    return;
  }

  const hidePrivate = isPrivate ?? true;
  const cfg = getGuildConfig(guildId);
  const overwrites: { id: string; allow?: bigint[]; deny?: bigint[] }[] = [];

  if (hidePrivate) {
    overwrites.push({ id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] });
  }
  if (cfg.staffRoleId) {
    overwrites.push({
      id: cfg.staffRoleId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ManageChannels,
      ],
    });
  }
  if (viewRoleId && viewRoleId !== cfg.staffRoleId) {
    overwrites.push({
      id: viewRoleId,
      allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory],
    });
  }
  // The bot's own user must always be explicitly allowed — otherwise, if it lacks
  // server-wide Administrator, it inherits the @everyone deny above and can no
  // longer see or manage the category (or channels created under it) it just made.
  const botId = guild.members.me?.id ?? client.user?.id;
  if (botId) {
    overwrites.push({
      id: botId,
      allow: [
        PermissionFlagsBits.ViewChannel,
        PermissionFlagsBits.SendMessages,
        PermissionFlagsBits.ReadMessageHistory,
        PermissionFlagsBits.ManageMessages,
        PermissionFlagsBits.ManageChannels,
      ],
    });
  }

  let category;
  try {
    category = await guild.channels.create({
      name: name.trim(),
      type: ChannelType.GuildCategory,
      permissionOverwrites: overwrites,
    });
  } catch (err) {
    logger.error({ err, guildId }, "Failed to create ticket category from dashboard");
    res.status(502).json({
      error:
        "Failed to create the category. Make sure the bot's role has Manage Channels permission and sits above the roles you're granting access to.",
    });
    return;
  }

  let config = cfg;
  if (type) {
    config = setGuildCategory(guildId, type as TicketType, category.id);
  }

  res.json({ category: { id: category.id, name: category.name }, config });
});

// ── Custom commands ─────────────────────────────────────────────────────────

router.get("/:guildId/custom-commands", (req, res) => {
  const guildId = req.params["guildId"]!;
  res.json({ customCommands: getGuildConfig(guildId).customCommands });
});

router.post("/:guildId/custom-commands", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { trigger, targetUserId, template } = req.body as {
    trigger?: string;
    targetUserId?: string;
    template?: string;
  };
  if (!trigger?.trim() || !targetUserId?.trim() || !template?.trim()) {
    res.status(400).json({ error: "trigger, targetUserId, and template are required" });
    return;
  }
  const config = setCustomCommand(guildId, trigger.trim(), targetUserId.trim(), template.trim());
  res.json({ config });
});

router.delete("/:guildId/custom-commands/:trigger", (req, res) => {
  const guildId = req.params["guildId"]!;
  const trigger = req.params["trigger"]!;
  const removed = removeCustomCommand(guildId, trigger);
  if (!removed) {
    res.status(404).json({ error: "No custom command with that trigger" });
    return;
  }
  res.json({ ok: true });
});

// ── Chat rewards ─────────────────────────────────────────────────────────────

router.get("/:guildId/chat-rewards", (req, res) => {
  const guildId = req.params["guildId"]!;
  res.json({ chatRewards: getChatRewardsConfig(guildId) });
});

router.put("/:guildId/chat-rewards", (req, res) => {
  const guildId = req.params["guildId"]!;
  const body = req.body as Record<string, unknown>;
  const patch: Partial<ChatRewardsConfig> = {};

  if (typeof body["enabled"] === "boolean") patch.enabled = body["enabled"];
  if (typeof body["dailyAmount"] === "number") patch.dailyAmount = body["dailyAmount"];
  if (typeof body["messageMin"] === "number") patch.messageMin = body["messageMin"];
  if (typeof body["messageMax"] === "number") patch.messageMax = body["messageMax"];
  if (typeof body["cooldownSeconds"] === "number") patch.cooldownSeconds = body["cooldownSeconds"];
  if (typeof body["dropEnabled"] === "boolean") patch.dropEnabled = body["dropEnabled"];
  if (typeof body["dropChancePercent"] === "number") patch.dropChancePercent = body["dropChancePercent"];
  if (typeof body["dropMin"] === "number") patch.dropMin = body["dropMin"];
  if (typeof body["dropMax"] === "number") patch.dropMax = body["dropMax"];
  if (typeof body["staffRoleId"] === "string" && body["staffRoleId"]) patch.staffRoleId = body["staffRoleId"];
  if (typeof body["logChannelId"] === "string" && body["logChannelId"]) patch.logChannelId = body["logChannelId"];

  const chatRewards = updateChatRewardsConfig(guildId, patch);
  res.json({ chatRewards });
});

router.post("/:guildId/chat-rewards/excluded-channels", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { channelId } = req.body as { channelId?: string };
  if (!channelId) {
    res.status(400).json({ error: "channelId is required" });
    return;
  }
  const chatRewards = addExcludedChannel(guildId, channelId);
  res.json({ chatRewards });
});

router.delete("/:guildId/chat-rewards/excluded-channels/:channelId", (req, res) => {
  const guildId = req.params["guildId"]!;
  const channelId = req.params["channelId"]!;
  const chatRewards = removeExcludedChannel(guildId, channelId);
  res.json({ chatRewards });
});

// ── Shop ─────────────────────────────────────────────────────────────────────

router.get("/:guildId/shop", (req, res) => {
  const guildId = req.params["guildId"]!;
  res.json({ items: listItems(guildId) });
});

router.post("/:guildId/shop", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { name, price, description, stock } = req.body as Partial<ShopItem>;
  if (!name?.trim() || typeof price !== "number" || price <= 0 || !description?.trim()) {
    res.status(400).json({ error: "name, price (>0), and description are required" });
    return;
  }
  const item = upsertItem(guildId, {
    name: name.trim(),
    price,
    description: description.trim(),
    stock: typeof stock === "number" ? stock : undefined,
  });
  res.json({ item });
});

router.patch("/:guildId/shop/:name", (req, res) => {
  const guildId = req.params["guildId"]!;
  const name = req.params["name"]!;
  const { price, description, stock } = req.body as {
    price?: number;
    description?: string;
    stock?: number | null;
  };
  const item = editItem(guildId, name, { price, description, stock });
  if (!item) {
    res.status(404).json({ error: "No shop item with that name" });
    return;
  }
  res.json({ item });
});

router.delete("/:guildId/shop/:name", (req, res) => {
  const guildId = req.params["guildId"]!;
  const name = req.params["name"]!;
  const removed = removeItem(guildId, name);
  if (!removed) {
    res.status(404).json({ error: "No shop item with that name" });
    return;
  }
  res.json({ ok: true });
});

export default router;
