import { type Interaction, type TextChannel, type GuildMember } from 'discord.js';
import { showInviteModal, handleInviteModalSubmit, handleRewardSelect, handleGameChoice } from '../tickets/inviteRewards.js';
import { openStandardTicket, handleStandardModalSubmit } from '../tickets/standardTicket.js';
import { openGeneralSupportTicket } from '../tickets/generalSupport.js';
import { openRestockTicket } from '../tickets/restockTicket.js';
import { openCreditRedeemTicket } from '../tickets/creditRedeem.js';
import { sendTicketPanel } from '../panel.js';
import { ticketStates } from '../state.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { closeTicketChannel } from '../utils/channel.js';
import { sendTicketLog } from '../utils/ticketLog.js';
import { getGuildConfig } from '../config.js';
import { handleSetupCommand } from '../setupCommand.js';
import { handleCustomCommandCommand } from '../customCommand.js';
import { handleAdminNukeCommand, handleAdminNukeButton } from '../adminNuke.js';
import { handleActivateCommand } from '../activateCommand.js';
import { handleCreditsCommand } from '../creditsCommand.js';
import { handleNukeCommand } from '../nukeCommand.js';
import { handleFlurryCommand } from '../flurryCommand.js';
import { handleShopCommand } from '../shopCommand.js';
import { logger } from '../../lib/logger.js';

function isStaff(member: GuildMember): boolean {
  const cfg = getGuildConfig(member.guild.id);
  return (
    (!!cfg.staffRoleId && member.roles.cache.has(cfg.staffRoleId)) ||
    (!!cfg.giveawayHosterRoleId && member.roles.cache.has(cfg.giveawayHosterRoleId)) ||
    member.permissions.has('Administrator')
  );
}

export async function handleInteraction(interaction: Interaction): Promise<void> {
  try {
    // ── Slash commands ──────────────────────────────────────────────────────
    if (interaction.isChatInputCommand()) {
      if (interaction.commandName === 'panel') {
        await interaction.deferReply({ ephemeral: true });
        const ch = interaction.channel as TextChannel | null;
        if (!ch?.send) {
          await interaction.editReply({ content: '❌ Cannot post panel in this channel.' });
          return;
        }
        await sendTicketPanel(ch);
        await interaction.editReply({ content: '✅ Ticket panel posted!' });
      }
      if (interaction.commandName === 'setup') {
        await handleSetupCommand(interaction);
      }
      if (interaction.commandName === 'customcommand') {
        await handleCustomCommandCommand(interaction);
      }
      if (interaction.commandName === 'adminnuke') {
        await handleAdminNukeCommand(interaction);
      }
      if (interaction.commandName === 'activate') {
        await handleActivateCommand(interaction);
      }
      if (interaction.commandName === 'credits') {
        await handleCreditsCommand(interaction);
      }
      if (interaction.commandName === 'nuke') {
        await handleNukeCommand(interaction);
      }
      if (interaction.commandName === 'flurry') {
        await handleFlurryCommand(interaction);
      }
      if (interaction.commandName === 'shop') {
        await handleShopCommand(interaction);
      }
      return;
    }

    // ── Modal submits ────────────────────────────────────────────────────────
    if (interaction.isModalSubmit()) {
      const id = interaction.customId;
      if (id === 'roblox_modal_invite')   return void handleInviteModalSubmit(interaction);
      if (id === 'roblox_modal_giveaway') return void handleStandardModalSubmit(interaction, 'giveaway');
      if (id === 'roblox_modal_chat')     return void handleStandardModalSubmit(interaction, 'chat-rewards');
      if (id === 'roblox_modal_chest')    return void handleStandardModalSubmit(interaction, 'chest-rewards');
      return;
    }

    // ── Buttons ─────────────────────────────────────────────────────────────
    if (interaction.isButton()) {
      const id     = interaction.customId;
      const member = interaction.member as GuildMember;

      // Admin nuke confirmation
      if (id.startsWith('adminnuke_confirm:') || id.startsWith('adminnuke_cancel:')) {
        return void handleAdminNukeButton(interaction);
      }

      // Ticket creation (panel buttons)
      if (id === 'create_ticket_invite')   return void showInviteModal(interaction);
      if (id === 'create_ticket_giveaway') return void openStandardTicket(interaction, 'giveaway');
      if (id === 'create_ticket_chat')     return void openStandardTicket(interaction, 'chat-rewards');
      if (id === 'create_ticket_chest')    return void openStandardTicket(interaction, 'chest-rewards');
      if (id === 'create_ticket_yapper')   return void openStandardTicket(interaction, 'yapper-rewards');
      if (id === 'create_ticket_support')  return void openGeneralSupportTicket(interaction);
      if (id === 'create_ticket_credit_redeem') return void openCreditRedeemTicket(interaction);

      // Restock panel buttons
      if (id === 'create_restock_gear')   return void openRestockTicket(interaction, 'gear');
      if (id === 'create_restock_pets')   return void openRestockTicket(interaction, 'pets');
      if (id === 'create_restock_seeds')  return void openRestockTicket(interaction, 'seeds');
      if (id === 'create_restock_all')    return void openRestockTicket(interaction, 'all');
      if (id === 'create_restock_ps99')   return void openRestockTicket(interaction, 'ps99');

      // Game choice (invite rewards) — every game, including Pet Sim 99 and
      // Robux, is a regular dashboard-managed entry now, so this is one
      // generic route instead of special-cased ids.
      if (id.startsWith('choose_game_custom_')) {
        return void handleGameChoice(interaction, id.slice('choose_game_custom_'.length));
      }

      // ── Claim ticket ───────────────────────────────────────────────────────
      if (id === 'claim_ticket') {
        const state = ticketStates.get(interaction.channelId);
        if (!state) {
          await interaction.reply({ content: '❌ This is not an active ticket.', ephemeral: true });
          return;
        }
        if (!isStaff(member)) {
          await interaction.reply({ content: '❌ Only Ticket Staff can claim tickets.', ephemeral: true });
          return;
        }
        if (state.claimedBy) {
          await interaction.reply({
            content: `❌ This ticket has already been claimed by <@${state.claimedBy}>.`,
            ephemeral: true,
          });
          return;
        }

        state.claimedBy         = interaction.user.id;
        state.claimedByUsername = interaction.user.tag;

        await interaction.update({ components: [buildTicketControls(true, true)] });

        // Cast to TextChannel — ticket channels are always guild text channels
        const ticketChannel = interaction.channel as TextChannel | null;
        await ticketChannel?.send({
          embeds: [
            buildEmbed({
              title: '🙋 Ticket Claimed',
              description: [
                `This ticket has been claimed by <@${interaction.user.id}>.`,
                '',
                'They will assist you shortly.',
              ].join('\n'),
              color: COLORS.success,
              footer: `Claimed by ${interaction.user.tag}`,
            }),
          ],
        });
        return;
      }

      // ── Close ticket ───────────────────────────────────────────────────────
      if (id === 'close_ticket') {
        await handleCloseTicket(interaction.channelId, interaction.user.id, interaction.user.tag, member);
        if (!interaction.replied && !interaction.deferred) {
          await interaction.deferUpdate().catch(() => {});
        }
        return;
      }

      return;
    }

    // ── Select menus ────────────────────────────────────────────────────────
    if (interaction.isStringSelectMenu()) {
      const id = interaction.customId;
      // Every game (Grow a Garden, Pet Sim 99, Robux, custom) uses the same
      // dynamic per-category select now — category names are freeform, so
      // this can't be a fixed list of ids any more.
      if (id.startsWith('reward_select_')) {
        return void handleRewardSelect(interaction);
      }
    }
  } catch (err) {
    logger.error({ err }, 'Error handling interaction');
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) {
      await interaction
        .reply({ content: '❌ An error occurred. Please try again.', ephemeral: true })
        .catch(() => {});
    }
  }
}

/** Shared close logic — used by both button and !close command */
export async function handleCloseTicket(
  channelId: string,
  userId: string,
  userTag: string,
  member: GuildMember,
): Promise<void> {
  const state = ticketStates.get(channelId);
  if (!state) return;

  const isOwner   = userId === state.ownerId;
  const isClaimer = state.claimedBy === userId;
  const staff     = isStaff(member);

  if (!isOwner && !isClaimer && !staff) return;

  const channel = member.guild.channels.cache.get(channelId) as TextChannel | undefined;
  if (!channel) return;

  // Send ticket log before deleting the channel
  await sendTicketLog({
    client:      member.client,
    guildId:     member.guild.id,
    state,
    channelId,
    channelName: channel.name,
    closedBy:    userTag,
    closeReason: isOwner ? 'Closed by ticket owner' : isClaimer ? 'Closed by assigned staff' : 'Closed by staff',
  });

  ticketStates.delete(channelId);
  await closeTicketChannel(channel, userTag);
}
