import { promises as fs } from 'fs';
import path from 'path';
import type { TicketType } from './state.js';
import { logger } from '../lib/logger.js';

/** Per-server settings for the passive chat-credits / daily-claim system, set up via /activate. */
export interface ChatRewardsConfig {
  enabled: boolean;
  /** Credits granted by /credits daily */
  dailyAmount: number;
  /** Random credit range earned per qualifying message */
  messageMin: number;
  messageMax: number;
  /** Per-member cooldown, in seconds, between messages that earn credits */
  cooldownSeconds: number;
  staffRoleId?: string;
  logChannelId?: string;
  excludedChannelIds: string[];
  /** Chat drop system — small % chance per qualifying message to instantly win bonus credits. */
  dropEnabled: boolean;
  /** Chance out of 100 that a qualifying message triggers a drop. */
  dropChancePercent: number;
  dropMin: number;
  dropMax: number;
}

export const DEFAULT_CHAT_REWARDS: ChatRewardsConfig = {
  enabled: false,
  dailyAmount: 100,
  messageMin: 1,
  messageMax: 3,
  cooldownSeconds: 60,
  excludedChannelIds: [],
  dropEnabled: false,
  dropChancePercent: 2,
  dropMin: 10,
  dropMax: 50,
};

/** Per-server configuration — replaces the old hardcoded / single-guild env vars. */
export interface GuildConfig {
  staffRoleId?: string;
  giveawayHosterRoleId?: string;
  restockPingRoleId?: string;
  logChannelId?: string;
  restockPanelChannelId?: string;
  /** Channel the ticket panel (/panel) was last posted in — auto-reposted here on every bot restart/redeploy. */
  panelChannelId?: string;
  /** Ticket-type → parent category channel ID */
  categories: Partial<Record<TicketType, string>>;
  /**
   * Custom text commands, e.g. "!killer" → "{user} is god".
   * Keyed by trigger word (lowercase, without the leading "!").
   */
  customCommands: Record<string, { targetUserId: string; template: string }>;
  /** Chat rewards / credits system settings — optional, absent until /activate is run once. */
  chatRewards?: ChatRewardsConfig;
}

const EMPTY_CONFIG: GuildConfig = { categories: {}, customCommands: {} };

// Persisted to disk so config survives bot restarts. NOTE: on hosts with an
// ephemeral filesystem (e.g. Railway without a mounted volume) this resets on
// redeploy — mount a persistent volume at DATA_DIR for it to stick long-term.
const DATA_DIR  = process.env['DATA_DIR'] ?? path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'guildConfigs.json');

let configs: Record<string, GuildConfig> = {};
let loaded = false;
let saveQueue: Promise<void> = Promise.resolve();

async function load(): Promise<void> {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    configs = JSON.parse(raw);
    logger.info({ guilds: Object.keys(configs).length, dataFile: DATA_FILE }, 'Loaded guild configs from disk');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    if (code === 'ENOENT') {
      logger.info({ dataFile: DATA_FILE }, 'No existing guild config file found — starting fresh (this is expected on first run)');
    } else {
      logger.warn({ err, dataFile: DATA_FILE }, 'Failed to read guild config file — starting fresh');
    }
    configs = {};
    // Backward-compat: seed the config for DISCORD_GUILD_ID from the old
    // single-server env vars, if present, so existing deployments keep working.
    const legacyGuildId = process.env['DISCORD_GUILD_ID'];
    if (legacyGuildId) {
      configs[legacyGuildId] = {
        staffRoleId:           process.env['TICKET_STAFF_ROLE_ID'] || undefined,
        giveawayHosterRoleId:  process.env['GIVEAWAY_HOSTER_ROLE_ID'] || undefined,
        categories: {},
        customCommands: {},
      };
      logger.info({ guildId: legacyGuildId }, 'Seeded guild config from legacy env vars');
    }
  }
}

function persist(): void {
  saveQueue = saveQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.writeFile(DATA_FILE, JSON.stringify(configs, null, 2), 'utf-8');
    })
    .catch((err) => logger.error({ err, dataFile: DATA_FILE }, 'Failed to persist guild configs'));
}

/** Must be awaited once before the bot starts handling events. */
export async function initConfigStore(): Promise<void> {
  await load();
}

export function getGuildConfig(guildId: string): GuildConfig {
  const cfg = configs[guildId];
  if (!cfg) return EMPTY_CONFIG;
  // Backward-compat: older persisted configs won't have this field yet.
  if (!cfg.customCommands) cfg.customCommands = {};
  return cfg;
}

export function updateGuildConfig(
  guildId: string,
  patch: Partial<Omit<GuildConfig, 'categories' | 'customCommands'>>,
): GuildConfig {
  const current = configs[guildId] ?? { categories: {}, customCommands: {} };
  configs[guildId] = { ...current, ...patch };
  persist();
  return configs[guildId]!;
}

export function setGuildCategory(guildId: string, type: TicketType, categoryId: string): GuildConfig {
  const current = configs[guildId] ?? { categories: {}, customCommands: {} };
  current.categories = { ...current.categories, [type]: categoryId };
  configs[guildId] = current;
  persist();
  return current;
}

export function setCustomCommand(
  guildId: string,
  trigger: string,
  targetUserId: string,
  template: string,
): GuildConfig {
  const current = configs[guildId] ?? { categories: {}, customCommands: {} };
  if (!current.customCommands) current.customCommands = {};
  current.customCommands = {
    ...current.customCommands,
    [trigger.toLowerCase()]: { targetUserId, template },
  };
  configs[guildId] = current;
  persist();
  return current;
}

export function removeCustomCommand(guildId: string, trigger: string): boolean {
  const current = configs[guildId];
  if (!current?.customCommands?.[trigger.toLowerCase()]) return false;
  const { [trigger.toLowerCase()]: _removed, ...rest } = current.customCommands;
  current.customCommands = rest;
  configs[guildId] = current;
  persist();
  return true;
}

/** Returns the guild's chat rewards settings, merged with defaults for any unset fields. */
export function getChatRewardsConfig(guildId: string): ChatRewardsConfig {
  const cfg = getGuildConfig(guildId);
  return { ...DEFAULT_CHAT_REWARDS, ...(cfg.chatRewards ?? {}) };
}

export function updateChatRewardsConfig(
  guildId: string,
  patch: Partial<ChatRewardsConfig>,
): ChatRewardsConfig {
  const current = configs[guildId] ?? { categories: {}, customCommands: {} };
  const merged = { ...DEFAULT_CHAT_REWARDS, ...(current.chatRewards ?? {}), ...patch };
  current.chatRewards = merged;
  configs[guildId] = current;
  persist();
  return merged;
}

export function addExcludedChannel(guildId: string, channelId: string): ChatRewardsConfig {
  const cfg = getChatRewardsConfig(guildId);
  const excludedChannelIds = cfg.excludedChannelIds.includes(channelId)
    ? cfg.excludedChannelIds
    : [...cfg.excludedChannelIds, channelId];
  return updateChatRewardsConfig(guildId, { excludedChannelIds });
}

export function removeExcludedChannel(guildId: string, channelId: string): ChatRewardsConfig {
  const cfg = getChatRewardsConfig(guildId);
  return updateChatRewardsConfig(guildId, {
    excludedChannelIds: cfg.excludedChannelIds.filter((id) => id !== channelId),
  });
}

const REQUIRED_FIELDS: { key: keyof Omit<GuildConfig, 'categories'>; label: string }[] = [
  { key: 'staffRoleId',           label: 'Staff role (`/setup staff-role`)' },
  { key: 'giveawayHosterRoleId',  label: 'Giveaway hoster role (`/setup giveaway-role`)' },
  { key: 'restockPingRoleId',     label: 'Restock ping role (`/setup restock-ping-role`)' },
  { key: 'logChannelId',          label: 'Ticket log channel (`/setup log-channel`)' },
  { key: 'restockPanelChannelId', label: 'Restock panel channel (`/setup restock-panel-channel`)' },
];

const ALL_TICKET_TYPES: TicketType[] = [
  'invite-rewards',
  'giveaway',
  'chat-rewards',
  'chest-rewards',
  'yapper-rewards',
  'general-support',
  'restock',
];

/** Returns a list of human-readable descriptions of missing setup steps. */
export function getMissingSetupItems(guildId: string): string[] {
  const cfg = getGuildConfig(guildId);
  const missing: string[] = [];
  for (const field of REQUIRED_FIELDS) {
    if (!cfg[field.key]) missing.push(field.label);
  }
  for (const type of ALL_TICKET_TYPES) {
    if (!cfg.categories[type]) {
      missing.push(`Category for **${type}** (\`/setup category\`)`);
    }
  }
  // Only nag about the credit-redeem category once chat rewards is actually turned on.
  if (getChatRewardsConfig(guildId).enabled && !cfg.categories['credit-redeem']) {
    missing.push('Category for **credit-redeem** (`/setup category`)');
  }
  return missing;
}
