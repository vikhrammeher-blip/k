import { promises as fs } from 'fs';
import path from 'path';
import { logger } from '../../lib/logger.js';

/**
 * A dashboard-managed "sub-category" for invite rewards — shown as a button
 * when a member picks which game they want their invite reward for. Every
 * reward in data/rewards.ts belongs to exactly one of these via its
 * `gameId`. Fully editable/removable, including Pet Simulator 99 and Robux —
 * they used to be hardcoded with their own formulaic reward math, but now
 * ship as regular seeded games like everything else.
 */
export interface InviteRewardGame {
  id: string;
  label: string;
  emoji: string;
}

/** Seeded into every server's catalog the first time it's touched. */
const DEFAULT_GAMES: InviteRewardGame[] = [
  { id: 'grow-a-garden', label: 'Grow a Garden',     emoji: '🌱' },
  { id: 'pet-sim',       label: 'Pet Simulator 99',  emoji: '🎮' },
  { id: 'robux',         label: 'Robux',             emoji: '💵' },
];

type GuildGames = Record<string, InviteRewardGame>; // gameId -> game

interface StoredFile {
  version: 2;
  /** True once existing servers have had pet-sim/robux backfilled as editable games — see migrate(). */
  builtinsMigrated: boolean;
  guilds: Record<string, GuildGames>;
}

const DATA_DIR  = process.env['DATA_DIR'] ?? path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'inviteGames.json');

let file: StoredFile = { version: 2, builtinsMigrated: true, guilds: {} };
let loaded = false;
let saveQueue: Promise<void> = Promise.resolve();

async function load(): Promise<void> {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as unknown;

    if (parsed && typeof parsed === 'object' && 'version' in parsed) {
      file = parsed as StoredFile;
    } else {
      // Pre-migration shape: bare { guildId: { gameId: game } }, from before
      // pet-sim/robux existed as editable games — wrap it and mark
      // unmigrated so migrate() backfills them for every guild that's
      // already here (new guilds get them for free via DEFAULT_GAMES).
      logger.info('Migrating invite games file to versioned format');
      file = { version: 2, builtinsMigrated: false, guilds: (parsed as Record<string, GuildGames>) ?? {} };
    }
    logger.info({ guilds: Object.keys(file.guilds).length, dataFile: DATA_FILE }, 'Loaded invite reward games from disk');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    if (code === 'ENOENT') {
      logger.info({ dataFile: DATA_FILE }, 'No existing invite games file found — starting fresh (this is expected on first run)');
    } else {
      logger.warn({ err, dataFile: DATA_FILE }, 'Failed to read invite games file — starting fresh');
    }
    file = { version: 2, builtinsMigrated: true, guilds: {} };
  }
  migrate();
}

/**
 * One-time backfill: any guild that already existed before pet-sim/robux
 * became editable games gets them added now. Gated on a persisted flag so
 * this runs exactly once ever — otherwise deleting "Pet Simulator 99" as a
 * game would just have it reappear on the next restart.
 */
function migrate(): void {
  if (file.builtinsMigrated) return;
  for (const guildId of Object.keys(file.guilds)) {
    const guild = file.guilds[guildId]!;
    for (const game of DEFAULT_GAMES) {
      if (!guild[game.id]) guild[game.id] = { ...game };
    }
  }
  file.builtinsMigrated = true;
  logger.info('Backfilled Pet Simulator 99 and Robux as editable games for existing servers');
  persist();
}

function persist(): void {
  saveQueue = saveQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.writeFile(DATA_FILE, JSON.stringify(file, null, 2), 'utf-8');
    })
    .catch((err) => logger.error({ err, dataFile: DATA_FILE }, 'Failed to persist invite reward games'));
}

/** Must be awaited once before the bot starts handling events. */
export async function initInviteGamesStore(): Promise<void> {
  await load();
}

function getGuildGames(guildId: string): GuildGames {
  let guild = file.guilds[guildId];
  if (!guild) {
    guild = Object.fromEntries(DEFAULT_GAMES.map((g) => [g.id, { ...g }]));
    file.guilds[guildId] = guild;
    persist();
  }
  return guild;
}

export function getGames(guildId: string): InviteRewardGame[] {
  return Object.values(getGuildGames(guildId)).sort((a, b) => a.label.localeCompare(b.label));
}

export function getGame(guildId: string, id: string): InviteRewardGame | undefined {
  return getGuildGames(guildId)[id];
}

function slugify(name: string): string {
  return (
    name
      .toLowerCase()
      .replace(/[^a-z0-9]+/g, '-')
      .replace(/^-+|-+$/g, '')
      .slice(0, 60) || 'game'
  );
}

function uniqueId(guild: GuildGames, base: string): string {
  let id = base;
  let n = 2;
  while (guild[id]) {
    id = `${base}-${n}`;
    n += 1;
  }
  return id;
}

export interface GameInput {
  label: string;
  emoji: string;
}

export function addGame(guildId: string, input: GameInput): InviteRewardGame {
  const guild = getGuildGames(guildId);
  const game: InviteRewardGame = {
    id: uniqueId(guild, slugify(input.label)),
    label: input.label,
    emoji: input.emoji || '🎮',
  };
  guild[game.id] = game;
  persist();
  return game;
}

export function editGame(guildId: string, id: string, patch: Partial<GameInput>): InviteRewardGame | undefined {
  const game = getGuildGames(guildId)[id];
  if (!game) return undefined;
  if (patch.label !== undefined) game.label = patch.label;
  if (patch.emoji !== undefined) game.emoji = patch.emoji;
  persist();
  return game;
}

export function removeGame(guildId: string, id: string): boolean {
  const guild = getGuildGames(guildId);
  if (!guild[id]) return false;
  delete guild[id];
  persist();
  return true;
}
