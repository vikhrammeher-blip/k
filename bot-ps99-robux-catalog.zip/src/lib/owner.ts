// The Discord user ID of the bot's owner. Gates dashboard views that would
// otherwise leak the owner's identity to any other admin who happens to
// share a server with this bot — namely which servers it's installed in
// (names, icons, member counts) and its full command catalog.
//
// Configurable via BOT_OWNER_ID (set it on Railway if the owner ever
// changes) so this never requires a code edit or redeploy from source.
const DEFAULT_OWNER_ID = '747815577682444382';

export function getOwnerId(): string {
  return process.env['BOT_OWNER_ID']?.trim() || DEFAULT_OWNER_ID;
}

export function isOwner(userId: string | undefined | null): boolean {
  return !!userId && userId === getOwnerId();
}
