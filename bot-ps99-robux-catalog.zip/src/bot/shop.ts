import { promises as fs } from 'fs';
import path from 'path';
import { logger } from '../lib/logger.js';

export interface ShopItem {
  name: string;
  price: number;
  description: string;
  /** undefined/null = unlimited stock */
  stock?: number;
}

type GuildShop = Record<string, ShopItem>; // itemKey (lowercase name) -> item

// Persisted to disk, same pattern as guildConfigs.json / chatCredits.json —
// mount a persistent volume at DATA_DIR on hosts with an ephemeral
// filesystem (e.g. Railway without a volume) or this resets on redeploy.
const DATA_DIR  = process.env['DATA_DIR'] ?? path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'shop.json');

let store: Record<string, GuildShop> = {}; // guildId -> GuildShop
let loaded = false;
let saveQueue: Promise<void> = Promise.resolve();

async function load(): Promise<void> {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    store = JSON.parse(raw);
    logger.info({ guilds: Object.keys(store).length, dataFile: DATA_FILE }, 'Loaded shop items from disk');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    if (code === 'ENOENT') {
      logger.info({ dataFile: DATA_FILE }, 'No existing shop file found — starting fresh (this is expected on first run)');
    } else {
      logger.warn({ err, dataFile: DATA_FILE }, 'Failed to read shop file — starting fresh');
    }
    store = {};
  }
}

function persist(): void {
  saveQueue = saveQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.writeFile(DATA_FILE, JSON.stringify(store, null, 2), 'utf-8');
    })
    .catch((err) => logger.error({ err, dataFile: DATA_FILE }, 'Failed to persist shop items'));
}

/** Must be awaited once before the bot starts handling events. */
export async function initShopStore(): Promise<void> {
  await load();
}

function key(name: string): string {
  return name.trim().toLowerCase();
}

export function listItems(guildId: string): ShopItem[] {
  const guild = store[guildId] ?? {};
  return Object.values(guild).sort((a, b) => a.price - b.price);
}

export function getItem(guildId: string, name: string): ShopItem | undefined {
  return store[guildId]?.[key(name)];
}

/** Creates a new item or overwrites an existing one with the same name. */
export function upsertItem(guildId: string, item: ShopItem): ShopItem {
  const guild = store[guildId] ?? (store[guildId] = {});
  guild[key(item.name)] = item;
  persist();
  return item;
}

export function removeItem(guildId: string, name: string): boolean {
  const guild = store[guildId];
  if (!guild || !guild[key(name)]) return false;
  delete guild[key(name)];
  persist();
  return true;
}

export interface EditPatch {
  price?: number;
  description?: string;
  /** Pass null to make stock unlimited. Omit to leave unchanged. */
  stock?: number | null;
}

export function editItem(guildId: string, name: string, patch: EditPatch): ShopItem | undefined {
  const guild = store[guildId];
  const item  = guild?.[key(name)];
  if (!guild || !item) return undefined;
  if (patch.price !== undefined)       item.price = patch.price;
  if (patch.description !== undefined) item.description = patch.description;
  if (patch.stock !== undefined)       item.stock = patch.stock === null ? undefined : patch.stock;
  persist();
  return item;
}

/** Decrements stock by 1 for a limited-stock item. No-op for unlimited items. */
export function decrementStock(guildId: string, name: string): void {
  const item = store[guildId]?.[key(name)];
  if (!item || item.stock === undefined) return;
  item.stock = Math.max(0, item.stock - 1);
  persist();
}
