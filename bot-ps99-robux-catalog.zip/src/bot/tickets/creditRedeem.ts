import { type ButtonInteraction, type GuildMember } from 'discord.js';
import { createTicketChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { ticketStates } from '../state.js';
import { getGuildConfig, getChatRewardsConfig } from '../config.js';
import { getBalance } from '../chatCredits.js';
import { logger } from '../../lib/logger.js';

export async function openCreditRedeemTicket(interaction: ButtonInteraction): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild  = interaction.guild!;
  const member = interaction.member as GuildMember;

  const rewardsCfg = getChatRewardsConfig(guild.id);
  if (!rewardsCfg.enabled) {
    await interaction.editReply({ content: '❌ Chat rewards isn\'t enabled on this server.' });
    return;
  }

  const guildConfig = getGuildConfig(guild.id);
  const staffRoleId = rewardsCfg.staffRoleId ?? guildConfig.staffRoleId;
  const categoryId  = guildConfig.categories['credit-redeem'];

  if (!staffRoleId) {
    await interaction.editReply({
      content:
        '❌ This server hasn\'t set a staff role for chat rewards yet. Ask an admin to run `/activate staff-role` or `/setup staff-role`.',
    });
    return;
  }

  const balance = getBalance(guild.id, member.id);

  try {
    const channel = await createTicketChannel({
      guild,
      member,
      ticketType: 'credit-redeem',
      staffRoleId,
      categoryId,
    });

    ticketStates.set(channel.id, {
      ticketType:    'credit-redeem',
      ownerId:       member.id,
      ownerUsername: member.user.username,
      createdAt:     new Date(),
    });

    await channel.send(`<@&${staffRoleId}>`);

    await channel.send({
      embeds: [
        buildEmbed({
          title: '💳 Chat Credits Redemption',
          description: [
            `Welcome, <@${member.id}>! 👋`,
            '',
            `Your current balance: **${balance} credits**`,
            '',
            "Please let us know what you'd like to redeem your credits for.",
            'A member of staff will review and process your request shortly.',
          ].join('\n'),
          color: COLORS.info,
          footer: 'Staff: adjust the balance with /credits take once fulfilled',
        }),
      ],
      components: [buildTicketControls(true)],
    });

    await interaction.editReply({ content: `✅ Ticket created: ${channel}` });
  } catch (err) {
    logger.error({ err }, 'Failed to create credit redeem ticket');
    await interaction.editReply({ content: '❌ Failed to create ticket. Please contact a staff member.' });
  }
}
