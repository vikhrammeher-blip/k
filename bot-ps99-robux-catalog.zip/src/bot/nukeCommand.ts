import {
  type ChatInputCommandInteraction,
  type GuildMember,
  SlashCommandBuilder,
  EmbedBuilder,
  PermissionFlagsBits,
} from 'discord.js';
import { logger } from '../lib/logger.js';

// Real timeout, themed after Sukuna's "Domain Expansion: Malevolent Shrine".
// Discord refuses to time out anyone with Administrator, no matter the role
// hierarchy — so for admin targets we temporarily strip whichever of their
// roles grant Administrator, apply the timeout, then restore those roles
// once it expires.
const SUKUNA_RED = 0x8b0000;
const TIMEOUT_MS = 5_000;
const ADMIN_TIMEOUT_MS = 30_000;

export function buildNukeCommand() {
  return new SlashCommandBuilder()
    .setName('nuke')
    .setDescription('👹 Open the Domain on a member — timeout')
    .addUserOption((opt) =>
      opt.setName('user').setDescription('The "victim"').setRequired(true),
    )
    .toJSON();
}

function adminRoles(member: GuildMember) {
  return member.roles.cache.filter(
    (role) => role.permissions.has(PermissionFlagsBits.Administrator) && role.id !== member.guild.id,
  );
}

export async function handleNukeCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const target = interaction.options.getUser('user', true);

  if (target.id === interaction.user.id) {
    await interaction.reply({ content: '❌ You cannot use this on yourself.', ephemeral: true });
    return;
  }
  if (target.bot) {
    await interaction.reply({ content: '❌ This command cannot target bots.', ephemeral: true });
    return;
  }

  const member = await guild.members.fetch(target.id).catch(() => null);
  if (!member) {
    await interaction.reply({ content: '❌ That user is not in this server.', ephemeral: true });
    return;
  }

  const me = guild.members.me;
  const rolesToStrip = adminRoles(member);
  const isAdmin = rolesToStrip.size > 0 || member.permissions.has(PermissionFlagsBits.Administrator);

  if (isAdmin) {
    // Need Manage Roles, and the bot's highest role must sit above every
    // admin role we're about to strip, or Discord will reject it.
    if (!me?.permissions.has(PermissionFlagsBits.ManageRoles)) {
      await interaction.reply({ content: "❌ I need the Manage Roles permission to nuke an admin.", ephemeral: true });
      return;
    }
    const unreachable = rolesToStrip.some((role) => role.position >= (me.roles.highest.position ?? 0));
    if (unreachable) {
      await interaction.reply({ content: "❌ I can't strip that admin's roles — my highest role isn't above theirs.", ephemeral: true });
      return;
    }
  } else if (!member.moderatable) {
    await interaction.reply({ content: "❌ I don't have permission to time out that member (role hierarchy).", ephemeral: true });
    return;
  }

  await interaction.reply(`👹 **Domain Expansion: Malevolent Shrine** — opened on ${target}...`);

  const strippedRoleIds = [...rolesToStrip.keys()];
  const duration = isAdmin ? ADMIN_TIMEOUT_MS : TIMEOUT_MS;

  try {
    if (strippedRoleIds.length > 0) {
      await member.roles.remove(strippedRoleIds, `Nuke prep (temp admin strip) by ${interaction.user.tag}`);
    }
    await member.timeout(duration, `Nuked by ${interaction.user.tag}`);
  } catch (err) {
    logger.error({ err, targetId: target.id }, 'Nuke timeout failed');
    // Best-effort role restore if we stripped before failing
    if (strippedRoleIds.length > 0) {
      await member.roles.add(strippedRoleIds, 'Nuke failed — restoring roles').catch(() => {});
    }
    await interaction.followUp({ content: `❌ Failed to time out ${target}. I may be missing permissions.` });
    return;
  }

  const embed = new EmbedBuilder()
    .setColor(SUKUNA_RED)
    .setTitle('👹 Domain Expansion: Malevolent Shrine')
    .setDescription(
      [
        `**${target}** is caught inside the domain.`,
        '',
        '*"Know your place."*',
        '',
        `⏱️ Timed out for **${duration / 1000} seconds**.`,
        strippedRoleIds.length > 0 ? '\n👑 Admin roles temporarily stripped and will be restored after the timeout.' : '',
      ].join('\n'),
    )
    .setThumbnail(target.displayAvatarURL())
    .setFooter({ text: `Summoned by ${interaction.user.tag}` })
    .setTimestamp();

  await interaction.followUp({ embeds: [embed] });

  if (strippedRoleIds.length > 0) {
    setTimeout(() => {
      member.roles
        .add(strippedRoleIds, 'Nuke timeout expired — restoring admin roles')
        .catch((err) =>
          logger.error({ err, targetId: target.id }, 'Failed to restore admin roles after nuke'),
        );
    }, duration);
  }
}
