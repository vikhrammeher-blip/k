import {
  type ChatInputCommandInteraction,
  type GuildMember,
  SlashCommandBuilder,
} from 'discord.js';
import { getGuildConfig, getChatRewardsConfig } from './config.js';
import { getBalance, removeCredits } from './chatCredits.js';
import { listItems, getItem, upsertItem, removeItem, editItem, decrementStock } from './shop.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { logChatRewardsEvent } from './utils/ticketLog.js';

function isChatRewardsStaff(member: GuildMember): boolean {
  const guildCfg   = getGuildConfig(member.guild.id);
  const rewardsCfg = getChatRewardsConfig(member.guild.id);
  return (
    (!!guildCfg.staffRoleId && member.roles.cache.has(guildCfg.staffRoleId)) ||
    (!!rewardsCfg.staffRoleId && member.roles.cache.has(rewardsCfg.staffRoleId)) ||
    member.permissions.has('Administrator')
  );
}

function stockLabel(stock: number | undefined): string {
  if (stock === undefined) return 'Unlimited';
  return stock > 0 ? `${stock} left` : 'Out of stock';
}

export function buildShopCommand() {
  return new SlashCommandBuilder()
    .setName('shop')
    .setDescription('Browse and buy items with your chat rewards credits')
    .setDMPermission(false)
    .addSubcommand((sub) => sub.setName('view').setDescription('View everything available in the shop'))
    .addSubcommand((sub) =>
      sub
        .setName('buy')
        .setDescription('Buy an item with your credits')
        .addStringOption((opt) => opt.setName('item').setDescription('Exact item name').setRequired(true)),
    )
    .addSubcommandGroup((group) =>
      group
        .setName('manage')
        .setDescription('Manage shop items (Staff only)')
        .addSubcommand((sub) =>
          sub
            .setName('add')
            .setDescription('Add a new shop item (or overwrite one with the same name)')
            .addStringOption((opt) => opt.setName('name').setDescription('Item name').setRequired(true))
            .addIntegerOption((opt) => opt.setName('price').setDescription('Price in credits').setRequired(true).setMinValue(1))
            .addStringOption((opt) => opt.setName('description').setDescription('What the member gets').setRequired(true))
            .addIntegerOption((opt) => opt.setName('stock').setDescription('Limited stock count (omit for unlimited)').setRequired(false).setMinValue(0)),
        )
        .addSubcommand((sub) =>
          sub
            .setName('edit')
            .setDescription('Edit an existing shop item')
            .addStringOption((opt) => opt.setName('name').setDescription('Exact item name').setRequired(true))
            .addIntegerOption((opt) => opt.setName('price').setDescription('New price in credits').setRequired(false).setMinValue(1))
            .addStringOption((opt) => opt.setName('description').setDescription('New description').setRequired(false))
            .addIntegerOption((opt) => opt.setName('stock').setDescription('New stock count (0 = out of stock)').setRequired(false).setMinValue(0))
            .addBooleanOption((opt) => opt.setName('unlimited').setDescription('Set to true to make stock unlimited').setRequired(false)),
        )
        .addSubcommand((sub) =>
          sub
            .setName('remove')
            .setDescription('Remove a shop item')
            .addStringOption((opt) => opt.setName('name').setDescription('Exact item name').setRequired(true)),
        )
        .addSubcommand((sub) => sub.setName('list').setDescription('View all shop items, including out-of-stock ones')),
    )
    .toJSON();
}

function buildShopEmbed(items: ReturnType<typeof listItems>, title: string) {
  if (items.length === 0) {
    return buildEmbed({
      title,
      description: 'The shop is empty right now — check back later!',
      color: COLORS.neutral,
    });
  }
  return buildEmbed({
    title,
    description: 'Redeem your chat rewards credits for the items below with `/shop buy <item>`.',
    color: COLORS.primary,
    fields: items.map((item) => ({
      name:   `${item.name} — ${item.price} credits`,
      value:  `${item.description}\n*${stockLabel(item.stock)}*`,
      inline: false,
    })),
  });
}

export async function handleShopCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId || !interaction.guild) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const group = interaction.options.getSubcommandGroup(false);
  const sub   = interaction.options.getSubcommand();
  const rewardsCfg = getChatRewardsConfig(guildId);

  // ── Manage (staff only) ────────────────────────────────────────────────
  if (group === 'manage') {
    const member = interaction.member as GuildMember;
    if (!isChatRewardsStaff(member)) {
      await interaction.reply({ content: '❌ Only Chat Rewards staff can manage the shop.', ephemeral: true });
      return;
    }

    if (sub === 'add') {
      const name        = interaction.options.getString('name', true);
      const price       = interaction.options.getInteger('price', true);
      const description = interaction.options.getString('description', true);
      const stock       = interaction.options.getInteger('stock') ?? undefined;

      const existed = !!getItem(guildId, name);
      upsertItem(guildId, { name, price, description, stock });
      await interaction.reply({
        content: `✅ ${existed ? 'Updated' : 'Added'} shop item **${name}** — ${price} credits, ${stockLabel(stock)}.`,
        ephemeral: true,
      });
      await logChatRewardsEvent(
        interaction.client, guildId,
        `🛍️ <@${interaction.user.id}> ${existed ? 'updated' : 'added'} shop item **${name}** (${price} credits, ${stockLabel(stock)}).`,
      );
      return;
    }

    if (sub === 'edit') {
      const name        = interaction.options.getString('name', true);
      const price       = interaction.options.getInteger('price') ?? undefined;
      const description = interaction.options.getString('description') ?? undefined;
      const stockOpt     = interaction.options.getInteger('stock');
      const unlimited    = interaction.options.getBoolean('unlimited') ?? false;

      if (!getItem(guildId, name)) {
        await interaction.reply({ content: `❌ No shop item named **${name}**.`, ephemeral: true });
        return;
      }

      const updated = editItem(guildId, name, {
        price,
        description,
        stock: unlimited ? null : (stockOpt ?? undefined),
      });

      await interaction.reply({
        content: `✅ Updated **${updated!.name}** — ${updated!.price} credits, ${stockLabel(updated!.stock)}.`,
        ephemeral: true,
      });
      await logChatRewardsEvent(interaction.client, guildId, `🛠️ <@${interaction.user.id}> edited shop item **${name}**.`);
      return;
    }

    if (sub === 'remove') {
      const name = interaction.options.getString('name', true);
      const ok = removeItem(guildId, name);
      await interaction.reply({
        content: ok ? `✅ Removed shop item **${name}**.` : `❌ No shop item named **${name}**.`,
        ephemeral: true,
      });
      if (ok) {
        await logChatRewardsEvent(interaction.client, guildId, `🗑️ <@${interaction.user.id}> removed shop item **${name}**.`);
      }
      return;
    }

    if (sub === 'list') {
      const items = listItems(guildId);
      await interaction.reply({ embeds: [buildShopEmbed(items, '🛍️ Shop Items (Admin View)')], ephemeral: true });
      return;
    }
    return;
  }

  // ── View (everyone) ────────────────────────────────────────────────────
  if (sub === 'view') {
    const items = listItems(guildId).filter((i) => i.stock === undefined || i.stock > 0);
    await interaction.reply({ embeds: [buildShopEmbed(items, '🛍️ Shop')], ephemeral: true });
    return;
  }

  // ── Buy (everyone) ─────────────────────────────────────────────────────
  if (sub === 'buy') {
    if (!rewardsCfg.enabled) {
      await interaction.reply({
        content: '❌ Chat rewards isn\'t enabled on this server yet, so the shop isn\'t open.',
        ephemeral: true,
      });
      return;
    }

    const name = interaction.options.getString('item', true);
    const item = getItem(guildId, name);
    if (!item) {
      await interaction.reply({ content: `❌ No shop item named **${name}**. Check \`/shop view\` for exact names.`, ephemeral: true });
      return;
    }
    if (item.stock !== undefined && item.stock <= 0) {
      await interaction.reply({ content: `❌ **${item.name}** is out of stock.`, ephemeral: true });
      return;
    }

    const result = removeCredits(guildId, interaction.user.id, item.price);
    if (!result.ok) {
      await interaction.reply({
        content: `❌ You only have **${result.balance}** credits — **${item.name}** costs **${item.price}**.`,
        ephemeral: true,
      });
      return;
    }

    decrementStock(guildId, item.name);

    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '✅ Purchase Complete',
          description: [
            `You bought **${item.name}** for **${item.price}** credits.`,
            `New balance: **${result.balance}**.`,
            '',
            'A staff member has been notified to fulfil your order.',
          ].join('\n'),
          color: COLORS.success,
        }),
      ],
      ephemeral: true,
    });

    await logChatRewardsEvent(
      interaction.client, guildId,
      `🛒 <@${interaction.user.id}> bought **${item.name}** for **${item.price}** credits (balance now **${result.balance}**). Please fulfil this order.`,
    );
    return;
  }
}
