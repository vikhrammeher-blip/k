import {
  EmbedBuilder,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';

export const COLORS = {
  primary: 0x5865F2,
  success: 0x57F287,
  warning: 0xFEE75C,
  danger:  0xED4245,
  info:    0xEB459E,
  neutral: 0x99AAB5,
} as const;

export interface EmbedOpts {
  title?: string;
  description: string;
  color?: number;
  footer?: string;
  fields?: Array<{ name: string; value: string; inline?: boolean }>;
}

export function buildEmbed(opts: EmbedOpts): EmbedBuilder {
  const embed = new EmbedBuilder()
    .setColor(opts.color ?? COLORS.primary)
    .setDescription(opts.description)
    .setTimestamp();
  if (opts.title)          embed.setTitle(opts.title);
  if (opts.footer)         embed.setFooter({ text: opts.footer });
  if (opts.fields?.length) embed.addFields(opts.fields);
  return embed;
}

/**
 * Builds the Claim + Close control row shown on every ticket.
 * @param hasClaim  true for all types except general-support
 * @param claimed   true once a staff member has already claimed the ticket
 */
export function buildTicketControls(
  hasClaim: boolean,
  claimed = false,
): ActionRowBuilder<ButtonBuilder> {
  const row = new ActionRowBuilder<ButtonBuilder>();

  if (hasClaim) {
    row.addComponents(
      new ButtonBuilder()
        .setCustomId('claim_ticket')
        .setLabel(claimed ? '✅ Claimed' : '🙋 Claim Ticket')
        .setStyle(claimed ? ButtonStyle.Secondary : ButtonStyle.Primary)
        .setDisabled(claimed),
    );
  }

  row.addComponents(
    new ButtonBuilder()
      .setCustomId('close_ticket')
      .setLabel('🔒 Close Ticket')
      .setStyle(ButtonStyle.Danger),
  );

  return row;
}
