import { Router } from "express";
import { randomBytes } from "crypto";
import { PermissionFlagsBits } from "discord.js";
import { getBotClient } from "../bot/index.js";
import { createSession, destroySession, SESSION_COOKIE, SESSION_MAX_AGE_MS } from "../lib/session.js";
import { isOwner } from "../lib/owner.js";
import { logger } from "../lib/logger.js";

const router = Router();

const STATE_COOKIE = "gh_oauth_state";
const isProd = process.env["NODE_ENV"] === "production";

function oauthConfigured(): boolean {
  return Boolean(
    process.env["DISCORD_CLIENT_ID"] &&
      process.env["DISCORD_CLIENT_SECRET"] &&
      process.env["DASHBOARD_PUBLIC_URL"],
  );
}

function redirectUri(): string {
  const base = (process.env["DASHBOARD_PUBLIC_URL"] ?? "").replace(/\/+$/, "");
  return `${base}/api/auth/callback`;
}

router.get("/login", (_req, res) => {
  if (!oauthConfigured()) {
    res
      .status(503)
      .json({ error: "Discord login isn't configured on this deployment yet. See README for setup." });
    return;
  }

  const state = randomBytes(16).toString("hex");
  res.cookie(STATE_COOKIE, state, {
    httpOnly: true,
    signed: true,
    sameSite: "lax",
    secure: isProd,
    maxAge: 5 * 60 * 1000,
  });

  const params = new URLSearchParams({
    client_id: process.env["DISCORD_CLIENT_ID"]!,
    redirect_uri: redirectUri(),
    response_type: "code",
    scope: "identify guilds",
    state,
    prompt: "consent",
  });
  res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
});

router.get("/callback", async (req, res) => {
  if (!oauthConfigured()) {
    res.status(503).send("Discord login isn't configured on this deployment yet.");
    return;
  }

  const code = typeof req.query["code"] === "string" ? req.query["code"] : undefined;
  const state = typeof req.query["state"] === "string" ? req.query["state"] : undefined;
  const expectedState = (req.signedCookies as Record<string, string> | undefined)?.[STATE_COOKIE];
  res.clearCookie(STATE_COOKIE);

  if (!code || !state || state !== expectedState) {
    res.redirect("/?authError=state");
    return;
  }

  try {
    const tokenRes = await fetch("https://discord.com/api/oauth2/token", {
      method: "POST",
      headers: { "Content-Type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({
        client_id: process.env["DISCORD_CLIENT_ID"]!,
        client_secret: process.env["DISCORD_CLIENT_SECRET"]!,
        grant_type: "authorization_code",
        code,
        redirect_uri: redirectUri(),
      }),
    });
    if (!tokenRes.ok) throw new Error(`token exchange failed with status ${tokenRes.status}`);
    const tokenData = (await tokenRes.json()) as { access_token: string };

    const [userRes, guildsRes] = await Promise.all([
      fetch("https://discord.com/api/users/@me", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      }),
      fetch("https://discord.com/api/users/@me/guilds", {
        headers: { Authorization: `Bearer ${tokenData.access_token}` },
      }),
    ]);
    if (!userRes.ok || !guildsRes.ok) throw new Error("failed to fetch Discord profile/guilds");

    const user = (await userRes.json()) as { id: string; username: string; avatar: string | null };
    const userGuilds = (await guildsRes.json()) as Array<{
      id: string;
      name: string;
      owner: boolean;
      permissions: string;
    }>;

    const client = getBotClient();
    const botGuildIds = new Set(client ? [...client.guilds.cache.keys()] : []);

    const adminGuilds = userGuilds
      .filter((g) => botGuildIds.has(g.id))
      .filter(
        (g) =>
          g.owner ||
          (BigInt(g.permissions) & PermissionFlagsBits.Administrator) === PermissionFlagsBits.Administrator,
      )
      .map((g) => ({ id: g.id, name: g.name }));

    if (adminGuilds.length === 0) {
      res.redirect("/?authError=forbidden");
      return;
    }

    const sessionId = createSession({
      userId: user.id,
      username: user.username,
      avatar: user.avatar,
      adminGuilds,
    });

    res.cookie(SESSION_COOKIE, sessionId, {
      httpOnly: true,
      signed: true,
      sameSite: "lax",
      secure: isProd,
      maxAge: SESSION_MAX_AGE_MS,
      path: "/",
    });
    res.redirect("/");
  } catch (err) {
    logger.error({ err }, "Discord OAuth callback failed");
    res.redirect("/?authError=failed");
  }
});

router.get("/me", (req, res) => {
  const session = req.dashboardSession;
  if (!session) {
    res.json({ loggedIn: false, configured: oauthConfigured() });
    return;
  }
  res.json({
    loggedIn: true,
    username: session.username,
    avatar: session.avatar,
    adminGuilds: session.adminGuilds,
    isOwner: isOwner(session.userId),
  });
});

router.post("/logout", (req, res) => {
  const sessionId = (req.signedCookies as Record<string, string> | undefined)?.[SESSION_COOKIE];
  destroySession(sessionId);
  res.clearCookie(SESSION_COOKIE, { path: "/" });
  res.json({ ok: true });
});

export default router;
