import { type Client, type TextChannel } from 'discord.js';
import { buildEmbed, COLORS } from './embeds.js';
import type { TicketState } from '../state.js';
import { getGuildConfig, getChatRewardsConfig } from '../config.js';
import { logger } from '../../lib/logger.js';

/**
 * Posts a plain-text line to the guild's chat-rewards log channel (set via
 * /activate log-channel) — used for daily claims and staff credit adjustments.
 * No-ops silently if that channel hasn't been configured.
 */
export async function logChatRewardsEvent(client: Client, guildId: string, text: string): Promise<void> {
  const logChannelId = getChatRewardsConfig(guildId).logChannelId;
  if (!logChannelId) return;

  try {
    const logChannel = await client.channels.fetch(logChannelId) as TextChannel | null;
    if (!logChannel?.isTextBased()) {
      logger.warn({ guildId, channelId: logChannelId }, 'Chat rewards log channel not found');
      return;
    }
    await logChannel.send({ content: text, allowedMentions: { parse: [] } });
  } catch (err) {
    logger.error({ err, guildId }, 'Failed to log chat rewards event');
  }
}

const MAX_LOGGED_CONTENT_LENGTH = 800;

/**
 * Mirrors a single message sent inside a ticket channel to the guild's
 * configured log channel, in real time. This captures messages even if the
 * bot goes on to delete the original (e.g. enforced screenshot-only phases),
 * so staff have a full record of what was said in every ticket.
 */
export async function logTicketMessage(opts: {
  client: Client;
  guildId: string;
  channelId: string;
  channelName: string;
  authorId: string;
  authorTag: string;
  isBot: boolean;
  content: string;
  attachmentUrls: string[];
}): Promise<void> {
  const { client, guildId, channelId, channelName, authorId, authorTag, isBot, content, attachmentUrls } = opts;

  const logChannelId = getGuildConfig(guildId).logChannelId;
  if (!logChannelId) return; // not configured — admin needs to run /setup log-channel

  // Nothing to show
  if (!content.trim() && attachmentUrls.length === 0) return;

  try {
    const logChannel = await client.channels.fetch(logChannelId) as TextChannel | null;
    if (!logChannel?.isTextBased()) {
      logger.warn({ guildId, channelId: logChannelId }, 'Ticket log channel not found');
      return;
    }

    let trimmedContent = content.trim();
    if (trimmedContent.length > MAX_LOGGED_CONTENT_LENGTH) {
      trimmedContent = `${trimmedContent.slice(0, MAX_LOGGED_CONTENT_LENGTH)}… *(truncated)*`;
    }

    const lines = [
      `📨 **#${channelName}** — ${isBot ? '🤖' : ''}<@${authorId}> (\`${authorTag}\`)`,
    ];
    if (trimmedContent) lines.push(trimmedContent);
    if (attachmentUrls.length) {
      lines.push(attachmentUrls.map(url => `📎 ${url}`).join('\n'));
    }

    await logChannel.send({ content: lines.join('\n'), allowedMentions: { parse: [] } });
  } catch (err) {
    logger.error({ err, guildId, channelId }, 'Failed to log ticket message');
  }
}

const TICKET_TYPE_LABELS: Record<string, string> = {
  'invite-rewards':  '🎟️ Invite Rewards',
  'giveaway':        '🎉 Giveaway Winner',
  'chat-rewards':    '💬 Chat Rewards',
  'chest-rewards':   '📦 Chest Rewards',
  'yapper-rewards':  '🗣️ Yapper Rewards',
  'general-support': '🛠️ General Support',
  'restock':         '🏪 Restock',
  'credit-redeem':   '💳 Credit Redeem',
};

export async function sendTicketLog(opts: {
  client: Client;
  guildId: string;
  state: TicketState;
  channelId: string;
  channelName: string;
  closedBy: string;      // display tag e.g. "Username#0000"
  closeReason: string;   // e.g. "Closed by staff", "0 invites detected", "Ticket expired"
}): Promise<void> {
  const { client, guildId, state, channelId, channelName, closedBy, closeReason } = opts;

  const logChannelId = getGuildConfig(guildId).logChannelId;
  if (!logChannelId) return; // not configured — admin needs to run /setup log-channel

  try {
    const logChannel = await client.channels.fetch(logChannelId) as TextChannel | null;
    if (!logChannel?.isTextBased()) {
      logger.warn({ guildId, channelId: logChannelId }, 'Ticket log channel not found');
      return;
    }

    const now      = new Date();
    const duration = Math.floor((now.getTime() - state.createdAt.getTime()) / 1_000);
    const mins     = Math.floor(duration / 60);
    const secs     = duration % 60;
    const durationStr = mins > 0 ? `${mins}m ${secs}s` : `${secs}s`;

    const typeLabel = TICKET_TYPE_LABELS[state.ticketType] ?? state.ticketType;

    const fields = [
      { name: 'Channel', value: `\`${channelName}\``, inline: true },
      { name: 'Type',    value: typeLabel,             inline: true },
      { name: 'Owner',   value: `<@${state.ownerId}>`, inline: true },
    ];

    if (state.robloxUsername) {
      fields.push({ name: 'Roblox Username', value: `\`${state.robloxUsername}\``, inline: true });
    }

    if (state.claimedBy) {
      fields.push({ name: 'Claimed By', value: `<@${state.claimedBy}>`, inline: true });
    }

    // Use autoDetectedInvites (the verified invite count from Falcon Bot)
    if (state.autoDetectedInvites !== undefined) {
      fields.push({ name: 'Verified Invites', value: String(state.autoDetectedInvites), inline: true });
    }

    if (state.selectedReward) {
      fields.push({ name: 'Reward Selected', value: state.selectedReward, inline: true });
    }

    if (state.restockSubtype) {
      fields.push({ name: 'Restock Category', value: state.restockSubtype, inline: true });
    }

    fields.push(
      { name: 'Duration',     value: durationStr, inline: true },
      { name: 'Closed By',    value: closedBy,    inline: true },
      { name: 'Close Reason', value: closeReason, inline: false },
    );

    const color =
      closeReason.toLowerCase().includes('0 invite') ? COLORS.danger
      : closeReason.toLowerCase().includes('expired') ? COLORS.warning
      : COLORS.neutral;

    await logChannel.send({
      embeds: [
        buildEmbed({
          title:  '📋 Ticket Closed',
          description: `Ticket \`#${channelId.slice(-6)}\` has been closed.`,
          color,
          fields,
          footer: `Closed at ${now.toUTCString()}`,
        }),
      ],
    });
  } catch (err) {
    logger.error({ err }, 'Failed to send ticket log');
  }
}
