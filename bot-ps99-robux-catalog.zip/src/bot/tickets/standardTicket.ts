import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type GuildMember,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
} from 'discord.js';
import { createTicketChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { ticketStates } from '../state.js';
import { getGuildConfig } from '../config.js';
import { logger } from '../../lib/logger.js';

type StandardType = 'giveaway' | 'chat-rewards' | 'chest-rewards' | 'yapper-rewards';

interface StaticConfig {
  title: string;
  instructions: string;
  footerNote: string;
  needsRoblox: boolean;
}

const CONFIGS: Record<StandardType, StaticConfig> = {
  'giveaway': {
    title: '🎉 Giveaway Winner Ticket',
    instructions: [
      'Congratulations on winning! 🎊',
      '',
      'Please **upload a screenshot** proving you won the giveaway.',
      'The chat will remain locked until the Giveaway Hoster reviews your proof.',
      '',
      '> ⚠️ **Only image attachments are accepted.** Text messages will be deleted.',
    ].join('\n'),
    footerNote: 'Giveaway Hoster will review your ticket',
    needsRoblox: true,
  },
  'chat-rewards': {
    title: '💬 Chat Rewards Ticket',
    instructions: [
      'Thanks for being an active member! 🗨️',
      '',
      'Please **upload a screenshot** proving your chat activity / reward eligibility.',
      'The chat will remain locked until Ticket Staff reviews your proof.',
      '',
      '> ⚠️ **Only image attachments are accepted.** Text messages will be deleted.',
    ].join('\n'),
    footerNote: 'Ticket Staff will review your ticket',
    needsRoblox: true,
  },
  'chest-rewards': {
    title: '📦 Chest Rewards Ticket',
    instructions: [
      'Thanks for your Chest Rewards claim! 📦',
      '',
      'Please **upload a screenshot** proving your chest reward eligibility.',
      'The chat will remain locked until Ticket Staff reviews your proof.',
      '',
      '> ⚠️ **Only image attachments are accepted.** Text messages will be deleted.',
    ].join('\n'),
    footerNote: 'Ticket Staff will review your ticket',
    needsRoblox: true,
  },
  'yapper-rewards': {
    title: '🗣️ Yapper Rewards Ticket',
    instructions: [
      "You've earned your Yapper rewards! 🎙️",
      '',
      'Please **upload a screenshot** proving your yapper status.',
      'The chat will remain locked until Ticket Staff reviews your proof.',
      '',
      '> ⚠️ **Only image attachments are accepted.** Text messages will be deleted.',
    ].join('\n'),
    footerNote: 'Ticket Staff will review your ticket',
    needsRoblox: false,
  },
};

const MODAL_ID: Record<StandardType, string> = {
  'giveaway':       'roblox_modal_giveaway',
  'chat-rewards':   'roblox_modal_chat',
  'chest-rewards':  'roblox_modal_chest',
  'yapper-rewards': '', // no modal
};

/** Show Roblox modal or create ticket directly (yapper) */
export async function openStandardTicket(
  interaction: ButtonInteraction,
  type: StandardType,
): Promise<void> {
  const config = CONFIGS[type]!;

  if (config.needsRoblox) {
    const modal = new ModalBuilder()
      .setCustomId(MODAL_ID[type])
      .setTitle(`${config.title} — Roblox Username`);
    modal.addComponents(
      new ActionRowBuilder<TextInputBuilder>().addComponents(
        new TextInputBuilder()
          .setCustomId('roblox_username')
          .setLabel('What is your Roblox username?')
          .setStyle(TextInputStyle.Short)
          .setPlaceholder('e.g. CoolPlayer123')
          .setRequired(true)
          .setMaxLength(50),
      ),
    );
    await interaction.showModal(modal);
  } else {
    // Yapper — no Roblox username needed, create directly
    await createStandardTicket(interaction, type, undefined);
  }
}

/** Called after modal submit (giveaway/chat/chest) or directly (yapper) */
export async function handleStandardModalSubmit(
  interaction: ModalSubmitInteraction,
  type: StandardType,
): Promise<void> {
  const robloxUsername = interaction.fields.getTextInputValue('roblox_username').trim();
  await createStandardTicket(interaction, type, robloxUsername);
}

async function createStandardTicket(
  interaction: ButtonInteraction | ModalSubmitInteraction,
  type: StandardType,
  robloxUsername: string | undefined,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild  = interaction.guild!;
  const member = interaction.member as GuildMember;
  const config = CONFIGS[type]!;

  const guildConfig = getGuildConfig(guild.id);
  const staffRoleId = guildConfig.staffRoleId;
  const pingRoleId  = type === 'giveaway' ? guildConfig.giveawayHosterRoleId : guildConfig.staffRoleId;
  const categoryId  = guildConfig.categories[type];

  if (!staffRoleId || !pingRoleId) {
    await interaction.editReply({
      content: '❌ This server hasn\'t been set up yet. Ask an admin to run `/setup staff-role` (and `/setup giveaway-role` for giveaway tickets).',
    });
    return;
  }

  const extraRoleId = type === 'giveaway' ? guildConfig.giveawayHosterRoleId : undefined;

  try {
    const channel = await createTicketChannel({
      guild,
      member,
      ticketType: type,
      staffRoleId,
      categoryId,
      extraRoleId,
    });

    ticketStates.set(channel.id, {
      ticketType:    type,
      ownerId:       member.id,
      ownerUsername: member.user.username,
      createdAt:     new Date(),
      robloxUsername,
    });

    // Initial ping of the responsible role
    await channel.send(`<@&${pingRoleId}>`);

    const descLines = [`Welcome, <@${member.id}>!`];
    if (robloxUsername) {
      descLines.push('', `**Roblox Username:** \`${robloxUsername}\``);
    }
    descLines.push('', config.instructions);

    await channel.send({
      embeds: [
        buildEmbed({
          title:       config.title,
          description: descLines.join('\n'),
          color:       COLORS.primary,
          footer:      config.footerNote,
        }),
      ],
      components: [buildTicketControls(true)],
    });

    await interaction.editReply({ content: `✅ Ticket created: ${channel}` });
  } catch (err) {
    logger.error({ err }, `Failed to create ${type} ticket`);
    await interaction.editReply({
      content: '❌ Failed to create ticket. Please contact a staff member.',
    });
  }
}
