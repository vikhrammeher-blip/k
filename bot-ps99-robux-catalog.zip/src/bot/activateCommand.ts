import {
  type ChatInputCommandInteraction,
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits,
} from 'discord.js';
import {
  getChatRewardsConfig,
  updateChatRewardsConfig,
  addExcludedChannel,
  removeExcludedChannel,
} from './config.js';
import { buildEmbed, COLORS } from './utils/embeds.js';

export function buildActivateCommand() {
  return new SlashCommandBuilder()
    .setName('activate')
    .setDescription('Configure and enable the chat rewards credit system for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand((sub) => sub.setName('enable').setDescription('Turn on chat rewards for this server'))
    .addSubcommand((sub) => sub.setName('disable').setDescription('Turn off chat rewards for this server (balances are kept)'))
    .addSubcommand((sub) =>
      sub
        .setName('daily-amount')
        .setDescription('Set how many credits the daily claim (/credits daily) gives')
        .addIntegerOption((opt) =>
          opt.setName('amount').setDescription('Credits per daily claim').setRequired(true).setMinValue(1),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('message-range')
        .setDescription('Set the min/max credits earned per qualifying message')
        .addIntegerOption((opt) =>
          opt.setName('min').setDescription('Minimum credits per message').setRequired(true).setMinValue(0),
        )
        .addIntegerOption((opt) =>
          opt.setName('max').setDescription('Maximum credits per message').setRequired(true).setMinValue(0),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('cooldown')
        .setDescription('Set the cooldown (seconds) between messages that earn a member credits')
        .addIntegerOption((opt) =>
          opt.setName('seconds').setDescription('Cooldown in seconds').setRequired(true).setMinValue(1),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('staff-role')
        .setDescription('Set the role pinged on redeem tickets and allowed to give/take credits')
        .addRoleOption((opt) => opt.setName('role').setDescription('Chat rewards staff role').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('log-channel')
        .setDescription('Set the channel where daily claims and credit adjustments are logged')
        .addChannelOption((opt) =>
          opt
            .setName('channel')
            .setDescription('Chat rewards log channel')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('exclude-channel')
        .setDescription('Stop messages in a channel from earning chat credits')
        .addChannelOption((opt) => opt.setName('channel').setDescription('Channel to exclude').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('include-channel')
        .setDescription('Allow a previously-excluded channel to earn chat credits again')
        .addChannelOption((opt) => opt.setName('channel').setDescription('Channel to re-include').setRequired(true)),
    )
    .addSubcommand((sub) => sub.setName('drop-enable').setDescription('Turn on the chat drop system (random bonus credits from chatting)'))
    .addSubcommand((sub) => sub.setName('drop-disable').setDescription('Turn off the chat drop system'))
    .addSubcommand((sub) =>
      sub
        .setName('drop-chance')
        .setDescription('Set the % chance a qualifying message triggers a chat drop')
        .addNumberOption((opt) =>
          opt.setName('percent').setDescription('Chance out of 100, e.g. 2 for 2%').setRequired(true).setMinValue(0).setMaxValue(100),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('drop-range')
        .setDescription('Set the min/max bonus credits a chat drop awards')
        .addIntegerOption((opt) =>
          opt.setName('min').setDescription('Minimum credits per drop').setRequired(true).setMinValue(1),
        )
        .addIntegerOption((opt) =>
          opt.setName('max').setDescription('Maximum credits per drop').setRequired(true).setMinValue(1),
        ),
    )
    .addSubcommand((sub) => sub.setName('status').setDescription('View the current chat rewards configuration'))
    .toJSON();
}

export async function handleActivateCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const sub = interaction.options.getSubcommand();

  if (sub === 'enable') {
    updateChatRewardsConfig(guildId, { enabled: true });
    await interaction.reply({
      content:
        '✅ Chat rewards is now **enabled**. Members earn credits by chatting and can claim a daily bonus with `/credits daily`. ' +
        'Set a staff role (`/activate staff-role`) and log channel (`/activate log-channel`) if you haven\'t yet.',
      ephemeral: true,
    });
    return;
  }

  if (sub === 'disable') {
    updateChatRewardsConfig(guildId, { enabled: false });
    await interaction.reply({ content: '✅ Chat rewards is now **disabled**. Existing balances are kept.', ephemeral: true });
    return;
  }

  if (sub === 'daily-amount') {
    const amount = interaction.options.getInteger('amount', true);
    updateChatRewardsConfig(guildId, { dailyAmount: amount });
    await interaction.reply({ content: `✅ Daily claim amount set to **${amount}** credits.`, ephemeral: true });
    return;
  }

  if (sub === 'message-range') {
    const min = interaction.options.getInteger('min', true);
    const max = interaction.options.getInteger('max', true);
    if (min > max) {
      await interaction.reply({ content: '❌ Minimum cannot be greater than maximum.', ephemeral: true });
      return;
    }
    updateChatRewardsConfig(guildId, { messageMin: min, messageMax: max });
    await interaction.reply({ content: `✅ Messages will now earn **${min}–${max}** credits each.`, ephemeral: true });
    return;
  }

  if (sub === 'cooldown') {
    const seconds = interaction.options.getInteger('seconds', true);
    updateChatRewardsConfig(guildId, { cooldownSeconds: seconds });
    await interaction.reply({ content: `✅ Message earn cooldown set to **${seconds}s** per member.`, ephemeral: true });
    return;
  }

  if (sub === 'staff-role') {
    const role = interaction.options.getRole('role', true);
    updateChatRewardsConfig(guildId, { staffRoleId: role.id });
    await interaction.reply({ content: `✅ Chat rewards staff role set to <@&${role.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'log-channel') {
    const channel = interaction.options.getChannel('channel', true);
    updateChatRewardsConfig(guildId, { logChannelId: channel.id });
    await interaction.reply({ content: `✅ Chat rewards log channel set to <#${channel.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'exclude-channel') {
    const channel = interaction.options.getChannel('channel', true);
    addExcludedChannel(guildId, channel.id);
    await interaction.reply({ content: `✅ <#${channel.id}> will no longer earn chat credits.`, ephemeral: true });
    return;
  }

  if (sub === 'include-channel') {
    const channel = interaction.options.getChannel('channel', true);
    removeExcludedChannel(guildId, channel.id);
    await interaction.reply({ content: `✅ <#${channel.id}> can earn chat credits again.`, ephemeral: true });
    return;
  }

  if (sub === 'drop-enable') {
    updateChatRewardsConfig(guildId, { dropEnabled: true });
    await interaction.reply({
      content: `✅ Chat drops are now **enabled**. Qualifying messages have a **${getChatRewardsConfig(guildId).dropChancePercent}%** chance to award a bonus **${getChatRewardsConfig(guildId).dropMin}–${getChatRewardsConfig(guildId).dropMax}** credits.`,
      ephemeral: true,
    });
    return;
  }

  if (sub === 'drop-disable') {
    updateChatRewardsConfig(guildId, { dropEnabled: false });
    await interaction.reply({ content: '✅ Chat drops are now **disabled**.', ephemeral: true });
    return;
  }

  if (sub === 'drop-chance') {
    const percent = interaction.options.getNumber('percent', true);
    updateChatRewardsConfig(guildId, { dropChancePercent: percent });
    await interaction.reply({ content: `✅ Chat drop chance set to **${percent}%** per qualifying message.`, ephemeral: true });
    return;
  }

  if (sub === 'drop-range') {
    const min = interaction.options.getInteger('min', true);
    const max = interaction.options.getInteger('max', true);
    if (min > max) {
      await interaction.reply({ content: '❌ Minimum cannot be greater than maximum.', ephemeral: true });
      return;
    }
    updateChatRewardsConfig(guildId, { dropMin: min, dropMax: max });
    await interaction.reply({ content: `✅ Chat drops will now award **${min}–${max}** credits each.`, ephemeral: true });
    return;
  }

  if (sub === 'status') {
    const cfg = getChatRewardsConfig(guildId);
    const fields = [
      { name: 'Status',       value: cfg.enabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
      { name: 'Daily Claim',  value: `${cfg.dailyAmount} credits`, inline: true },
      { name: 'Per Message',  value: `${cfg.messageMin}–${cfg.messageMax} credits`, inline: true },
      { name: 'Cooldown',     value: `${cfg.cooldownSeconds}s`, inline: true },
      { name: 'Staff Role',   value: cfg.staffRoleId ? `<@&${cfg.staffRoleId}>` : '*Not set*', inline: true },
      { name: 'Log Channel',  value: cfg.logChannelId ? `<#${cfg.logChannelId}>` : '*Not set*', inline: true },
      {
        name: 'Excluded Channels',
        value: cfg.excludedChannelIds.length ? cfg.excludedChannelIds.map((id) => `<#${id}>`).join(', ') : '*None*',
        inline: false,
      },
      { name: 'Chat Drops',      value: cfg.dropEnabled ? '🟢 Enabled' : '🔴 Disabled', inline: true },
      { name: 'Drop Chance',     value: `${cfg.dropChancePercent}%`, inline: true },
      { name: 'Drop Range',      value: `${cfg.dropMin}–${cfg.dropMax} credits`, inline: true },
    ];

    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '💬 Chat Rewards Configuration',
          description: 'Current chat rewards settings for this server.',
          color: cfg.enabled ? COLORS.success : COLORS.neutral,
          fields,
        }),
      ],
      ephemeral: true,
    });
    return;
  }
}
