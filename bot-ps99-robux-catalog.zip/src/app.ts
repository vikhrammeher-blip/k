import path from "path";
import { fileURLToPath } from "url";
import { randomBytes } from "crypto";
import express, { type Express } from "express";
import cors from "cors";
import cookieParser from "cookie-parser";
import pinoHttp from "pino-http";
import router from "./routes/index.js";
import { logger } from "./lib/logger.js";
import { getSession, SESSION_COOKIE } from "./lib/session.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app: Express = express();

app.use(
  // pino-http's CJS export doesn't align perfectly with NodeNext ESM types
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  (pinoHttp as any)({
    logger,
    serializers: {
      req(req: { id: string; method: string; url?: string }) {
        return {
          id: req.id,
          method: req.method,
          url: req.url?.split("?")[0],
        };
      },
      res(res: { statusCode: number }) {
        return {
          statusCode: res.statusCode,
        };
      },
    },
  }),
);
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// SESSION_SECRET signs the session/state cookies. If it's not set we
// generate one at boot — dashboard sessions are in-memory anyway (see
// lib/session.ts), so they reset on redeploy regardless; a fixed secret
// only matters if you want logins to survive a process restart.
const sessionSecret = process.env["SESSION_SECRET"] ?? randomBytes(32).toString("hex");
app.use(cookieParser(sessionSecret));

// Attach the dashboard session (if any) to every request so downstream
// routes — the /api data endpoints — can require it. See routes/auth.ts
// for how a session gets created (Discord OAuth, admin-only).
app.use((req, _res, next) => {
  const sessionId = (req.signedCookies as Record<string, string> | undefined)?.[SESSION_COOKIE];
  req.dashboardSession = getSession(sessionId);
  next();
});

app.use("/api", router);

// Dashboard — static HTML/JS/CSS served from public/, copied next to the
// bundle at build time (see build.mjs). The shell itself is open (no
// ticket data in it); it calls /api/auth/me and shows a "Continue with
// Discord" button until the visitor is signed in as an admin of one of
// the bot's servers.
app.use(express.static(path.join(__dirname, "public")));

export default app;
