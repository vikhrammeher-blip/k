(() => {
  "use strict";

  const REFRESH_MS = 8000;

  // Canonical ticket lifecycle, in order. Real invite-reward tickets move
  // through most of these; other ticket types land on a fallback phase
  // ("awaiting_screenshot" or "open") reported by the /api/stats endpoint.
  const PHASES = [
    { key: "awaiting_command", label: "Seed", hint: "Waiting on .i" },
    { key: "awaiting_falcon_response", label: "Sprout", hint: "Waiting on Falcon" },
    { key: "awaiting_screenshot", label: "Rooting", hint: "Proof pending" },
    { key: "awaiting_screenshots", label: "Budding", hint: "Collecting proof" },
    { key: "awaiting_game_choice", label: "Flowering", hint: "Choosing game" },
    { key: "awaiting_reward", label: "Ripening", hint: "Picking reward" },
    { key: "reward_selected", label: "Harvested", hint: "Reward locked" },
    { key: "open", label: "Open", hint: "General support" },
  ];

  const TYPE_LABELS = {
    "invite-rewards": "Invite Rewards",
    "giveaway": "Giveaway",
    "chat-rewards": "Chat Rewards",
    "chest-rewards": "Chest Rewards",
    "yapper-rewards": "Yapper Rewards",
    "general-support": "General Support",
    "restock": "Restock",
    "credit-redeem": "Credit Redeem",
  };

  const AUTH_ERROR_MESSAGES = {
    state: "That sign-in link expired — try again.",
    forbidden: "That Discord account isn't an admin on any server this bot is in.",
    failed: "Something went wrong talking to Discord — try again.",
  };

  const $ = (sel) => document.querySelector(sel);
  const el = (tag, cls, text) => {
    const node = document.createElement(tag);
    if (cls) node.className = cls;
    if (text !== undefined) node.textContent = text;
    return node;
  };

  let allTickets = [];
  let pollTimer = null;
  let botCommandsLoaded = false;
  let adminGuilds = [];
  let isBotOwner = false;
  let currentSettingsGuildId = null;

  async function apiFetch(path, options) {
    const res = await fetch(`/api${path}`, options);
    if (res.status === 401) {
      const err = new Error("unauthorized");
      err.unauthorized = true;
      throw err;
    }
    if (!res.ok) {
      let message = `Request to ${path} failed (${res.status})`;
      try {
        const body = await res.json();
        if (body?.error) message = body.error;
      } catch {
        /* ignore non-JSON error bodies */
      }
      const err = new Error(message);
      err.status = res.status;
      throw err;
    }
    if (res.status === 204) return null;
    return res.json();
  }

  function apiSend(method, path, body) {
    return apiFetch(path, {
      method,
      headers: { "Content-Type": "application/json" },
      body: body !== undefined ? JSON.stringify(body) : undefined,
    });
  }

  function showAuthGate(show) {
    $("#authGate").hidden = !show;
    $("#app").hidden = show;
  }

  function relativeTime(iso) {
    const diffMs = Date.now() - new Date(iso).getTime();
    const mins = Math.round(diffMs / 60000);
    if (mins < 1) return "just now";
    if (mins < 60) return `${mins}m ago`;
    const hours = Math.round(mins / 60);
    if (hours < 24) return `${hours}h ago`;
    const days = Math.round(hours / 24);
    return `${days}d ago`;
  }

  function renderPipeline(byPhase) {
    const container = $("#pipeline");
    container.innerHTML = "";
    const counts = PHASES.map((p) => byPhase[p.key] ?? 0);
    const known = new Set(PHASES.map((p) => p.key));
    const extras = Object.keys(byPhase).filter((k) => !known.has(k));
    const stages = [...PHASES, ...extras.map((k) => ({ key: k, label: k, hint: "" }))];
    const allCounts = [...counts, ...extras.map((k) => byPhase[k])];
    const max = Math.max(1, ...allCounts);

    stages.forEach((stage, i) => {
      const count = allCounts[i] ?? 0;
      const pct = Math.round((count / max) * 100);
      const wrap = el("div", "stage" + (count === max && count > 0 ? " stage--peak" : ""));
      const countEl = el("div", "stage__count", String(count));
      const track = el("div", "stage__bar-track");
      const bar = el("div", "stage__bar");
      bar.style.height = count === 0 ? "3px" : `${Math.max(pct, 8)}%`;
      track.appendChild(bar);
      const label = el("div", "stage__label", stage.label);
      const key = el("div", "stage__key", stage.hint || stage.key);
      wrap.append(countEl, track, label, key);
      container.appendChild(wrap);
    });
  }

  function renderStatCards(stats, botStatus) {
    const container = $("#statCards");
    container.innerHTML = "";
    const cards = [
      { label: "Open tickets", value: stats.total, accent: true },
      { label: "Claimed", value: stats.claimedCount },
      { label: "Unclaimed", value: stats.unclaimedCount },
      { label: "Servers connected", value: botStatus.guildCount ?? 0 },
    ];
    for (const c of cards) {
      const card = el("div", "stat-card" + (c.accent ? " stat-card--accent" : ""));
      card.append(el("div", "stat-card__value", String(c.value)), el("div", "stat-card__label", c.label));
      container.appendChild(card);
    }
  }

  function renderTypeBars(byType) {
    const container = $("#typeBars");
    container.innerHTML = "";
    const entries = Object.entries(byType).sort((a, b) => b[1] - a[1]);
    const max = Math.max(1, ...entries.map(([, v]) => v));
    if (entries.length === 0) {
      container.appendChild(el("p", "empty-state", "No open tickets to break down yet."));
      return;
    }
    for (const [type, count] of entries) {
      const row = el("div", "type-bar");
      row.append(
        el("div", "type-bar__label", TYPE_LABELS[type] ?? type),
        (() => {
          const track = el("div", "type-bar__track");
          const fill = el("div", "type-bar__fill");
          fill.style.width = `${Math.round((count / max) * 100)}%`;
          track.appendChild(fill);
          return track;
        })(),
        el("div", "type-bar__count", String(count)),
      );
      container.appendChild(row);
    }
  }

  function populateTypeFilter(byType) {
    const select = $("#typeFilter");
    const current = select.value;
    const types = Object.keys(byType).sort();
    select.innerHTML = '<option value="">All types</option>';
    for (const t of types) {
      const opt = el("option", null, TYPE_LABELS[t] ?? t);
      opt.value = t;
      select.appendChild(opt);
    }
    if (types.includes(current)) select.value = current;
  }

  function renderTable() {
    const body = $("#ticketTableBody");
    const search = $("#searchInput").value.trim().toLowerCase();
    const typeFilter = $("#typeFilter").value;

    const filtered = allTickets.filter((t) => {
      if (typeFilter && t.ticketType !== typeFilter) return false;
      if (!search) return true;
      return (
        t.ownerUsername?.toLowerCase().includes(search) ||
        t.channelId?.toLowerCase().includes(search)
      );
    });

    body.innerHTML = "";
    $("#emptyState").hidden = filtered.length > 0;

    for (const t of filtered) {
      const tr = el("tr");

      const typeTd = el("td");
      typeTd.appendChild(el("span", "type-pill", TYPE_LABELS[t.ticketType] ?? t.ticketType));

      const ownerTd = el("td");
      const ownerWrap = el("div", "owner-cell");
      ownerWrap.append(
        el("div", "owner-cell__name", t.ownerUsername || "unknown"),
        el("div", "owner-cell__id mono", t.channelId),
      );
      ownerTd.appendChild(ownerWrap);

      const phaseTd = el("td");
      const phaseInfo = PHASES.find((p) => p.key === t.phase);
      phaseTd.appendChild(el("span", "phase-pill", phaseInfo ? phaseInfo.label : t.phase));

      const rewardTd = el("td", null, t.selectedReward || "—");

      const claimedTd = el("td");
      claimedTd.appendChild(
        t.claimedBy ? el("span", "claimed-yes", "Claimed") : el("span", "claimed-no", "Unclaimed"),
      );

      const timeTd = el("td", "time-cell", relativeTime(t.createdAt));

      tr.append(typeTd, ownerTd, phaseTd, rewardTd, claimedTd, timeTd);
      body.appendChild(tr);
    }
  }

  function renderGuilds(botStatus) {
    if (!isBotOwner) return;
    const container = $("#guildList");
    container.innerHTML = "";
    const guilds = botStatus.guilds ?? [];
    if (guilds.length === 0) {
      container.appendChild(el("p", "empty-state", "Not connected to any servers yet."));
      return;
    }
    for (const g of guilds) {
      const chip = el("div", "guild-chip");
      if (g.iconUrl) {
        const img = document.createElement("img");
        img.src = g.iconUrl;
        img.alt = "";
        img.className = "guild-chip__icon";
        chip.appendChild(img);
      } else {
        chip.appendChild(el("span", "guild-chip__dot"));
      }
      chip.append(
        el("span", null, g.name),
        el("span", "guild-chip__count mono", g.memberCount != null ? `${g.memberCount}` : ""),
      );
      if (g.joinedAt) {
        chip.title = `Joined ${new Date(g.joinedAt).toLocaleDateString()} · ID ${g.id}`;
      }
      container.appendChild(chip);
    }
  }

  // ── Bot commands catalog ────────────────────────────────────────────────
  // Fetched once (not on every poll cycle) since the command list only
  // changes on a bot redeploy — see the botCommandsLoaded guard in refresh().

  async function loadBotCommands() {
    if (!isBotOwner) return;
    try {
      const { commands } = await apiFetch("/bot-commands");
      renderBotCommands(commands);
    } catch (err) {
      console.error("Failed to load bot commands", err);
    }
  }

  const DISCORD_SUBCOMMAND_TYPE = 1;

  function renderBotCommands(commands) {
    const container = $("#botCommandsList");
    if (!container) return;
    container.innerHTML = "";
    if (!commands || commands.length === 0) {
      container.appendChild(el("p", "empty-state", "No commands registered."));
      return;
    }

    for (const cmd of [...commands].sort((a, b) => a.name.localeCompare(b.name))) {
      const adminOnly = cmd.default_member_permissions != null;
      const subcommands = (cmd.options ?? []).filter((o) => o.type === DISCORD_SUBCOMMAND_TYPE);

      const entries = subcommands.length > 0
        ? subcommands.map((sub) => ({ label: `/${cmd.name} ${sub.name}`, description: sub.description }))
        : [{ label: `/${cmd.name}`, description: cmd.description }];

      for (const entry of entries) {
        const row = el("div", "settings-list-row");
        const main = el("div", "settings-list-row__main");
        main.append(
          el("div", "settings-list-row__title mono", entry.label),
          el("div", "settings-list-row__sub", entry.description || ""),
        );
        row.appendChild(main);
        if (adminOnly) {
          row.appendChild(el("span", "type-pill", "Admin only"));
        }
        container.appendChild(row);
      }
    }
  }

  function renderTopbar(botStatus) {
    const dot = $("#statusDot");
    const label = $("#statusLabel");
    dot.className = "status-dot " + (botStatus.online ? "status-dot--online" : "status-dot--offline");
    label.textContent = botStatus.online ? "Online" : "Offline";
    $("#guildCount").textContent = `${botStatus.guildCount ?? 0} server${botStatus.guildCount === 1 ? "" : "s"}`;
    $("#uptime").textContent = formatUptime(botStatus.uptime);
    $("#offlineBanner").hidden = botStatus.online;
  }

  function formatUptime(ms) {
    if (ms == null) return "uptime unknown";
    const totalMin = Math.floor(ms / 60000);
    const h = Math.floor(totalMin / 60);
    const m = totalMin % 60;
    if (h === 0) return `up ${m}m`;
    return `up ${h}h ${m}m`;
  }

  function renderUserChip(me) {
    const chip = $("#userChip");
    if (!me.loggedIn) {
      chip.hidden = true;
      return;
    }
    chip.hidden = false;
    const guildName = me.adminGuilds?.[0]?.name;
    $("#userName").textContent = guildName ? `${me.username} · ${guildName}` : me.username;
  }

  async function checkAuth() {
    const me = await apiFetch("/auth/me").catch(() => ({ loggedIn: false, configured: true }));
    renderUserChip(me);
    if (!me.loggedIn) {
      showAuthGate(true);
      if (!me.configured) {
        $("#authGateCopy").textContent =
          "Discord login isn't configured on this deployment yet — set DISCORD_CLIENT_ID, DISCORD_CLIENT_SECRET, and DASHBOARD_PUBLIC_URL.";
        $("#loginBtn").style.display = "none";
      }
      return false;
    }
    adminGuilds = me.adminGuilds ?? [];
    isBotOwner = me.isOwner === true;
    $("#guildPanel").hidden = !isBotOwner;
    $("#botCommandsPanel").hidden = !isBotOwner;
    populateSettingsGuildSelect();
    return true;
  }

  function showAuthErrorFromUrl() {
    const params = new URLSearchParams(window.location.search);
    const code = params.get("authError");
    if (code) {
      const box = $("#authGateError");
      box.textContent = AUTH_ERROR_MESSAGES[code] ?? "Sign-in failed — try again.";
      box.hidden = false;
      window.history.replaceState({}, "", window.location.pathname);
    }
  }

  async function refresh(isManual) {
    const btn = $("#refreshBtn");
    if (isManual) btn.classList.add("spinning");
    try {
      const loggedIn = await checkAuth();
      if (!loggedIn) return;

      const [stats, tickets, botStatus] = await Promise.all([
        apiFetch("/stats"),
        apiFetch("/tickets"),
        apiFetch("/bot-status"),
      ]);

      showAuthGate(false);
      allTickets = tickets;

      renderTopbar(botStatus);
      renderPipeline(stats.byPhase);
      renderStatCards(stats, botStatus);
      renderTypeBars(stats.byType);
      populateTypeFilter(stats.byType);
      renderTable();
      renderGuilds(botStatus);

      if (!botCommandsLoaded) {
        botCommandsLoaded = true;
        loadBotCommands();
      }

      $("#lastRefreshed").textContent = `updated ${new Date().toLocaleTimeString()}`;
    } catch (err) {
      if (err.unauthorized) {
        showAuthGate(true);
      } else {
        $("#lastRefreshed").textContent = "refresh failed — retrying…";
        console.error(err);
      }
    } finally {
      if (isManual) setTimeout(() => btn.classList.remove("spinning"), 400);
    }
  }

  function startPolling() {
    if (pollTimer) clearInterval(pollTimer);
    pollTimer = setInterval(() => refresh(false), REFRESH_MS);
  }

  // ── View switching (Overview / Settings) ──────────────────────────────

  function switchView(view) {
    $("#overviewView").hidden = view !== "overview";
    $("#settingsView").hidden = view !== "settings";
    for (const btn of document.querySelectorAll("#viewTabs .view-tab")) {
      btn.classList.toggle("view-tab--active", btn.dataset.view === view);
    }
    if (view === "settings" && currentSettingsGuildId) {
      loadSettingsForGuild(currentSettingsGuildId);
    }
  }

  function switchSettingsTab(tab) {
    for (const pane of document.querySelectorAll('[id^="settingsPane-"]')) {
      pane.hidden = pane.id !== `settingsPane-${tab}`;
    }
    for (const btn of document.querySelectorAll("#settingsTabs .view-tab")) {
      btn.classList.toggle("view-tab--active", btn.dataset.settingsTab === tab);
    }
  }

  // ── Settings: guild picker ─────────────────────────────────────────────

  function populateSettingsGuildSelect() {
    const select = $("#settingsGuildSelect");
    const current = select.value;
    select.innerHTML = "";
    for (const g of adminGuilds) {
      const opt = el("option", null, g.name);
      opt.value = g.id;
      select.appendChild(opt);
    }
    const next = adminGuilds.some((g) => g.id === current) ? current : adminGuilds[0]?.id;
    if (next) {
      select.value = next;
      currentSettingsGuildId = next;
    }
  }

  function fillSelect(select, options, placeholder) {
    const current = select.value;
    select.innerHTML = "";
    const empty = el("option", null, placeholder);
    empty.value = "";
    select.appendChild(empty);
    for (const o of options) {
      const opt = el("option", null, o.name);
      opt.value = o.id;
      select.appendChild(opt);
    }
    if (options.some((o) => o.id === current)) select.value = current;
  }

  async function loadSettingsForGuild(guildId) {
    currentSettingsGuildId = guildId;
    $("#setupSaveStatus").textContent = "";
    $("#chatRewardsSaveStatus").textContent = "";
    try {
      const [roles, channels, overview, commands, shop, rewards] = await Promise.all([
        apiFetch(`/settings/${guildId}/roles`),
        apiFetch(`/settings/${guildId}/channels`),
        apiFetch(`/settings/${guildId}/overview`),
        apiFetch(`/settings/${guildId}/custom-commands`),
        apiFetch(`/settings/${guildId}/shop`),
        apiFetch(`/rewards/${guildId}`),
      ]);

      for (const sel of document.querySelectorAll("[data-role-select]")) {
        fillSelect(sel, roles.roles, "— none —");
      }
      for (const sel of document.querySelectorAll("[data-channel-select]")) {
        fillSelect(sel, channels.textChannels, "— none —");
      }

      const cfg = overview.config;
      $("#setupStaffRole").value = cfg.staffRoleId ?? "";
      $("#setupGiveawayRole").value = cfg.giveawayHosterRoleId ?? "";
      $("#setupRestockRole").value = cfg.restockPingRoleId ?? "";
      $("#setupLogChannel").value = cfg.logChannelId ?? "";
      $("#setupRestockChannel").value = cfg.restockPanelChannelId ?? "";

      const missingEl = $("#settingsMissing");
      if (overview.missing.length > 0) {
        missingEl.hidden = false;
        missingEl.textContent = `${overview.missing.length} setup item(s) still missing on this server.`;
      } else {
        missingEl.hidden = true;
      }

      renderCategories(overview.ticketTypes, cfg.categories, channels.categories);
      renderCommands(commands.customCommands);
      renderChatRewards(overview.chatRewards, channels.textChannels);
      renderShop(shop.items);
      renderGames(rewards.games);
      renderRewards(rewards.rewards, rewards.games);
    } catch (err) {
      console.error("Failed to load settings", err);
    }
  }

  // ── General setup form ─────────────────────────────────────────────────

  async function handleSetupSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const body = {
      staffRoleId: $("#setupStaffRole").value || undefined,
      giveawayHosterRoleId: $("#setupGiveawayRole").value || undefined,
      restockPingRoleId: $("#setupRestockRole").value || undefined,
      logChannelId: $("#setupLogChannel").value || undefined,
      restockPanelChannelId: $("#setupRestockChannel").value || undefined,
    };
    try {
      await apiSend("PUT", `/settings/${guildId}/setup`, body);
      $("#setupSaveStatus").textContent = "Saved";
      setTimeout(() => ($("#setupSaveStatus").textContent = ""), 2500);
      loadSettingsForGuild(guildId);
    } catch (err) {
      $("#setupSaveStatus").textContent = `Error: ${err.message}`;
    }
  }

  // ── Categories ──────────────────────────────────────────────────────────

  function renderCategories(ticketTypes, categories, categoryChannels) {
    populateCategoryTypeSelect(ticketTypes);

    const container = $("#categoriesList");
    container.innerHTML = "";
    for (const type of ticketTypes) {
      const row = el("div", "settings-list-row");
      const main = el("div", "settings-list-row__main");
      main.append(el("div", "settings-list-row__title", TYPE_LABELS[type] ?? type));
      row.appendChild(main);

      const select = el("select");
      fillSelect(select, categoryChannels, "— not set —");
      select.value = categories[type] ?? "";
      select.addEventListener("change", async () => {
        if (!select.value) return;
        try {
          await apiSend("PUT", `/settings/${currentSettingsGuildId}/category`, {
            type,
            categoryId: select.value,
          });
        } catch (err) {
          console.error(err);
        }
      });
      const actions = el("div", "settings-list-row__actions");
      actions.appendChild(select);
      row.appendChild(actions);
      container.appendChild(row);
    }
  }

  function populateCategoryTypeSelect(ticketTypes) {
    const select = $("#newCategoryType");
    const current = select.value;
    select.innerHTML = "";
    const empty = el("option", null, "— don't assign —");
    empty.value = "";
    select.appendChild(empty);
    for (const type of ticketTypes) {
      const opt = el("option", null, TYPE_LABELS[type] ?? type);
      opt.value = type;
      select.appendChild(opt);
    }
    if (ticketTypes.includes(current)) select.value = current;
  }

  async function handleCreateCategorySubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const name = $("#newCategoryName").value.trim();
    if (!name) {
      $("#createCategoryStatus").textContent = "Name is required";
      return;
    }
    const body = {
      name,
      viewRoleId: $("#newCategoryViewRole").value || undefined,
      private: $("#newCategoryPrivate").checked,
      type: $("#newCategoryType").value || undefined,
    };
    $("#createCategoryStatus").textContent = "Creating…";
    try {
      await apiSend("POST", `/settings/${guildId}/create-category`, body);
      $("#createCategoryStatus").textContent = "Created";
      $("#newCategoryName").value = "";
      setTimeout(() => ($("#createCategoryStatus").textContent = ""), 2500);
      loadSettingsForGuild(guildId);
    } catch (err) {
      $("#createCategoryStatus").textContent = `Error: ${err.message}`;
    }
  }

  // ── Custom commands ─────────────────────────────────────────────────────

  function renderCommands(customCommands) {
    const container = $("#commandsList");
    container.innerHTML = "";
    const entries = Object.entries(customCommands ?? {});
    if (entries.length === 0) {
      container.appendChild(el("p", "empty-state", "No custom commands yet."));
      return;
    }
    for (const [trigger, cmd] of entries) {
      const row = el("div", "settings-list-row");
      const main = el("div", "settings-list-row__main");
      main.append(
        el("div", "settings-list-row__title", `!${trigger}`),
        el("div", "settings-list-row__sub", `→ ${cmd.template} (target: ${cmd.targetUserId})`),
      );
      row.appendChild(main);
      const actions = el("div", "settings-list-row__actions");
      const delBtn = el("button", "danger-btn", "Remove");
      delBtn.type = "button";
      delBtn.addEventListener("click", async () => {
        try {
          await apiSend("DELETE", `/settings/${currentSettingsGuildId}/custom-commands/${encodeURIComponent(trigger)}`);
          loadSettingsForGuild(currentSettingsGuildId);
        } catch (err) {
          console.error(err);
        }
      });
      actions.appendChild(delBtn);
      row.appendChild(actions);
      container.appendChild(row);
    }
  }

  async function handleCommandSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const trigger = $("#cmdTrigger").value.trim();
    const targetUserId = $("#cmdTargetId").value.trim();
    const template = $("#cmdTemplate").value.trim();
    if (!trigger || !targetUserId || !template) return;
    try {
      await apiSend("POST", `/settings/${guildId}/custom-commands`, { trigger, targetUserId, template });
      $("#commandForm").reset();
      loadSettingsForGuild(guildId);
    } catch (err) {
      console.error(err);
    }
  }

  // ── Chat rewards ────────────────────────────────────────────────────────

  function renderChatRewards(cr, textChannels) {
    $("#crEnabled").checked = Boolean(cr.enabled);
    $("#crDaily").value = cr.dailyAmount;
    $("#crMsgMin").value = cr.messageMin;
    $("#crMsgMax").value = cr.messageMax;
    $("#crCooldown").value = cr.cooldownSeconds;
    $("#crStaffRole").value = cr.staffRoleId ?? "";
    $("#crLogChannel").value = cr.logChannelId ?? "";
    $("#crDropEnabled").checked = Boolean(cr.dropEnabled);
    $("#crDropChance").value = cr.dropChancePercent;
    $("#crDropMin").value = cr.dropMin;
    $("#crDropMax").value = cr.dropMax;

    const list = $("#excludedChannelsList");
    list.innerHTML = "";
    const excluded = cr.excludedChannelIds ?? [];
    if (excluded.length === 0) {
      list.appendChild(el("p", "empty-state", "No excluded channels."));
    } else {
      for (const channelId of excluded) {
        const channel = textChannels.find((c) => c.id === channelId);
        const row = el("div", "settings-list-row");
        row.appendChild(el("div", "settings-list-row__title", channel ? `#${channel.name}` : channelId));
        const actions = el("div", "settings-list-row__actions");
        const delBtn = el("button", "danger-btn", "Remove");
        delBtn.type = "button";
        delBtn.addEventListener("click", async () => {
          try {
            await apiSend(
              "DELETE",
              `/settings/${currentSettingsGuildId}/chat-rewards/excluded-channels/${channelId}`,
            );
            loadSettingsForGuild(currentSettingsGuildId);
          } catch (err) {
            console.error(err);
          }
        });
        actions.appendChild(delBtn);
        row.appendChild(actions);
        list.appendChild(row);
      }
    }
  }

  async function handleChatRewardsSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const body = {
      enabled: $("#crEnabled").checked,
      dailyAmount: Number($("#crDaily").value),
      messageMin: Number($("#crMsgMin").value),
      messageMax: Number($("#crMsgMax").value),
      cooldownSeconds: Number($("#crCooldown").value),
      staffRoleId: $("#crStaffRole").value || undefined,
      logChannelId: $("#crLogChannel").value || undefined,
      dropEnabled: $("#crDropEnabled").checked,
      dropChancePercent: Number($("#crDropChance").value),
      dropMin: Number($("#crDropMin").value),
      dropMax: Number($("#crDropMax").value),
    };
    try {
      await apiSend("PUT", `/settings/${guildId}/chat-rewards`, body);
      $("#chatRewardsSaveStatus").textContent = "Saved";
      setTimeout(() => ($("#chatRewardsSaveStatus").textContent = ""), 2500);
    } catch (err) {
      $("#chatRewardsSaveStatus").textContent = `Error: ${err.message}`;
    }
  }

  async function handleExcludeChannelSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    const channelId = $("#excludeChannelSelect").value;
    if (!guildId || !channelId) return;
    try {
      await apiSend("POST", `/settings/${guildId}/chat-rewards/excluded-channels`, { channelId });
      loadSettingsForGuild(guildId);
    } catch (err) {
      console.error(err);
    }
  }

  // ── Shop ────────────────────────────────────────────────────────────────

  function renderShop(items) {
    const container = $("#shopList");
    container.innerHTML = "";
    if (items.length === 0) {
      container.appendChild(el("p", "empty-state", "No shop items yet."));
      return;
    }
    for (const item of items) {
      const row = el("div", "settings-list-row");
      const main = el("div", "settings-list-row__main");
      main.append(
        el("div", "settings-list-row__title", `${item.name} — ${item.price} credits`),
        el(
          "div",
          "settings-list-row__sub",
          `${item.description} · stock: ${item.stock === undefined ? "unlimited" : item.stock}`,
        ),
      );
      row.appendChild(main);
      const actions = el("div", "settings-list-row__actions");
      const delBtn = el("button", "danger-btn", "Remove");
      delBtn.type = "button";
      delBtn.addEventListener("click", async () => {
        try {
          await apiSend("DELETE", `/settings/${currentSettingsGuildId}/shop/${encodeURIComponent(item.name)}`);
          loadSettingsForGuild(currentSettingsGuildId);
        } catch (err) {
          console.error(err);
        }
      });
      actions.appendChild(delBtn);
      row.appendChild(actions);
      container.appendChild(row);
    }
  }

  async function handleShopSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const name = $("#shopName").value.trim();
    const price = Number($("#shopPrice").value);
    const description = $("#shopDescription").value.trim();
    const stockRaw = $("#shopStock").value;
    if (!name || !price || !description) return;
    try {
      await apiSend("POST", `/settings/${guildId}/shop`, {
        name,
        price,
        description,
        stock: stockRaw === "" ? undefined : Number(stockRaw),
      });
      $("#shopForm").reset();
      loadSettingsForGuild(guildId);
    } catch (err) {
      console.error(err);
    }
  }

  // ── Invite rewards catalog (per-server) ─────────────────────────────────

  let currentGames = [];

  function populateRewardGameSelect(games) {
    const select = $("#rewardGame");
    const current = select.value;
    select.innerHTML = "";
    for (const game of games) {
      const opt = el("option", null, `${game.emoji || "🎮"} ${game.label}`);
      opt.value = game.id;
      select.appendChild(opt);
    }
    if (games.some((g) => g.id === current)) select.value = current;
  }

  function renderGames(games) {
    currentGames = games;
    populateRewardGameSelect(games);

    const container = $("#gamesList");
    container.innerHTML = "";

    if (games.length === 0) {
      container.appendChild(el("p", "empty-state", "No games yet — add one below."));
      return;
    }

    for (const game of games) {
      const row = el("div", "settings-list-row");
      const main = el("div", "settings-list-row__main");
      main.append(
        el("div", "settings-list-row__title", `${game.emoji || "🎮"} ${game.label}`),
        el("div", "settings-list-row__sub", `id: ${game.id}`),
      );
      row.appendChild(main);
      const actions = el("div", "settings-list-row__actions");
      const delBtn = el("button", "danger-btn", "Remove");
      delBtn.type = "button";
      delBtn.addEventListener("click", async () => {
        try {
          await apiSend("DELETE", `/rewards/${currentSettingsGuildId}/games/${encodeURIComponent(game.id)}`);
          loadSettingsForGuild(currentSettingsGuildId);
        } catch (err) {
          console.error(err);
        }
      });
      actions.appendChild(delBtn);
      row.appendChild(actions);
      container.appendChild(row);
    }
  }

  async function handleGameSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const label = $("#gameLabel").value.trim();
    const emoji = $("#gameEmoji").value.trim();
    if (!label) return;
    try {
      await apiSend("POST", `/rewards/${guildId}/games`, { label, emoji });
      $("#gameForm").reset();
      loadSettingsForGuild(guildId);
    } catch (err) {
      console.error(err);
    }
  }

  function renderRewards(rewards, games) {
    const container = $("#rewardsList");
    container.innerHTML = "";

    const gameLabel = (gameId) => games.find((g) => g.id === gameId)?.label ?? gameId;

    // Group by game, then by category within each game — both are freeform
    // now, so this just reflects whatever grouping the admin actually used.
    const byGame = new Map();
    for (const r of rewards) {
      if (!byGame.has(r.gameId)) byGame.set(r.gameId, new Map());
      const byCategory = byGame.get(r.gameId);
      if (!byCategory.has(r.category)) byCategory.set(r.category, []);
      byCategory.get(r.category).push(r);
    }

    if (byGame.size === 0) {
      container.appendChild(el("p", "empty-state", "No rewards yet — add one below."));
      return;
    }

    for (const [gameId, byCategory] of byGame) {
      container.appendChild(el("p", "eyebrow", gameLabel(gameId)));
      for (const [category, items] of byCategory) {
        container.appendChild(el("div", "settings-list-row__sub mono", category));
        for (const reward of items) {
          const row = el("div", "settings-list-row");
          const main = el("div", "settings-list-row__main");
          main.append(
            el("div", "settings-list-row__title", reward.name),
            el("div", "settings-list-row__sub", `${reward.requiredInvites} invite(s) required · id: ${reward.id}`),
          );
          row.appendChild(main);
          const actions = el("div", "settings-list-row__actions");
          const delBtn = el("button", "danger-btn", "Remove");
          delBtn.type = "button";
          delBtn.addEventListener("click", async () => {
            try {
              await apiSend("DELETE", `/rewards/${currentSettingsGuildId}/${encodeURIComponent(reward.id)}`);
              loadSettingsForGuild(currentSettingsGuildId);
            } catch (err) {
              console.error(err);
            }
          });
          actions.appendChild(delBtn);
          row.appendChild(actions);
          container.appendChild(row);
        }
      }
    }
  }

  async function handleRewardSubmit(e) {
    e.preventDefault();
    const guildId = currentSettingsGuildId;
    if (!guildId) return;
    const name = $("#rewardName").value.trim();
    const gameId = $("#rewardGame").value;
    const category = $("#rewardCategory").value.trim() || "General";
    const requiredInvites = Number($("#rewardInvites").value);
    if (!name || !gameId || !requiredInvites) return;
    try {
      await apiSend("POST", `/rewards/${guildId}`, { name, category, gameId, requiredInvites });
      $("#rewardName").value = "";
      $("#rewardCategory").value = "";
      $("#rewardInvites").value = "";
      loadSettingsForGuild(guildId);
    } catch (err) {
      console.error(err);
    }
  }

  function initSettings() {
    $("#viewTabs").addEventListener("click", (e) => {
      const btn = e.target.closest(".view-tab");
      if (!btn) return;
      switchView(btn.dataset.view);
    });
    $("#settingsTabs").addEventListener("click", (e) => {
      const btn = e.target.closest(".view-tab");
      if (!btn) return;
      switchSettingsTab(btn.dataset.settingsTab);
    });
    $("#settingsGuildSelect").addEventListener("change", (e) => {
      loadSettingsForGuild(e.target.value);
    });
    $("#setupForm").addEventListener("submit", handleSetupSubmit);
    $("#createCategoryForm").addEventListener("submit", handleCreateCategorySubmit);
    $("#commandForm").addEventListener("submit", handleCommandSubmit);
    $("#chatRewardsForm").addEventListener("submit", handleChatRewardsSubmit);
    $("#excludeChannelForm").addEventListener("submit", handleExcludeChannelSubmit);
    $("#shopForm").addEventListener("submit", handleShopSubmit);
    $("#gameForm").addEventListener("submit", handleGameSubmit);
    $("#rewardForm").addEventListener("submit", handleRewardSubmit);
  }

  function init() {
    showAuthErrorFromUrl();

    $("#refreshBtn").addEventListener("click", () => refresh(true));
    $("#searchInput").addEventListener("input", renderTable);
    $("#typeFilter").addEventListener("change", renderTable);
    $("#logoutBtn").addEventListener("click", async () => {
      await fetch("/api/auth/logout", { method: "POST" });
      window.location.reload();
    });

    initSettings();

    refresh(false);
    startPolling();
  }

  document.addEventListener("DOMContentLoaded", init);
})();
