import {
  type Client,
  type TextChannel,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { getGuildConfig } from './config.js';
import { logger } from '../lib/logger.js';

/** Tracks the current restock panel message ID per guild so we can detect deletion */
const restockPanelMessageIds = new Map<string, string>();

function buildRestockPanel() {
  const embed = buildEmbed({
    title: '🏪 Restock Request Panel',
    description: [
      'Use the buttons below to open a restock request ticket.',
      'These tickets are for **staff members** to request stock for Invite Reward fulfilment.',
      '',
      '**⚙️ Gear Stock** — Request GAG gear items',
      '**🐶 Pet Stock** — Request GAG pet items',
      '**🌱 Seed Stock** — Request GAG seed items',
      '**📦 All GAG Stock** — Request all GAG items',
      '**🎮 PS99 Stock** — Request Pet Simulator 99 items',
    ].join('\n'),
    color: COLORS.warning,
    footer: 'Staff use only — restock handlers will be notified automatically',
  });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId('create_restock_gear')
      .setLabel('Gear Stock')
      .setEmoji('⚙️')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('create_restock_pets')
      .setLabel('Pet Stock')
      .setEmoji('🐶')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('create_restock_seeds')
      .setLabel('Seed Stock')
      .setEmoji('🌱')
      .setStyle(ButtonStyle.Secondary),
    new ButtonBuilder()
      .setCustomId('create_restock_all')
      .setLabel('All GAG Stock')
      .setEmoji('📦')
      .setStyle(ButtonStyle.Primary),
    new ButtonBuilder()
      .setCustomId('create_restock_ps99')
      .setLabel('PS99 Stock')
      .setEmoji('🎮')
      .setStyle(ButtonStyle.Primary),
  );

  return { embeds: [embed], components: [row] };
}

/** Posts (or re-uses) the restock panel for a single guild. No-op if not configured. */
export async function postRestockPanel(client: Client, guildId: string): Promise<void> {
  const channelId = getGuildConfig(guildId).restockPanelChannelId;
  if (!channelId) return; // not configured yet — admin needs to run /setup restock-panel-channel

  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (!channel || !channel.isTextBased()) {
      logger.warn({ guildId, channelId }, 'Restock panel channel not found or not a text channel');
      return;
    }

    // Check recent messages for an existing panel — scan up to 50 so we catch it
    // even if the channel has activity since the last bot restart.
    const recent = await channel.messages.fetch({ limit: 50 });
    const botPanels = recent.filter(
      m => m.author.id === client.user!.id && m.components.length > 0,
    );
    if (botPanels.size > 0) {
      // Keep the newest one, delete any extras so we never have duplicate panels.
      const sorted = [...botPanels.values()].sort(
        (a, b) => b.createdTimestamp - a.createdTimestamp,
      );
      restockPanelMessageIds.set(guildId, sorted[0]!.id);
      logger.info({ guildId, messageId: sorted[0]!.id }, 'Restock panel already present — tracking existing message');
      // Delete any duplicates beyond the first
      for (const extra of sorted.slice(1)) {
        await extra.delete().catch(() => {});
        logger.info({ guildId, messageId: extra.id }, 'Deleted duplicate restock panel');
      }
      return;
    }

    const msg = await channel.send(buildRestockPanel());
    restockPanelMessageIds.set(guildId, msg.id);
    logger.info({ guildId, messageId: msg.id }, 'Restock panel posted');
  } catch (err) {
    logger.error({ guildId, err }, 'Failed to post restock panel');
  }
}

/** Posts the restock panel for every guild that has one configured. Call once on startup. */
export async function postAllRestockPanels(client: Client): Promise<void> {
  for (const guild of client.guilds.cache.values()) {
    await postRestockPanel(client, guild.id);
  }
}

/**
 * Call this from the messageDelete event handler.
 * If the deleted message was a tracked restock panel, re-post it automatically.
 */
export async function handleRestockPanelDelete(
  client: Client,
  guildId: string,
  deletedMessageId: string,
): Promise<void> {
  if (restockPanelMessageIds.get(guildId) !== deletedMessageId) return;

  logger.info({ guildId, deletedMessageId }, 'Restock panel was deleted — re-posting automatically');
  restockPanelMessageIds.delete(guildId); // clear before re-posting so we don't double-track

  const channelId = getGuildConfig(guildId).restockPanelChannelId;
  if (!channelId) return;

  try {
    const channel = await client.channels.fetch(channelId) as TextChannel | null;
    if (!channel || !channel.isTextBased()) return;

    const msg = await channel.send(buildRestockPanel());
    restockPanelMessageIds.set(guildId, msg.id);
    logger.info({ guildId, messageId: msg.id }, 'Restock panel re-posted after deletion');
  } catch (err) {
    logger.error({ guildId, err }, 'Failed to re-post restock panel after deletion');
  }
}
