import { type ButtonInteraction, type GuildMember } from 'discord.js';
import { createTicketChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { ticketStates } from '../state.js';
import { getGuildConfig } from '../config.js';
import { logger } from '../../lib/logger.js';

export async function openGeneralSupportTicket(
  interaction: ButtonInteraction,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild  = interaction.guild!;
  const member = interaction.member as GuildMember;

  const guildConfig = getGuildConfig(guild.id);
  const staffRoleId = guildConfig.staffRoleId;
  const categoryId  = guildConfig.categories['general-support'];

  if (!staffRoleId) {
    await interaction.editReply({
      content: '❌ This server hasn\'t been set up yet. Ask an admin to run `/setup staff-role`.',
    });
    return;
  }

  try {
    const channel = await createTicketChannel({
      guild,
      member,
      ticketType: 'general-support',
      staffRoleId,
      categoryId,
    });

    ticketStates.set(channel.id, {
      ticketType:    'general-support',
      ownerId:       member.id,
      ownerUsername: member.user.username,
      createdAt:     new Date(),
    });

    await channel.send(`<@&${staffRoleId}>`);

    await channel.send({
      embeds: [
        buildEmbed({
          title: '🛠️ General Support Ticket',
          description: [
            `Welcome, <@${member.id}>! 👋`,
            '',
            'A member of our Ticket Staff team will be with you shortly.',
            '',
            'Please describe your issue or question in as much detail as possible.',
            'You can freely chat in this ticket — no restrictions apply here.',
          ].join('\n'),
          color: COLORS.info,
          footer: 'Please be patient while staff responds',
        }),
      ],
      // General Support has no Claim button, only Close
      components: [buildTicketControls(false)],
    });

    await interaction.editReply({ content: `✅ Ticket created: ${channel}` });
  } catch (err) {
    logger.error({ err }, 'Failed to create general support ticket');
    await interaction.editReply({
      content: '❌ Failed to create ticket. Please contact a staff member.',
    });
  }
}
