import { type ChatInputCommandInteraction, type GuildMember, SlashCommandBuilder } from 'discord.js';
import { getGuildConfig, getChatRewardsConfig } from './config.js';
import { getBalance, claimDaily, addCredits, removeCredits } from './chatCredits.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { logChatRewardsEvent } from './utils/ticketLog.js';

function isChatRewardsStaff(member: GuildMember): boolean {
  const guildCfg   = getGuildConfig(member.guild.id);
  const rewardsCfg = getChatRewardsConfig(member.guild.id);
  return (
    (!!guildCfg.staffRoleId && member.roles.cache.has(guildCfg.staffRoleId)) ||
    (!!rewardsCfg.staffRoleId && member.roles.cache.has(rewardsCfg.staffRoleId)) ||
    member.permissions.has('Administrator')
  );
}

export function buildCreditsCommand() {
  return new SlashCommandBuilder()
    .setName('credits')
    .setDescription('Chat rewards credits')
    .setDMPermission(false)
    .addSubcommand((sub) => sub.setName('daily').setDescription('Claim your daily chat rewards credits'))
    .addSubcommand((sub) =>
      sub
        .setName('balance')
        .setDescription('Check a chat rewards credit balance')
        .addUserOption((opt) => opt.setName('user').setDescription('Member to check (defaults to you)').setRequired(false)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('give')
        .setDescription('Add credits to a member\'s balance (Staff only)')
        .addUserOption((opt) => opt.setName('user').setDescription('Member').setRequired(true))
        .addIntegerOption((opt) => opt.setName('amount').setDescription('Amount to add').setRequired(true).setMinValue(1))
        .addStringOption((opt) => opt.setName('reason').setDescription('Reason').setRequired(false)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('take')
        .setDescription('Remove credits from a member\'s balance (Staff only)')
        .addUserOption((opt) => opt.setName('user').setDescription('Member').setRequired(true))
        .addIntegerOption((opt) => opt.setName('amount').setDescription('Amount to remove').setRequired(true).setMinValue(1))
        .addStringOption((opt) => opt.setName('reason').setDescription('Reason').setRequired(false)),
    )
    .toJSON();
}

export async function handleCreditsCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId || !interaction.guild) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const sub        = interaction.options.getSubcommand();
  const rewardsCfg = getChatRewardsConfig(guildId);

  if (!rewardsCfg.enabled && sub !== 'balance') {
    await interaction.reply({
      content: '❌ Chat rewards isn\'t enabled on this server yet. Ask an admin to run `/activate enable`.',
      ephemeral: true,
    });
    return;
  }

  if (sub === 'daily') {
    const result = claimDaily(guildId, interaction.user.id, rewardsCfg.dailyAmount);
    if (!result.ok) {
      const hours = Math.ceil((result.msRemaining ?? 0) / (60 * 60 * 1000));
      await interaction.reply({
        content: `⏳ You've already claimed today. Try again in about **${hours}h**.`,
        ephemeral: true,
      });
      return;
    }
    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '💰 Daily Credits Claimed',
          description: `You claimed **${result.amount}** credits!\nNew balance: **${result.balance}**`,
          color: COLORS.success,
        }),
      ],
      ephemeral: true,
    });
    await logChatRewardsEvent(
      interaction.client,
      guildId,
      `💰 <@${interaction.user.id}> claimed their daily **${result.amount}** credits. New balance: **${result.balance}**.`,
    );
    return;
  }

  if (sub === 'balance') {
    const target  = interaction.options.getUser('user') ?? interaction.user;
    const balance = getBalance(guildId, target.id);
    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '💳 Chat Rewards Balance',
          description: `<@${target.id}> has **${balance}** credits.`,
          color: COLORS.info,
        }),
      ],
      ephemeral: true,
    });
    return;
  }

  const member = interaction.member as GuildMember;
  if ((sub === 'give' || sub === 'take') && !isChatRewardsStaff(member)) {
    await interaction.reply({ content: '❌ Only Chat Rewards staff can adjust balances.', ephemeral: true });
    return;
  }

  if (sub === 'give') {
    const target = interaction.options.getUser('user', true);
    const amount = interaction.options.getInteger('amount', true);
    const reason = interaction.options.getString('reason') ?? 'No reason given';
    const balance = addCredits(guildId, target.id, amount);
    await interaction.reply({
      content: `✅ Gave **${amount}** credits to <@${target.id}>. New balance: **${balance}**.`,
      ephemeral: true,
    });
    await logChatRewardsEvent(
      interaction.client,
      guildId,
      `➕ <@${interaction.user.id}> gave **${amount}** credits to <@${target.id}> (${reason}). New balance: **${balance}**.`,
    );
    return;
  }

  if (sub === 'take') {
    const target = interaction.options.getUser('user', true);
    const amount = interaction.options.getInteger('amount', true);
    const reason = interaction.options.getString('reason') ?? 'No reason given';
    const result = removeCredits(guildId, target.id, amount);
    if (!result.ok) {
      await interaction.reply({
        content: `❌ <@${target.id}> only has **${result.balance}** credits — can't remove ${amount}.`,
        ephemeral: true,
      });
      return;
    }
    await interaction.reply({
      content: `✅ Removed **${amount}** credits from <@${target.id}>. New balance: **${result.balance}**.`,
      ephemeral: true,
    });
    await logChatRewardsEvent(
      interaction.client,
      guildId,
      `➖ <@${interaction.user.id}> removed **${amount}** credits from <@${target.id}> (${reason}). New balance: **${result.balance}**.`,
    );
    return;
  }
}
