import {
  type ChatInputCommandInteraction,
  SlashCommandBuilder,
  ChannelType,
  PermissionFlagsBits,
} from 'discord.js';
import { updateGuildConfig, setGuildCategory, getGuildConfig, getMissingSetupItems } from './config.js';
import { buildEmbed, COLORS } from './utils/embeds.js';
import { postRestockPanel } from './restockPanel.js';
import type { TicketType } from './state.js';
import { logger } from '../lib/logger.js';

const TICKET_TYPE_CHOICES: { name: string; value: TicketType }[] = [
  { name: 'Invite Rewards',  value: 'invite-rewards' },
  { name: 'Giveaway',        value: 'giveaway' },
  { name: 'Chat Rewards',    value: 'chat-rewards' },
  { name: 'Chest Rewards',   value: 'chest-rewards' },
  { name: 'Yapper Rewards',  value: 'yapper-rewards' },
  { name: 'General Support', value: 'general-support' },
  { name: 'Restock',         value: 'restock' },
  { name: 'Credit Redeem',   value: 'credit-redeem' },
];

export function buildSetupCommand() {
  return new SlashCommandBuilder()
    .setName('setup')
    .setDescription('Configure the ticket bot for this server')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addSubcommand((sub) =>
      sub
        .setName('staff-role')
        .setDescription('Set the Ticket Staff role')
        .addRoleOption((opt) => opt.setName('role').setDescription('Ticket Staff role').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('giveaway-role')
        .setDescription('Set the Giveaway Hoster role')
        .addRoleOption((opt) => opt.setName('role').setDescription('Giveaway Hoster role').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('restock-ping-role')
        .setDescription('Set the role pinged when a restock ticket opens')
        .addRoleOption((opt) => opt.setName('role').setDescription('Restock ping role').setRequired(true)),
    )
    .addSubcommand((sub) =>
      sub
        .setName('log-channel')
        .setDescription('Set the channel where closed-ticket logs are posted')
        .addChannelOption((opt) =>
          opt
            .setName('channel')
            .setDescription('Ticket log channel')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('restock-panel-channel')
        .setDescription('Set the channel where the restock request panel is posted')
        .addChannelOption((opt) =>
          opt
            .setName('channel')
            .setDescription('Restock panel channel')
            .addChannelTypes(ChannelType.GuildText)
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) =>
      sub
        .setName('category')
        .setDescription('Set the parent category new tickets of a given type are created under')
        .addStringOption((opt) => {
          opt.setName('type').setDescription('Ticket type').setRequired(true);
          for (const c of TICKET_TYPE_CHOICES) opt.addChoices(c);
          return opt;
        })
        .addChannelOption((opt) =>
          opt
            .setName('category')
            .setDescription('Category channel to place these tickets under')
            .addChannelTypes(ChannelType.GuildCategory)
            .setRequired(true),
        ),
    )
    .addSubcommand((sub) => sub.setName('view').setDescription('View the current configuration'))
    .toJSON();
}

export async function handleSetupCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guildId = interaction.guildId;
  if (!guildId) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const sub = interaction.options.getSubcommand();

  if (sub === 'staff-role') {
    const role = interaction.options.getRole('role', true);
    updateGuildConfig(guildId, { staffRoleId: role.id });
    await interaction.reply({ content: `✅ Ticket Staff role set to <@&${role.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'giveaway-role') {
    const role = interaction.options.getRole('role', true);
    updateGuildConfig(guildId, { giveawayHosterRoleId: role.id });
    await interaction.reply({ content: `✅ Giveaway Hoster role set to <@&${role.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'restock-ping-role') {
    const role = interaction.options.getRole('role', true);
    updateGuildConfig(guildId, { restockPingRoleId: role.id });
    await interaction.reply({ content: `✅ Restock ping role set to <@&${role.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'log-channel') {
    const channel = interaction.options.getChannel('channel', true);
    updateGuildConfig(guildId, { logChannelId: channel.id });
    await interaction.reply({ content: `✅ Ticket log channel set to <#${channel.id}>.`, ephemeral: true });
    return;
  }

  if (sub === 'restock-panel-channel') {
    const channel = interaction.options.getChannel('channel', true);
    updateGuildConfig(guildId, { restockPanelChannelId: channel.id });
    await interaction.reply({ content: `✅ Restock panel channel set to <#${channel.id}>. Posting panel…`, ephemeral: true });
    await postRestockPanel(interaction.client, guildId).catch(() => {});
    return;
  }

  if (sub === 'category') {
    const type     = interaction.options.getString('type', true) as TicketType;
    const category = interaction.options.getChannel('category', true);
    setGuildCategory(guildId, type, category.id);
    await interaction.reply({
      content: `✅ Tickets of type **${type}** will now be created under <#${category.id}>.`,
      ephemeral: true,
    });
    return;
  }

  if (sub === 'view') {
    const cfg     = getGuildConfig(guildId);
    const missing = getMissingSetupItems(guildId);

    const fields = [
      { name: 'Staff Role',            value: cfg.staffRoleId ? `<@&${cfg.staffRoleId}>` : '*Not set*', inline: true },
      { name: 'Giveaway Hoster Role',  value: cfg.giveawayHosterRoleId ? `<@&${cfg.giveawayHosterRoleId}>` : '*Not set*', inline: true },
      { name: 'Restock Ping Role',     value: cfg.restockPingRoleId ? `<@&${cfg.restockPingRoleId}>` : '*Not set*', inline: true },
      { name: 'Log Channel',           value: cfg.logChannelId ? `<#${cfg.logChannelId}>` : '*Not set*', inline: true },
      { name: 'Restock Panel Channel', value: cfg.restockPanelChannelId ? `<#${cfg.restockPanelChannelId}>` : '*Not set*', inline: true },
      {
        name: 'Categories',
        value:
          TICKET_TYPE_CHOICES.map(
            (c) => `${c.name}: ${cfg.categories[c.value] ? `<#${cfg.categories[c.value]}>` : '*Not set*'}`,
          ).join('\n') || '*None set*',
        inline: false,
      },
    ];

    await interaction.reply({
      embeds: [
        buildEmbed({
          title: '⚙️ Ticket Bot Configuration',
          description:
            missing.length === 0
              ? '✅ Fully configured!'
              : `⚠️ **${missing.length} item(s) still need setup:**\n${missing.map((m) => `• ${m}`).join('\n')}`,
          color: missing.length === 0 ? COLORS.success : COLORS.warning,
          fields,
        }),
      ],
      ephemeral: true,
    });
    return;
  }
}
