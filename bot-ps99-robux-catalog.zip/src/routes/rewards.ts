import { Router, type NextFunction, type Request, type Response } from "express";
import { getRewards, addReward, editReward, removeReward } from "../bot/data/rewards.js";
import { getGames, addGame, editGame, removeGame } from "../bot/data/inviteGames.js";

const router = Router();

// Every route below requires a logged-in Discord admin session AND that the
// session's admin lists this exact guild — same pattern as /settings/:guildId/*,
// so a user can only add/edit/remove rewards for servers they actually admin.
function requireGuildAdmin(req: Request, res: Response, next: NextFunction): void {
  const session = req.dashboardSession;
  if (!session) {
    res.status(401).json({ error: "unauthorized", loginUrl: "/api/auth/login" });
    return;
  }
  const guildId = req.params["guildId"];
  const allowed = session.adminGuilds.some((g) => g.id === guildId);
  if (!allowed) {
    res.status(403).json({ error: "You aren't an admin on that server." });
    return;
  }
  next();
}
router.use("/:guildId", requireGuildAdmin);

// ── Games (invite-reward sub-categories) ────────────────────────────────
// Grow a Garden, Pet Simulator 99, and Robux ship as defaults but are fully
// editable/removable like any custom game — nothing here is hardcoded.

router.get("/:guildId/games", (req, res) => {
  const guildId = req.params["guildId"]!;
  res.json({ games: getGames(guildId) });
});

router.post("/:guildId/games", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { label, emoji } = req.body as { label?: string; emoji?: string };
  if (!label?.trim()) {
    res.status(400).json({ error: "label is required" });
    return;
  }
  const game = addGame(guildId, { label: label.trim(), emoji: emoji?.trim() ?? "🎮" });
  res.status(201).json({ game });
});

router.patch("/:guildId/games/:id", (req, res) => {
  const guildId = req.params["guildId"]!;
  const id = req.params["id"]!;
  const { label, emoji } = req.body as { label?: string; emoji?: string };
  const game = editGame(guildId, id, { label: label?.trim(), emoji: emoji?.trim() });
  if (!game) {
    res.status(404).json({ error: "No game with that id" });
    return;
  }
  res.json({ game });
});

router.delete("/:guildId/games/:id", (req, res) => {
  const guildId = req.params["guildId"]!;
  const id = req.params["id"]!;
  const removed = removeGame(guildId, id);
  if (!removed) {
    res.status(404).json({ error: "No game with that id" });
    return;
  }
  res.json({ ok: true });
});

// ── Rewards ─────────────────────────────────────────────────────────────
// Category is freeform text (grouping label for the reward-select menus) —
// not restricted to a fixed list, so a server can organize however it wants.
// gameId ties a reward to one of the games above.

router.get("/:guildId", (req, res) => {
  const guildId = req.params["guildId"]!;
  res.json({ rewards: getRewards(guildId), games: getGames(guildId) });
});

router.post("/:guildId", (req, res) => {
  const guildId = req.params["guildId"]!;
  const { name, category, gameId, requiredInvites } = req.body as {
    name?: string;
    category?: string;
    gameId?: string;
    requiredInvites?: number;
  };
  if (
    !name?.trim() ||
    !gameId?.trim() ||
    typeof requiredInvites !== "number" ||
    requiredInvites <= 0
  ) {
    res.status(400).json({ error: "name, gameId, and requiredInvites (>0) are required" });
    return;
  }
  const reward = addReward(guildId, {
    name: name.trim(),
    category: category?.trim() || "General",
    gameId,
    requiredInvites,
  });
  res.status(201).json({ reward });
});

router.patch("/:guildId/:id", (req, res) => {
  const guildId = req.params["guildId"]!;
  const id = req.params["id"]!;
  const { name, category, gameId, requiredInvites } = req.body as {
    name?: string;
    category?: string;
    gameId?: string;
    requiredInvites?: number;
  };
  const reward = editReward(guildId, id, {
    name: name?.trim(),
    category: category?.trim(),
    gameId,
    requiredInvites,
  });
  if (!reward) {
    res.status(404).json({ error: "No reward with that id" });
    return;
  }
  res.json({ reward });
});

router.delete("/:guildId/:id", (req, res) => {
  const guildId = req.params["guildId"]!;
  const id = req.params["id"]!;
  const removed = removeReward(guildId, id);
  if (!removed) {
    res.status(404).json({ error: "No reward with that id" });
    return;
  }
  res.json({ ok: true });
});

export default router;
