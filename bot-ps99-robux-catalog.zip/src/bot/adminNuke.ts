import {
  type ChatInputCommandInteraction,
  type ButtonInteraction,
  SlashCommandBuilder,
  PermissionFlagsBits,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  EmbedBuilder,
} from 'discord.js';
import { randomUUID } from 'crypto';
import { logger } from '../lib/logger.js';

// Sukuna (Ryomen Sukuna, "King of Curses") themed embed color — deep curse-red.
const SUKUNA_RED = 0x8B0000;

type NukeAction = 'kick' | 'ban';

interface PendingNuke {
  guildId: string;
  invokerId: string;
  targetId: string;
  targetTag: string;
  action: NukeAction;
  reason: string;
  expiresAt: number;
}

const pendingNukes = new Map<string, PendingNuke>();
const CONFIRM_TIMEOUT_MS = 30_000;

function sukunaFlavor(action: NukeAction): string {
  return action === 'ban'
    ? '*"Know your place."* This soul has been judged and cast out — permanently.'
    : '*"Know your place."* This soul has been judged unworthy of this domain — for now.';
}

function cleanupExpired(): void {
  const now = Date.now();
  for (const [token, nuke] of pendingNukes) {
    if (nuke.expiresAt < now) pendingNukes.delete(token);
  }
}

export function buildAdminNukeCommand() {
  return new SlashCommandBuilder()
    .setName('adminnuke')
    .setDescription('👹 Judge a member — kick or ban them, Sukuna-style')
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .setDMPermission(false)
    .addUserOption((opt) => opt.setName('user').setDescription('The member to judge').setRequired(true))
    .addStringOption((opt) =>
      opt
        .setName('action')
        .setDescription('Kick or ban')
        .setRequired(true)
        .addChoices({ name: 'Kick', value: 'kick' }, { name: 'Ban', value: 'ban' }),
    )
    .addStringOption((opt) =>
      opt.setName('reason').setDescription('Reason (shown in audit log)').setRequired(false),
    )
    .toJSON();
}

export async function handleAdminNukeCommand(interaction: ChatInputCommandInteraction): Promise<void> {
  const guild = interaction.guild;
  if (!guild) {
    await interaction.reply({ content: '❌ This command can only be used in a server.', ephemeral: true });
    return;
  }

  const targetUser = interaction.options.getUser('user', true);
  const action      = interaction.options.getString('action', true) as NukeAction;
  const reason      = interaction.options.getString('reason') ?? 'No reason provided';

  if (targetUser.id === interaction.user.id) {
    await interaction.reply({ content: '❌ You cannot use this on yourself.', ephemeral: true });
    return;
  }
  if (targetUser.bot) {
    await interaction.reply({ content: '❌ This command cannot target bots.', ephemeral: true });
    return;
  }

  const targetMember = await guild.members.fetch(targetUser.id).catch(() => null);
  if (!targetMember && action === 'kick') {
    await interaction.reply({ content: '❌ That user is not in this server.', ephemeral: true });
    return;
  }

  // Role hierarchy / permission sanity checks
  const me = guild.members.me;
  if (targetMember && me) {
    if (!targetMember.kickable && action === 'kick') {
      await interaction.reply({ content: "❌ I don't have permission to kick that member (role hierarchy).", ephemeral: true });
      return;
    }
    if (!targetMember.bannable && action === 'ban') {
      await interaction.reply({ content: "❌ I don't have permission to ban that member (role hierarchy).", ephemeral: true });
      return;
    }
  }

  cleanupExpired();
  const token = randomUUID();
  pendingNukes.set(token, {
    guildId:   guild.id,
    invokerId: interaction.user.id,
    targetId:  targetUser.id,
    targetTag: targetUser.tag,
    action,
    reason,
    expiresAt: Date.now() + CONFIRM_TIMEOUT_MS,
  });

  const embed = new EmbedBuilder()
    .setColor(SUKUNA_RED)
    .setTitle('👹 Domain Expansion: Malevolent Shrine')
    .setDescription(
      [
        `**${interaction.user}**, you stand ready to pass judgment on **${targetUser}**.`,
        '',
        `**Sentence:** ${action === 'ban' ? '🔨 Banishment (Ban)' : '👢 Expulsion (Kick)'}`,
        `**Reason:** ${reason}`,
        '',
        sukunaFlavor(action),
        '',
        `⏳ Confirm within **${CONFIRM_TIMEOUT_MS / 1000}s** or the curse dissipates.`,
      ].join('\n'),
    )
    .setThumbnail(targetUser.displayAvatarURL())
    .setFooter({ text: 'Only you may confirm this judgment.' });

  const row = new ActionRowBuilder<ButtonBuilder>().addComponents(
    new ButtonBuilder()
      .setCustomId(`adminnuke_confirm:${token}`)
      .setLabel(action === 'ban' ? 'Confirm Banishment' : 'Confirm Expulsion')
      .setStyle(ButtonStyle.Danger)
      .setEmoji('👹'),
    new ButtonBuilder()
      .setCustomId(`adminnuke_cancel:${token}`)
      .setLabel('Cancel')
      .setStyle(ButtonStyle.Secondary),
  );

  await interaction.reply({ embeds: [embed], components: [row] });
}

export async function handleAdminNukeButton(interaction: ButtonInteraction): Promise<void> {
  const [prefix, token] = interaction.customId.split(':');
  if (!token) return;

  const nuke = pendingNukes.get(token);
  if (!nuke) {
    await interaction.update({
      content: '⌛ This judgment has expired or was already resolved.',
      embeds: [],
      components: [],
    }).catch(() => {});
    return;
  }

  if (interaction.user.id !== nuke.invokerId) {
    await interaction.reply({ content: '❌ Only the admin who issued this judgment can confirm or cancel it.', ephemeral: true });
    return;
  }

  pendingNukes.delete(token);

  if (prefix === 'adminnuke_cancel') {
    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(SUKUNA_RED)
          .setTitle('👹 The curse retreats')
          .setDescription(`Judgment on <@${nuke.targetId}> has been **cancelled**.`),
      ],
      components: [],
    });
    return;
  }

  // Confirm
  const guild = interaction.guild;
  if (!guild) return;

  try {
    if (nuke.action === 'kick') {
      const member = await guild.members.fetch(nuke.targetId).catch(() => null);
      if (!member) throw new Error('Member no longer in server');
      await member.kick(`${nuke.reason} — nuked by ${interaction.user.tag}`);
    } else {
      await guild.members.ban(nuke.targetId, {
        reason: `${nuke.reason} — nuked by ${interaction.user.tag}`,
      });
    }

    await interaction.update({
      embeds: [
        new EmbedBuilder()
          .setColor(SUKUNA_RED)
          .setTitle(nuke.action === 'ban' ? '👹 Banishment Executed' : '👹 Expulsion Executed')
          .setDescription(
            [
              `**${nuke.targetTag}** (<@${nuke.targetId}>) has been ${nuke.action === 'ban' ? 'banned' : 'kicked'}.`,
              '',
              `**Reason:** ${nuke.reason}`,
              '',
              '*"You have no right to live in my domain."*',
            ].join('\n'),
          )
          .setFooter({ text: `Judgment carried out by ${interaction.user.tag}` })
          .setTimestamp(),
      ],
      components: [],
    });
  } catch (err) {
    logger.error({ err, targetId: nuke.targetId, action: nuke.action }, 'Admin nuke failed to execute');
    await interaction.update({
      content: `❌ Failed to ${nuke.action} <@${nuke.targetId}>. I may be missing permissions.`,
      embeds: [],
      components: [],
    }).catch(() => {});
  }
}
