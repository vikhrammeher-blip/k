# Ticket Bot — Railway Deploy

A Discord ticket bot for invite rewards, giveaways, chat/chest rewards, and restock requests.

The bot is **multi-server** — invite it to as many Discord servers as you like.
There's nothing to hardcode or redeploy per server: each server's admins run
`/setup` once inside their own server and the bot configures itself for that
server only. Every server's settings are stored separately.

## Railway Deployment (Easy)

1. Push this folder to a **new GitHub repository** (only this folder, not the whole Replit project).
2. In Railway, click **New Project → Deploy from GitHub repo** and select your repo.
3. Railway will auto-detect `railway.toml` and run `npm install && npm run build`.
4. Go to **Variables** and add:
   - `DISCORD_BOT_TOKEN` — your bot token from the Discord Developer Portal
5. Deploy. The bot starts automatically.
6. (Optional but recommended) Attach a Railway **volume** mounted at `/app/data`
   so `/setup` settings survive redeploys — otherwise they're stored in the
   container's local filesystem and reset on redeploy. If you don't attach one,
   just re-run `/setup` in each server after a redeploy.

> **PORT** and **NODE_ENV** are already set in `railway.toml` — don't add them as variables.

## Discord Bot Setup

In the [Discord Developer Portal](https://discord.com/developers/applications):
- **Bot → Privileged Gateway Intents**: enable **Server Members Intent** and **Message Content Intent**
- Invite the bot to each server with permissions: `Manage Channels`, `Send Messages`, `Read Message History`, `Embed Links`, `Manage Messages`, `View Channels`

## Setting Up a New Server

After inviting the bot to a server, an **admin** runs these slash commands in that server (each is independent, run in any order, and can be re-run any time to change a setting):

| Command | Sets |
|---------|------|
| `/setup staff-role role:@TicketStaff` | The Ticket Staff role — can claim/close/unlock any ticket |
| `/setup giveaway-role role:@GiveawayHoster` | The Giveaway Hoster role — reviews giveaway tickets |
| `/setup restock-ping-role role:@RestockTeam` | Role pinged when a restock ticket opens |
| `/setup log-channel channel:#ticket-logs` | Where closed-ticket summaries are posted |
| `/setup restock-panel-channel channel:#restock` | Where the restock request panel is posted (auto-posted immediately) |
| `/setup category type:<ticket-type> category:#SomeCategory` | The category new tickets of that type get created under — run once per ticket type (Invite Rewards, Giveaway, Chat Rewards, Chest Rewards, Yapper Rewards, General Support, Restock) |
| `/setup view` | Shows the current config and lists anything still missing |

Once staff role + a category are set for a ticket type, use `/panel` (Admin only) to post the ticket selection panel in a channel, and tickets of that type can be opened. `/setup view` will tell you exactly what's left to configure.

## Dashboard

The bot serves a live dashboard at the app's root URL (e.g.
`https://your-app.up.railway.app/`) with two views:

- **Overview** — ticket lifecycle breakdown, open tickets per queue, a
  searchable/filterable table of open tickets, and the servers the bot is
  currently connected to. It polls the `/api/tickets`, `/api/stats`, and
  `/api/bot-status` endpoints every few seconds; no database or extra
  service needed.
- **Settings** — everything `/setup`, `/customcommand`, `/activate`, and
  `/shop manage` do, but as web forms. Pick a server from the dropdown,
  then: staff/giveaway/restock roles and log/panel channels, the
  category each ticket type is created under, custom `!commands`, the
  chat-rewards system (daily amount, message credit range, cooldown,
  drops, excluded channels), the credits shop, and the global invite-reward
  catalog (the reward list `/invite-rewards` tickets offer, shared across
  all servers). Changes save straight to the same config files/store the
  slash commands use — the two stay in sync either way.

Only servers you're an admin (or owner) of appear in the Settings guild
picker, and every settings API call re-checks that server-side before
making a change.

It's locked behind **Discord login**: visitors sign in with Discord, and
only get in if they have **Administrator permission** (or are the owner)
in at least one server this bot is installed in. Everyone else sees a
sign-in screen and nothing else.

To enable it, set three environment variables — see `.env.example` for
the full walkthrough:

| Variable | Where to get it |
|---|---|
| `DISCORD_CLIENT_ID` | Developer Portal → your app → General Information |
| `DISCORD_CLIENT_SECRET` | Developer Portal → your app → OAuth2 tab |
| `DASHBOARD_PUBLIC_URL` | Your deployment's public URL, no trailing slash |

Then add `<DASHBOARD_PUBLIC_URL>/api/auth/callback` as a redirect under
Developer Portal → OAuth2 → Redirects. Until all three variables are set,
the dashboard shell loads but shows "Discord login isn't configured yet"
instead of a sign-in button.

Sessions live in memory, so everyone's signed out on redeploy — that's
expected, just sign in again.

## Slash Commands

- `/panel` — (Admin only) Posts the ticket selection panel in the current channel.
- `/setup` — (Admin only) Configures the bot for this server. See "Setting Up a New Server" above.

## Ticket Types

| Button | Type | Description |
|--------|------|-------------|
| Invite Rewards | `invite-rewards` | Verifies Falcon Bot invite count, collects 1 screenshot, shows reward menu |
| Giveaway Rewards | `giveaway` | Screenshot proof for giveaway wins |
| Chat Rewards | `chat-rewards` | Screenshot proof for chat activity rewards |
| Chest Rewards | `chest-rewards` | Screenshot proof for chest rewards |
| Yapper Rewards | `yapper-rewards` | Screenshot proof for yapper rewards |
| General Support | `general-support` | Open support ticket |

## Staff Commands (in ticket channels)

| Command | Who | Effect |
|---------|-----|--------|
| `!close` | Owner / Claimer / Staff | Close and delete the ticket |
| `!unlock` | Staff | Unlock a locked ticket |
| `!setinvites N` | Staff | Manually set invite count if Falcon auto-detect fails |

## Invite Reward Games & Catalog

Invite rewards are fully dashboard-managed now — nothing about them is hardcoded.

- **Games** are sub-categories a member picks between when claiming an invite reward (e.g. "Grow a Garden", "Pet Simulator 99", "Robux"). Manage them from the dashboard's Invite Rewards tab — add, rename, or remove any of them, including the three that ship by default.
- **Rewards** belong to one game each and have a free-text category (used just to group the in-Discord select menus — call it whatever you want), a name, and how many invites it costs. Add/edit/remove them from the same tab.
- A member's reward menu is built live from whatever's currently in the catalog for the game they picked — quantities scale automatically up to their verified invite count (capped at 10 of any one reward per selection).
- Robux (or any game) unlocking at a higher invite count isn't special-cased — it's just a reward whose `requiredInvites` is higher, so it naturally won't show up in anyone's menu until they qualify.

Each server has its own independent games list and catalog.
