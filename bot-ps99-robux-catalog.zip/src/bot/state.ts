export type TicketType =
  | 'invite-rewards'
  | 'giveaway'
  | 'chat-rewards'
  | 'chest-rewards'
  | 'yapper-rewards'
  | 'general-support'
  | 'restock'
  | 'credit-redeem';

export type InvitePhase =
  | 'awaiting_command'          // waiting for member to type .i
  | 'awaiting_falcon_response'  // .i typed, waiting for Falcon Bot to reply
  | 'awaiting_screenshots'      // invite count known, collecting proof screenshots
  | 'awaiting_game_choice'      // all screenshots in, waiting for game selection
  | 'awaiting_reward'           // game chosen, showing reward menu
  | 'reward_selected';          // reward chosen, channel locked

export interface TicketState {
  ticketType: TicketType;
  ownerId: string;
  ownerUsername: string;
  createdAt: Date;
  /** Roblox username collected before ticket creation */
  robloxUsername?: string;
  /** Staff member who claimed the ticket */
  claimedBy?: string;
  claimedByUsername?: string;

  // ── Invite Rewards ──────────────────────────────────────────────────────
  invitePhase?: InvitePhase;
  /** Invite count parsed from Falcon Bot's response */
  autoDetectedInvites?: number;
  /** How many proof screenshots the member still needs to upload */
  screenshotsRequired?: number;
  /** How many proof screenshots received so far */
  screenshotsReceived?: number;
  /** Selected reward name (for channel rename) */
  selectedReward?: string;
  /** Selected reward quantity */
  selectedQty?: number;
  /** Pending timeout handle (Falcon response wait OR 10-min screenshot) */
  timeoutHandle?: ReturnType<typeof setTimeout>;
  /** True once the member has uploaded their proof screenshot (standard ticket types).
   *  After this is set, typing is no longer blocked even if staff !unlock the channel. */
  screenshotSubmitted?: boolean;

  /**
   * Which game the member chose for their invite reward — a game id from
   * the dashboard-managed catalog (data/inviteGames.ts). Grow a Garden,
   * Pet Simulator 99, and Robux ship as defaults but are fully editable
   * like any custom game; nothing here is hardcoded.
   */
  gameChoice?: string;

  // ── Restock ─────────────────────────────────────────────────────────────
  // 'ps99' is a valid restock subtype for Pet Simulator 99 stock requests
  restockSubtype?: 'gear' | 'pets' | 'seeds' | 'all' | 'ps99';
}

/** channelId → TicketState */
export const ticketStates = new Map<string, TicketState>();

export function findTicketByOwner(ownerId: string): string | undefined {
  for (const [channelId, state] of ticketStates) {
    if (state.ownerId === ownerId) return channelId;
  }
  return undefined;
}
