import { promises as fs } from 'fs';
import path from 'path';
import { logger } from '../../lib/logger.js';

/**
 * Category is a free-text label chosen by whoever adds the reward (e.g.
 * "Gear", "Pets", "Seeds", or anything else) — it's just used to group the
 * reward-selection menus, never validated against a fixed list.
 */
export interface Reward {
  id: string;
  name: string;
  category: string;
  /** Which game/sub-category (data/inviteGames.ts) this reward belongs to. */
  gameId: string;
  requiredInvites: number;
}

/**
 * Starter catalog used to seed a server the very first time its invite
 * rewards are requested (matches the bot's original hardcoded lists — Pet
 * Simulator 99 and Robux used to be computed by formula, but now ship as
 * regular seeded catalog rows like everything else, fully editable). Each
 * server gets its own independent copy from here on.
 */
const DEFAULT_REWARDS: Reward[] = [
  // 🌱 Grow a Garden — ⚙️ Gear (1 invite each)
  { id: 'super_watering',    name: '2× Super Watering',       category: 'Gear',  gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'super_sprinkler',   name: '1× Super Sprinkler',      category: 'Gear',  gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'trowel',            name: '10× Trowel',              category: 'Gear',  gameId: 'grow-a-garden', requiredInvites: 1 },
  // 🌱 Grow a Garden — 🐶 Pets
  { id: 'random_pet',        name: '3× Random Pet',           category: 'Pets',  gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'dragonfly',         name: '1× Dragonfly',            category: 'Pets',  gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'unicorn',           name: '1× Unicorn',              category: 'Pets',  gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'firefly',           name: '1× Firefly',              category: 'Pets',  gameId: 'grow-a-garden', requiredInvites: 3 },
  // 🌱 Grow a Garden — 🌱 Seeds
  { id: 'gold_seed',         name: '15× Gold Seed',           category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'mushroom',          name: '30× Mushroom',            category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'rainbow_seed',      name: '4× Rainbow Seed',         category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'mega_seed',         name: '10× Mega Seed',           category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'rocket_pop_seed',   name: '15× Rocket Pop Seed',     category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 1 },
  { id: 'moonbloom_seed',    name: '1× Moonbloom Seed',        category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'dragons_breath',    name: "1× Dragon's Breath Seed",  category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'pepper_seed',       name: '1× Pepper Seed',          category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'hypnobloom_seed',   name: '1× Hypnobloom Seed',      category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 2 },
  { id: 'sunbloom_seed',     name: '1× Sunbloom Seed',        category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 3 },
  { id: 'star_fruit_seed',   name: '1× Star Fruit Seed',       category: 'Seeds', gameId: 'grow-a-garden', requiredInvites: 7 },
  // 🎮 Pet Simulator 99 — was "1 invite per 25M Gems, 1 Huge per 5 invites"
  { id: 'petsim_gems',       name: '25M Gems',                 category: 'Gems',  gameId: 'pet-sim', requiredInvites: 1 },
  { id: 'petsim_huge',       name: '1× Huge',                  category: 'Pets',  gameId: 'pet-sim', requiredInvites: 5 },
  // 💵 Robux — was "250 Robux per 25 invites"
  { id: 'robux_250',         name: '250 Robux',                category: 'Robux', gameId: 'robux',   requiredInvites: 25 },
];

/** Ids of the rows above that came from the old pet-sim/robux formulas — used by the one-time migration below. */
const BUILTIN_MIGRATION_IDS = ['petsim_gems', 'petsim_huge', 'robux_250'] as const;

type GuildRewards = Record<string, Reward>; // rewardId -> reward

interface StoredFile {
  version: 2;
  /** True once existing servers have had Pet Sim 99 / Robux backfilled as catalog rows — see migrate(). */
  builtinsMigrated: boolean;
  guilds: Record<string, GuildRewards>;
}

// Persisted to disk, same pattern as guildConfigs.json / shop.json — mount a
// persistent volume at DATA_DIR on hosts with an ephemeral filesystem (e.g.
// Railway without a volume) or edits reset on redeploy.
const DATA_DIR  = process.env['DATA_DIR'] ?? path.join(process.cwd(), 'data');
const DATA_FILE = path.join(DATA_DIR, 'rewards.json');

let file: StoredFile = { version: 2, builtinsMigrated: true, guilds: {} };
let loaded = false;
let saveQueue: Promise<void> = Promise.resolve();

async function load(): Promise<void> {
  if (loaded) return;
  loaded = true;
  try {
    const raw = await fs.readFile(DATA_FILE, 'utf-8');
    const parsed = JSON.parse(raw) as unknown;

    if (Array.isArray(parsed)) {
      // Oldest format: a single flat array shared by every server, from
      // before per-server catalogs existed at all.
      logger.info({ count: parsed.length }, 'Migrating legacy global reward catalog to per-server storage');
      const guilds: Record<string, GuildRewards> = {
        __legacy__: Object.fromEntries((parsed as Reward[]).map((r) => [r.id, backfillGameId(r)])),
      };
      file = { version: 2, builtinsMigrated: false, guilds };
    } else if (parsed && typeof parsed === 'object' && 'version' in parsed) {
      file = parsed as StoredFile;
    } else {
      // Mid format: bare { guildId: { rewardId: reward } }, from before
      // gameId and the versioned wrapper existed.
      logger.info('Migrating reward catalog file to versioned format');
      const guilds = parsed as Record<string, GuildRewards>;
      for (const guildRewards of Object.values(guilds ?? {})) {
        for (const reward of Object.values(guildRewards)) backfillGameId(reward);
      }
      file = { version: 2, builtinsMigrated: false, guilds: guilds ?? {} };
    }
    logger.info({ guilds: Object.keys(file.guilds).length, dataFile: DATA_FILE }, 'Loaded reward catalogs from disk');
  } catch (err) {
    const code = (err as NodeJS.ErrnoException)?.code;
    if (code === 'ENOENT') {
      logger.info({ dataFile: DATA_FILE }, 'No existing reward catalog file found — starting fresh (this is expected on first run)');
    } else {
      logger.warn({ err, dataFile: DATA_FILE }, 'Failed to read reward catalog file — starting fresh');
    }
    file = { version: 2, builtinsMigrated: true, guilds: {} };
  }
  migrate();
}

function backfillGameId(r: Reward): Reward {
  if (!r.gameId) r.gameId = 'grow-a-garden';
  return r;
}

/**
 * One-time backfill: any guild whose catalog predates Pet Sim 99 / Robux
 * becoming editable rows gets the equivalent starter rows added now. Gated
 * on a persisted flag so this runs exactly once ever — otherwise deleting
 * "25M Gems" would just have it reappear on the next restart.
 */
function migrate(): void {
  if (file.builtinsMigrated) return;
  const builtinRewards = DEFAULT_REWARDS.filter((r) => (BUILTIN_MIGRATION_IDS as readonly string[]).includes(r.id));
  for (const guildRewards of Object.values(file.guilds)) {
    for (const reward of builtinRewards) {
      if (!guildRewards[reward.id]) guildRewards[reward.id] = { ...reward };
    }
  }
  file.builtinsMigrated = true;
  logger.info('Backfilled Pet Simulator 99 / Robux starter rewards for existing servers');
  persist();
}

function persist(): void {
  saveQueue = saveQueue
    .then(async () => {
      await fs.mkdir(DATA_DIR, { recursive: true });
      await fs.writeFile(DATA_FILE, JSON.stringify(file, null, 2), 'utf-8');
    })
    .catch((err) => logger.error({ err, dataFile: DATA_FILE }, 'Failed to persist reward catalogs'));
}

/** Must be awaited once before the bot starts handling events. */
export async function initRewardsStore(): Promise<void> {
  await load();
}

/**
 * Returns the guild's reward catalog, seeding it from the default starter
 * list the very first time this guild is seen (and persisting that seed so
 * it's editable/removable from there on, independently of the defaults).
 */
function getGuildRewards(guildId: string): GuildRewards {
  let guild = file.guilds[guildId];
  if (!guild) {
    guild = Object.fromEntries(DEFAULT_REWARDS.map((r) => [r.id, { ...r }]));
    file.guilds[guildId] = guild;
    persist();
  }
  return guild;
}

/** Every reward in this server's catalog, across every game. */
export function getRewards(guildId: string): Reward[] {
  return Object.values(getGuildRewards(guildId)).sort((a, b) => a.requiredInvites - b.requiredInvites);
}

/** Just the rewards belonging to one game/sub-category — used to build a member's reward menu. */
export function getRewardsForGame(guildId: string, gameId: string): Reward[] {
  return getRewards(guildId).filter((r) => r.gameId === gameId);
}

export function getEligibleRewards(guildId: string, gameId: string, inviteCount: number): Reward[] {
  return getRewardsForGame(guildId, gameId).filter((r) => r.requiredInvites <= inviteCount);
}

export function getReward(guildId: string, id: string): Reward | undefined {
  return getGuildRewards(guildId)[id];
}

function slugify(name: string): string {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, '_')
    .replace(/^_+|_+$/g, '')
    .slice(0, 60) || 'reward';
}

function uniqueId(guild: GuildRewards, base: string): string {
  let id = base;
  let n = 2;
  while (guild[id]) {
    id = `${base}_${n}`;
    n += 1;
  }
  return id;
}

export interface RewardInput {
  name: string;
  category: string;
  gameId: string;
  requiredInvites: number;
}

/** Adds a new reward to this server's catalog, generating a unique id from its name. */
export function addReward(guildId: string, input: RewardInput): Reward {
  const guild = getGuildRewards(guildId);
  const reward: Reward = {
    id: uniqueId(guild, slugify(input.name)),
    name: input.name,
    category: input.category || 'General',
    gameId: input.gameId,
    requiredInvites: input.requiredInvites,
  };
  guild[reward.id] = reward;
  persist();
  return reward;
}

export function editReward(guildId: string, id: string, patch: Partial<RewardInput>): Reward | undefined {
  const reward = getGuildRewards(guildId)[id];
  if (!reward) return undefined;
  if (patch.name !== undefined) reward.name = patch.name;
  if (patch.category !== undefined) reward.category = patch.category || 'General';
  if (patch.gameId !== undefined) reward.gameId = patch.gameId;
  if (patch.requiredInvites !== undefined) reward.requiredInvites = patch.requiredInvites;
  persist();
  return reward;
}

export function removeReward(guildId: string, id: string): boolean {
  const guild = getGuildRewards(guildId);
  if (!guild[id]) return false;
  delete guild[id];
  persist();
  return true;
}
