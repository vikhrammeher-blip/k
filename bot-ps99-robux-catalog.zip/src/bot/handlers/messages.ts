import { type Message, type GuildMember, type TextChannel, ComponentType } from 'discord.js';
import { ticketStates } from '../state.js';
import { lockChannel, unlockChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import {
  startFalconWaitTimeout,
  handleFalconResponse,
  handleScreenshotUpload,
  buildScreenshotInstructions,
  MAX_ATTACHMENTS_PER_MESSAGE,
} from '../tickets/inviteRewards.js';
import { handleCloseTicket } from './interactions.js';
import { getGuildConfig, getChatRewardsConfig } from '../config.js';
import { recordMessageEarn, recordActivity, addCredits } from '../chatCredits.js';
import { logTicketMessage } from '../utils/ticketLog.js';
import { logger } from '../../lib/logger.js';

function isStaff(member: GuildMember): boolean {
  const cfg = getGuildConfig(member.guild.id);
  return (
    (!!cfg.staffRoleId && member.roles.cache.has(cfg.staffRoleId)) ||
    (!!cfg.giveawayHosterRoleId && member.roles.cache.has(cfg.giveawayHosterRoleId)) ||
    member.permissions.has('Administrator')
  );
}

async function sendTempWarning(channel: TextChannel, text: string): Promise<void> {
  const msg = await channel.send({
    embeds: [buildEmbed({ description: text, color: COLORS.warning })],
  });
  setTimeout(() => msg.delete().catch(() => {}), 5_000);
}

/** Finds the bot's controls message (Claim / Close buttons) in a ticket channel. */
async function findControlsMessage(channel: TextChannel) {
  const msgs = await channel.messages.fetch({ limit: 20 });
  return msgs.find(m => {
    if (m.author.id !== channel.client.user!.id) return false;
    if (!m.components.length) return false;
    const row = m.components[0];
    // TopLevelComponent is ActionRow | FileComponent — only ActionRow has .components
    if (!row || row.type !== ComponentType.ActionRow) return false;
    return row.components.some(
      (c: { customId?: string | null }) =>
        c.customId === 'claim_ticket' || c.customId === 'close_ticket',
    );
  });
}

async function pingStaffOnScreenshot(
  channel: TextChannel,
  ownerId: string,
  robloxUsername: string | undefined,
  guildId: string,
): Promise<void> {
  const staffRoleId = getGuildConfig(guildId).staffRoleId;
  // Permanent ping — not deleted
  await channel.send(
    `<@&${staffRoleId}>\n\n` +
    `**A member has submitted proof and is ready for review.**\n\n` +
    `Discord User: <@${ownerId}>\n` +
    `Roblox Username: \`${robloxUsername ?? 'Not provided'}\``,
  );
}

export async function handleMessage(message: Message): Promise<void> {
  // Always ignore our own bot's messages
  if (message.author.id === message.client.user?.id) return;
  if (!message.guild) return;

  // ── ;help — works in ANY channel, sends bot commands to DM ──────────────────
  if (!message.author.bot && message.content.trim() === ';help') {
    const helpEmbed = buildEmbed({
      title: '📋 Ticket Bot — Command Guide',
      description: [
        '**Panel Commands**',
        '`/panel` — Post the ticket selection panel *(Admin only)*',
        '`/customcommand add|remove|list` — Manage custom !commands *(Admin only)*',
        '`/activate` — Configure & enable the chat rewards credit system *(Admin only)*',
        '',
        '**Chat Rewards Commands**',
        '`/credits daily` — Claim your daily credits',
        '`/credits balance [user]` — Check a credit balance',
        '`/credits give|take` — Adjust a member\'s balance *(Staff only)*',
        '`/flurry <amount> [minutes]` — Give bonus credits to everyone active recently *(Staff only)*',
        '',
        '**Shop**',
        '`/shop view` — Browse items you can redeem credits for',
        '`/shop buy <item>` — Buy an item with your credits',
        '`/shop manage add|edit|remove|list` — Manage shop items *(Staff only)*',
        '',
        '**Chat Drops**',
        'While chat rewards is on, qualifying messages have a small random chance to instantly award bonus credits.',
        'Configure with `/activate drop-enable|drop-disable|drop-chance|drop-range` *(Admin only)*.',
        '',
        '**Ticket Commands** *(use inside any ticket channel)*',
        '`!claim` — Claim the ticket and assign yourself to it *(Staff only)*',
        '`!unclaim` — Release your claim on the ticket *(Staff only)*',
        '`!close` — Close and delete the ticket',
        '`!unlock` — Unlock a locked ticket after reviewing proof *(Staff only)*',
        '`!setinvites <N>` — Manually set invite count *(Staff only, Invite Rewards only)*',
        '',
        '**General Commands** *(work in any channel)*',
        '`;help` — DM yourself this command guide',
        '',
        '**Ticket Types**',
        '🎟️ Invite Rewards · 🎉 Giveaway · 💬 Chat Rewards',
        '📦 Chest Rewards · 🗣️ Yapper Rewards · 🛠️ General Support · 🏪 Restock · 💳 Chat Credits',
        '',
        '**Invite Rewards Flow**',
        '1. Member types `.i` → Falcon Bot detects invites',
        '2. Member uploads **all screenshots in one single message**',
        '3. Member chooses a reward category: **Pet Sim 99**, **Grow a Garden**, or **Robux** (Robux unlocks at 25 invites)',
        '',
        '   🎮 **Pet Simulator 99 rewards:**',
        '   • 💎 25M Gems — 1 invite each (stackable)',
        '   • 🐾 1× Huge — 5 invites each (stackable)',
        '',
        '   🌱 **Grow a Garden rewards:**',
        '   • **Gear:** 2× Super Watering, 1× Super Sprinkler, 10× Trowel — 1 invite each',
        '   • **Pets:** 3× Random Pet — 1 invite; 1× Dragonfly / 1× Unicorn — 2 invites each; 1× Firefly — 3 invites',
        '   • **Seeds:** 15× Gold Seed, 30× Mushroom, 4× Rainbow Seed, 10× Mega Seed, 15× Rocket Pop Seed — 1 invite each',
        "   • Moonbloom Seed / Dragon's Breath Seed / Pepper Seed / Hypnobloom Seed — 2 invites each",
        '   • Sunbloom Seed — 3 invites; Star Fruit Seed — 7 invites',
        '',
        '   💵 **Robux rewards:**',
        '   • 250 Robux — 25 invites (category unlocks at 25 invites)',
        '',
        '4. Member selects reward → bot pings Ticket Staff automatically',
      ].join('\n'),
      color: COLORS.primary,
      footer: 'Ticket Bot Command Guide',
    });

    try {
      await message.author.send({ embeds: [helpEmbed] });
      await message.delete().catch(() => {});
      const tempChannel = message.channel as TextChannel;
      const conf = await tempChannel.send({
        embeds: [buildEmbed({
          description: `📬 Command guide sent to your DMs, <@${message.author.id}>!`,
          color: COLORS.success,
        })],
      });
      setTimeout(() => conf.delete().catch(() => {}), 5_000);
    } catch {
      const tempChannel = message.channel as TextChannel;
      const warn = await tempChannel.send({
        embeds: [buildEmbed({
          description: `❌ Couldn't DM you, <@${message.author.id}>. Please enable DMs from server members.`,
          color: COLORS.warning,
        })],
      });
      setTimeout(() => warn.delete().catch(() => {}), 5_000);
    }
    return;
  }

  // ── Custom !commands (e.g. !killer) — work in any channel, anyone can use ──
  if (!message.author.bot && message.content.trim().startsWith('!')) {
    const trigger = message.content.trim().slice(1).split(/\s+/)[0]?.toLowerCase();
    const customCmd = trigger ? getGuildConfig(message.guild.id).customCommands?.[trigger] : undefined;
    if (customCmd) {
      const text = customCmd.template.replace('{user}', `<@${customCmd.targetUserId}>`);
      await (message.channel as TextChannel).send({
        content: text,
        allowedMentions: { users: [customCmd.targetUserId] },
      });
      return;
    }
  }

  // ── Chat Rewards: passive credit earning + chat drops ───────────────────
  // Runs in any regular (non-ticket) channel that hasn't been excluded via
  // /activate exclude-channel. Cooldown + random range are enforced inside
  // recordMessageEarn, so this is safe to call on every human message.
  if (!message.author.bot && !ticketStates.has(message.channelId)) {
    // Track presence for /flurry regardless of whether chat rewards is on,
    // so staff can enable rewards later and /flurry still has activity data.
    recordActivity(message.guild.id, message.author.id);

    const rewardsCfg = getChatRewardsConfig(message.guild.id);
    if (rewardsCfg.enabled && !rewardsCfg.excludedChannelIds.includes(message.channelId)) {
      recordMessageEarn(
        message.guild.id,
        message.author.id,
        rewardsCfg.messageMin,
        rewardsCfg.messageMax,
        rewardsCfg.cooldownSeconds,
      );

      // Chat drop — small independent chance per qualifying message to
      // instantly win a bonus. Not gated by the earn cooldown; it's a
      // separate rare event layered on top.
      if (rewardsCfg.dropEnabled && Math.random() * 100 < rewardsCfg.dropChancePercent) {
        const lo     = Math.min(rewardsCfg.dropMin, rewardsCfg.dropMax);
        const hi     = Math.max(rewardsCfg.dropMin, rewardsCfg.dropMax);
        const amount = Math.floor(Math.random() * (hi - lo + 1)) + lo;
        const balance = addCredits(message.guild.id, message.author.id, amount);
        await (message.channel as TextChannel).send({
          embeds: [
            buildEmbed({
              title: '🎁 Chat Drop!',
              description: `<@${message.author.id}> stumbled onto a chat drop worth **${amount}** credits!\nNew balance: **${balance}**.`,
              color: COLORS.success,
              footer: 'Keep chatting for a chance at more drops',
            }),
          ],
        }).catch(() => {});
      }
    }
  }

  const channelId = message.channelId;
  const state     = ticketStates.get(channelId);
  if (!state) return;

  const channel = message.channel as TextChannel;

  // Mirror every message sent in a ticket channel to the log channel, in real
  // time — including ones the bot is about to delete below (e.g. enforced
  // screenshot-only phases), so staff always have a full record.
  logTicketMessage({
    client: message.client,
    guildId: message.guild.id,
    channelId,
    channelName: channel.name,
    authorId: message.author.id,
    authorTag: message.author.tag,
    isBot: message.author.bot,
    content: message.content,
    attachmentUrls: [...message.attachments.values()].map(a => a.url),
  }).catch((err) => logger.error({ err }, 'Failed to mirror ticket message to log channel'));

  // ── OTHER bots (Falcon, etc.) — only process in invite-rewards tickets ─────
  if (message.author.bot) {
    if (state.ticketType !== 'invite-rewards') return;
    if (state.invitePhase === 'awaiting_falcon_response') {
      await handleFalconResponse(message, channel, state, channelId);
    }
    return;
  }

  // ── Human messages below ────────────────────────────────────────────────────
  const member  = message.member as GuildMember;
  const isOwner = message.author.id === state.ownerId;
  const content = message.content.trim();

  // ── Universal: !close ──────────────────────────────────────────────────────
  if (content === '!close') {
    const isOwnerOrClaimer = isOwner || state.claimedBy === message.author.id;
    if (!isOwnerOrClaimer && !isStaff(member)) {
      await sendTempWarning(channel, '❌ Only the ticket owner or assigned staff can close this ticket.');
      return;
    }
    await message.delete().catch(() => {});
    await handleCloseTicket(channelId, message.author.id, message.author.tag, member);
    return;
  }

  // ── Universal: !unlock for staff ───────────────────────────────────────────
  if (content === '!unlock' && isStaff(member)) {
    await message.delete().catch(() => {});
    await unlockChannel(channel, state.ownerId);
    await channel.send({
      embeds: [buildEmbed({
        title: '🔓 Ticket Unlocked',
        description: `This ticket has been unlocked by <@${member.id}>.`,
        color: COLORS.success,
      })],
    });
    return;
  }

  // ── Staff: !claim ──────────────────────────────────────────────────────────
  if (content === '!claim' && isStaff(member)) {
    if (state.claimedBy) {
      await sendTempWarning(channel, `❌ This ticket is already claimed by <@${state.claimedBy}>.`);
      return;
    }
    state.claimedBy         = message.author.id;
    state.claimedByUsername = message.author.tag;
    await message.delete().catch(() => {});
    const hasClaim = state.ticketType !== 'general-support';
    const ctrlMsg  = await findControlsMessage(channel);
    if (ctrlMsg) {
      await ctrlMsg.edit({ components: [buildTicketControls(hasClaim, true)] }).catch(() => {});
    }
    await channel.send({
      embeds: [buildEmbed({
        title: '🙋 Ticket Claimed',
        description: [
          `This ticket has been claimed by <@${message.author.id}>.`,
          '',
          'They will assist you shortly.',
        ].join('\n'),
        color: COLORS.success,
        footer: `Claimed by ${message.author.tag}`,
      })],
    });
    return;
  }

  // ── Claimer / Staff: !unclaim ──────────────────────────────────────────────
  if (content === '!unclaim') {
    if (!state.claimedBy) {
      await sendTempWarning(channel, '❌ This ticket has not been claimed.');
      return;
    }
    const isClaimer = state.claimedBy === message.author.id;
    if (!isClaimer && !isStaff(member)) {
      await sendTempWarning(channel, '❌ Only the claimer or a staff member can unclaim this ticket.');
      return;
    }
    const prevClaimer       = state.claimedByUsername ?? 'Unknown';
    state.claimedBy         = undefined;
    state.claimedByUsername = undefined;
    await message.delete().catch(() => {});
    const hasClaim   = state.ticketType !== 'general-support';
    const ctrlMsg2   = await findControlsMessage(channel);
    if (ctrlMsg2) {
      await ctrlMsg2.edit({ components: [buildTicketControls(hasClaim, false)] }).catch(() => {});
    }
    await channel.send({
      embeds: [buildEmbed({
        title: '↩️ Ticket Unclaimed',
        description: [
          `<@${message.author.id}> has unclaimed this ticket.`,
          '',
          'The ticket is now available for another staff member to claim.',
        ].join('\n'),
        color: COLORS.warning,
        footer: `Previously claimed by ${prevClaimer}`,
      })],
    });
    return;
  }

  // ── Staff: !setinvites N  (fallback if Falcon auto-detect fails) ───────────
  if (/^!setinvites\s+\d+$/i.test(content) && isStaff(member)) {
    if (state.ticketType !== 'invite-rewards') return;
    const count = parseInt(content.split(/\s+/)[1] ?? '0', 10);
    if (count <= 0) return;
    await message.delete().catch(() => {});

    if (state.timeoutHandle) { clearTimeout(state.timeoutHandle); state.timeoutHandle = undefined; }
    state.autoDetectedInvites = count;
    state.screenshotsRequired = count;
    state.screenshotsReceived = 0;
    state.invitePhase         = 'awaiting_screenshots';

    await channel.send({
      embeds: [buildEmbed({
        title: '✅ Invites Set Manually',
        description: [
          `Staff set invite count to **${count}** for <@${state.ownerId}>.`,
          '',
          ...buildScreenshotInstructions(count),
        ].join('\n'),
        color: COLORS.success,
        footer:
          count <= MAX_ATTACHMENTS_PER_MESSAGE
            ? `Set by ${message.author.tag}`
            : `Set by ${message.author.tag} · 0/${count} screenshots received`,
      })],
    });
    return;
  }

  // ── Invite Rewards flow ────────────────────────────────────────────────────
  if (state.ticketType === 'invite-rewards') {

    // Phase: awaiting .i command
    if (state.invitePhase === 'awaiting_command') {
      if (!isOwner) return; // staff may speak freely
      if (content === '.i') {
        state.invitePhase   = 'awaiting_falcon_response';
        state.timeoutHandle = startFalconWaitTimeout(channelId, channel, state.ownerId);
        await channel.send({
          embeds: [buildEmbed({
            description: '🔍 Waiting for Falcon Bot to respond with your invite count…',
            color: COLORS.neutral,
          })],
        });
      } else {
        await message.delete().catch(() => {});
      }
      return;
    }

    // Phase: waiting for Falcon Bot — delete member messages
    if (state.invitePhase === 'awaiting_falcon_response') {
      if (isOwner) await message.delete().catch(() => {});
      return;
    }

    // Phase: collecting proof screenshots — ALL must be in ONE message
    if (state.invitePhase === 'awaiting_screenshots') {
      if (!isOwner) return; // staff may speak freely
      if (message.attachments.size > 0) {
        // Pass the message so handleScreenshotUpload can delete it if incomplete
        await handleScreenshotUpload(channel, state, channelId, message.attachments.size, message);
      } else {
        await message.delete().catch(() => {});
        const req      = state.screenshotsRequired ?? 1;
        const received = state.screenshotsReceived ?? 0;
        const remaining = req - received;
        await sendTempWarning(
          channel,
          req <= MAX_ATTACHMENTS_PER_MESSAGE
            ? `⚠️ Please upload **all ${req} screenshot${req !== 1 ? 's' : ''}** as image attachments in a single message. Text messages are not allowed.`
            : `⚠️ Please upload **${remaining} more screenshot${remaining !== 1 ? 's' : ''}** (${received}/${req} received so far) as image attachments. Text messages are not allowed.`,
        );
      }
      return;
    }

    // All later phases — owner cannot send
    if (isOwner) await message.delete().catch(() => {});
    return;
  }

  // ── Standard locked tickets (giveaway / chat-rewards / chest-rewards) ──────
  if (
    state.ticketType === 'giveaway' ||
    state.ticketType === 'chat-rewards' ||
    state.ticketType === 'chest-rewards'
  ) {
    if (!isOwner) return;
    // Screenshot already received — staff used !unlock to continue the conversation,
    // so don't enforce screenshot-only mode anymore.
    if (state.screenshotSubmitted) return;

    if (message.attachments.size > 0) {
      state.screenshotSubmitted = true;
      await lockChannel(channel, state.ownerId);
      const reviewer = state.ticketType === 'giveaway' ? 'Giveaway Hoster' : 'Ticket Staff';
      await channel.send({
        embeds: [buildEmbed({
          title: '📸 Screenshot Received',
          description: [
            '✅ Your screenshot has been submitted.',
            '',
            `This ticket is now **locked** until a ${reviewer} reviews it.`,
            `A ${reviewer} will use \`!unlock\` to continue.`,
          ].join('\n'),
          color: COLORS.success,
          footer: 'Please wait patiently',
        })],
      });
      // Permanent staff ping
      await pingStaffOnScreenshot(channel, state.ownerId, state.robloxUsername, message.guild.id);
    } else {
      await message.delete().catch(() => {});
      await sendTempWarning(channel, '⚠️ Please upload an **image/screenshot** as proof. Text messages are not allowed.');
    }
    return;
  }

  // ── Yapper Rewards ─────────────────────────────────────────────────────────
  if (state.ticketType === 'yapper-rewards') {
    if (!isOwner) return;
    // Screenshot already received — allow free typing after !unlock.
    if (state.screenshotSubmitted) return;

    if (message.attachments.size > 0) {
      state.screenshotSubmitted = true;
      await lockChannel(channel, state.ownerId);
      await channel.send({
        embeds: [buildEmbed({
          title: '📸 Screenshot Received',
          description: [
            '✅ Your screenshot has been submitted.',
            '',
            'This ticket is now **locked** until Ticket Staff reviews it.',
          ].join('\n'),
          color: COLORS.success,
          footer: 'Please wait patiently',
        })],
      });
      await pingStaffOnScreenshot(channel, state.ownerId, state.robloxUsername, message.guild.id);
    } else {
      await message.delete().catch(() => {});
      await sendTempWarning(channel, '⚠️ Please upload an **image/screenshot** as proof. Text messages are not allowed.');
    }
    return;
  }

  // ── General Support & Restock: no restrictions ────────────────────────────
}
