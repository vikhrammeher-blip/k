import { randomUUID } from "crypto";

export interface AdminGuild {
  id: string;
  name: string;
}

export interface DashboardSession {
  userId: string;
  username: string;
  avatar: string | null;
  adminGuilds: AdminGuild[];
  expiresAt: number;
}

// Sessions live in memory only — they reset on redeploy/restart, same as
// ticketStates. That's fine here: worst case an admin logs in again.
const SESSION_TTL_MS = 12 * 60 * 60 * 1000; // 12 hours
const sessions = new Map<string, DashboardSession>();

export const SESSION_COOKIE = "gh_session";
export const SESSION_MAX_AGE_MS = SESSION_TTL_MS;

export function createSession(data: Omit<DashboardSession, "expiresAt">): string {
  const id = randomUUID();
  sessions.set(id, { ...data, expiresAt: Date.now() + SESSION_TTL_MS });
  return id;
}

export function getSession(id: string | undefined): DashboardSession | undefined {
  if (!id) return undefined;
  const session = sessions.get(id);
  if (!session) return undefined;
  if (session.expiresAt < Date.now()) {
    sessions.delete(id);
    return undefined;
  }
  return session;
}

export function destroySession(id: string | undefined): void {
  if (id) sessions.delete(id);
}

declare global {
  // eslint-disable-next-line @typescript-eslint/no-namespace
  namespace Express {
    interface Request {
      dashboardSession?: DashboardSession;
    }
  }
}
