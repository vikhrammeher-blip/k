import {
  type ButtonInteraction,
  type ModalSubmitInteraction,
  type StringSelectMenuInteraction,
  type TextChannel,
  type GuildMember,
  type Message,
  ActionRowBuilder,
  ModalBuilder,
  TextInputBuilder,
  TextInputStyle,
  StringSelectMenuBuilder,
  ButtonBuilder,
  ButtonStyle,
} from 'discord.js';
import { createTicketChannel, lockChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { ticketStates, type TicketState } from '../state.js';
import { getRewardsForGame, getReward } from '../data/rewards.js';
import { getGames, getGame } from '../data/inviteGames.js';
import { getGuildConfig } from '../config.js';
import { logger } from '../../lib/logger.js';

// ─── Screenshot upload rules ─────────────────────────────────────────────────

/** Discord's hard cap on attachments per message. */
export const MAX_ATTACHMENTS_PER_MESSAGE = 10;

/**
 * Builds the "please upload proof" instructions for a given required count.
 * 10 or fewer must arrive in a single message (Discord's own per-message cap
 * is 10, so there's no reason to split a small batch). More than 10 may be
 * split across multiple messages, up to 10 attachments each.
 */
export function buildScreenshotInstructions(count: number): string[] {
  if (count <= MAX_ATTACHMENTS_PER_MESSAGE) {
    return [
      `Please upload **all ${count} screenshot${count !== 1 ? 's' : ''}** as proof **in a single message**.`,
      count > 1
        ? `⚠️ You must attach **all ${count} screenshots at the same time** — do not send them one by one.`
        : '',
    ].filter(Boolean);
  }

  const messagesNeeded = Math.ceil(count / MAX_ATTACHMENTS_PER_MESSAGE);
  return [
    `Please upload **all ${count} screenshots** as proof.`,
    `⚠️ Discord only allows **${MAX_ATTACHMENTS_PER_MESSAGE} attachments per message**, so send them across **${messagesNeeded} messages** (up to ${MAX_ATTACHMENTS_PER_MESSAGE} screenshots each).`,
    `You'll see a running total after each message until all ${count} are received.`,
  ];
}

// ─── Falcon Bot response parsing ────────────────────────────────────────────

/**
 * Patterns to match invite count from Falcon Bot's response.
 * Ordered from most-specific to least-specific.
 * Each pattern captures the invite NUMBER, not unrelated large numbers.
 *
 * Falcon's typical embed format:
 *   Regular: 2
 *   Bonus: 0
 *   Fake: 0
 *   Left: 0
 *   Total: 2
 *
 * We specifically want "Regular" (real invites) or "Total" — NOT server
 * member counts, guild IDs, timestamps, or other large numbers in the embed.
 */
const INVITE_PATTERNS = [
  // "Regular: 2"  or  "Regular 2"  — most reliable field from Falcon
  /\bregular\s*:?\s*(\d{1,6})\b/i,
  // "Total: 2"  — second choice, but cap at 6 digits to avoid huge numbers
  /\btotal\s*invites?\s*:?\s*(\d{1,6})\b/i,
  /\btotal\s*:?\s*(\d{1,6})\b/i,
  // "You have 2 invites" — generic fallback, still capped at 6 digits
  /\b(\d{1,6})\s*(?:total\s*)?invites?\b/i,
  // "Invites: 2" — last resort
  /\binvites?\s*:?\s*(\d{1,6})\b/i,
];

export function parseFalconInviteCount(message: Message): number | null {
  // Collect all text from the message
  const texts: string[] = [message.content];

  for (const embed of message.embeds) {
    if (embed.description) texts.push(embed.description);
    for (const field of embed.fields) {
      texts.push(`${field.name}: ${field.value}`);
    }
    if (embed.footer?.text) texts.push(embed.footer.text);
    if (embed.title) texts.push(embed.title);
  }

  // Try each pattern on each text segment individually (not combined)
  // so a large number in one field can't bleed into another field's match.
  for (const pattern of INVITE_PATTERNS) {
    for (const text of texts) {
      const match = text.match(pattern);
      if (match?.[1] !== undefined) {
        const n = parseInt(match[1], 10);
        // Sanity-check: an invite count over 10,000 is almost certainly
        // a false positive (server member count, Discord snowflake, etc.)
        if (n <= 10_000) return n;
      }
    }
  }
  return null;
}

// ─── Reward + quantity helpers ───────────────────────────────────────────────

interface RewardOption {
  rewardId: string;
  rewardName: string;   // stripped of leading "N×"
  qty: number;
  inviteCost: number;
}

/** Base reward name without leading "N×" prefix */
function baseRewardName(name: string): string {
  return name.replace(/^\d+[×x]\s*/i, '').trim();
}

/** Slug used in channel name: lowercase, alphanumeric only */
function rewardSlug(rewardName: string): string {
  return baseRewardName(rewardName)
    .toLowerCase()
    .replace(/[^a-z0-9]/g, '');
}

/** Build all quantity variants for the select menus, scoped to one game. */
function buildRewardOptions(guildId: string, gameId: string, inviteCount: number): RewardOption[] {
  const options: RewardOption[] = [];
  for (const reward of getRewardsForGame(guildId, gameId)) {
    const maxQty = Math.min(Math.floor(inviteCount / reward.requiredInvites), 10);
    for (let qty = 1; qty <= maxQty; qty++) {
      options.push({
        rewardId:   reward.id,
        rewardName: reward.name,
        qty,
        inviteCost: qty * reward.requiredInvites,
      });
    }
  }
  return options;
}

/**
 * Discord select menus cap out at 25 options. Naively slicing the option
 * list cuts off whichever rewards happen to sort last, so cheap rewards
 * with many quantity variants (1x..10x) can crowd out entire reward types.
 *
 * Instead, round-robin by quantity tier across reward types: every reward
 * gets its 1x option before any reward gets a 2x option, and so on. This
 * guarantees every eligible reward type shows up at least once.
 */
function capOptionsFairly(options: RewardOption[], max = 25): RewardOption[] {
  const byReward = new Map<string, RewardOption[]>();
  for (const o of options) {
    if (!byReward.has(o.rewardId)) byReward.set(o.rewardId, []);
    byReward.get(o.rewardId)!.push(o);
  }
  const groups = [...byReward.values()];

  const result: RewardOption[] = [];
  let tier = 0;
  while (result.length < max) {
    let addedAny = false;
    for (const group of groups) {
      if (tier < group.length) {
        result.push(group[tier]!);
        addedAny = true;
        if (result.length >= max) break;
      }
    }
    if (!addedAny) break;
    tier++;
  }
  return result;
}

// ─── Ticket creation ─────────────────────────────────────────────────────────

export async function showInviteModal(interaction: ButtonInteraction): Promise<void> {
  const modal = new ModalBuilder()
    .setCustomId('roblox_modal_invite')
    .setTitle('Invite Rewards — Roblox Username');

  modal.addComponents(
    new ActionRowBuilder<TextInputBuilder>().addComponents(
      new TextInputBuilder()
        .setCustomId('roblox_username')
        .setLabel('What is your Roblox username?')
        .setStyle(TextInputStyle.Short)
        .setPlaceholder('e.g. CoolPlayer123')
        .setRequired(true)
        .setMaxLength(50),
    ),
  );

  await interaction.showModal(modal);
}

export async function handleInviteModalSubmit(
  interaction: ModalSubmitInteraction,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild  = interaction.guild!;
  const member = interaction.member as GuildMember;
  const robloxUsername = interaction.fields.getTextInputValue('roblox_username').trim();

  const guildConfig = getGuildConfig(guild.id);
  const staffRoleId = guildConfig.staffRoleId;

  if (!staffRoleId) {
    await interaction.editReply({
      content: '❌ This server hasn\'t been set up yet. Ask an admin to run `/setup staff-role`.',
    });
    return;
  }

  try {
    const channel = await createTicketChannel({
      guild,
      member,
      ticketType: 'invite-rewards',
      staffRoleId,
      categoryId: guildConfig.categories['invite-rewards'],
    });

    ticketStates.set(channel.id, {
      ticketType:    'invite-rewards',
      ownerId:       member.id,
      ownerUsername: member.user.username,
      createdAt:     new Date(),
      robloxUsername,
      invitePhase:   'awaiting_command',
    });

    await channel.send({
      embeds: [
        buildEmbed({
          title: '🎟️ Invite Rewards Ticket',
          description: [
            `Welcome, <@${member.id}>! 👋`,
            '',
            `**Roblox Username:** \`${robloxUsername}\``,
            '',
            'To check your invite count, please type **`.i`** in this channel.',
            'Falcon Bot will show your current invite count.',
            '',
            '> ⚠️ **Only `.i` is allowed right now.**',
            '> Any other messages will be automatically deleted.',
          ].join('\n'),
          color: COLORS.primary,
          footer: 'Bot will auto-detect your invite count from Falcon',
        }),
      ],
      components: [buildTicketControls(true)],
    });

    await interaction.editReply({ content: `✅ Ticket created: ${channel}` });
  } catch (err) {
    logger.error({ err }, 'Failed to create invite rewards ticket');
    await interaction.editReply({ content: '❌ Failed to create ticket. Please contact a staff member.' });
  }
}

// ─── Rename helpers ───────────────────────────────────────────────────────────

/**
 * Rename the channel once a reward has been selected.
 * We intentionally skip intermediate renames (invite-detected, screenshots-done)
 * because Discord allows only 2 channel renames per 10 minutes. Burning both
 * before the reward rename means the important one gets silently dropped.
 */
export async function renameToReward(
  channel: TextChannel,
  state: TicketState,
): Promise<void> {
  const safe = state.ownerUsername.toLowerCase().replace(/[^a-z0-9]/g, '').slice(0, 16) || 'user';
  const slug = rewardSlug(state.selectedReward ?? 'reward').slice(0, 22);
  const qty  = state.selectedQty ?? 1;
  // e.g. "reward-1x-starfruitseed-username"
  const name = `reward-${qty}x-${slug}-${safe}`.slice(0, 100);
  await channel.setName(name).catch((err) => {
    logger.warn({ err }, 'Failed to rename channel to reward name');
  });
}

// ─── Falcon response handler ─────────────────────────────────────────────────

/** Called when we detect a bot message while in awaiting_falcon_response phase */
export async function handleFalconResponse(
  message: Message,
  channel: TextChannel,
  state: TicketState,
  channelId: string,
): Promise<void> {
  // Cancel the Falcon wait timeout
  if (state.timeoutHandle) {
    clearTimeout(state.timeoutHandle);
    state.timeoutHandle = undefined;
  }

  const count = parseFalconInviteCount(message);

  if (count === null) {
    // Couldn't parse — do nothing, stay in awaiting_falcon_response
    return;
  }

  if (count === 0) {
    // Zero invites — close immediately
    await closeTicketForZeroInvites(channel, state, channelId);
    return;
  }

  // Store the count and move to screenshot collection.
  // Screenshots required = invite count (one proof screenshot per invite).
  state.autoDetectedInvites = count;
  state.screenshotsRequired = count;
  state.screenshotsReceived = 0;
  state.invitePhase         = 'awaiting_screenshots';
  // No intermediate rename here — we save Discord's 2-per-10-min rename
  // budget for the reward rename that happens after selection.

  await channel.send({
    embeds: [
      buildEmbed({
        title: '✅ Invite Count Detected',
        description: [
          `Falcon Bot confirmed: **${count} invite${count !== 1 ? 's' : ''}**.`,
          '',
          ...buildScreenshotInstructions(count),
          '',
          '> ⚠️ Only image attachments will be counted. Text messages will be deleted.',
        ].join('\n'),
        color: COLORS.success,
        footer:
          count <= MAX_ATTACHMENTS_PER_MESSAGE
            ? `Need all ${count} screenshot${count !== 1 ? 's' : ''} in one message`
            : `0/${count} screenshots received`,
      }),
    ],
  });
}

// ─── Screenshot collection ────────────────────────────────────────────────────

/**
 * Called when owner uploads screenshots during awaiting_screenshots phase.
 *
 * - 10 or fewer required: ALL screenshots must be sent in a single message
 *   (Discord itself caps attachments at 10 per message, so there's never a
 *   reason to split a small batch). Sending fewer than required deletes the
 *   message and asks the member to resend everything together.
 * - More than 10 required: screenshots may be spread across multiple
 *   messages (up to 10 attachments each). We keep a running tally on the
 *   ticket state and only move on once the total reaches the required count.
 */
export async function handleScreenshotUpload(
  channel: TextChannel,
  state: TicketState,
  _channelId: string,
  attachmentCount = 1,
  messageToDelete?: Message,
): Promise<void> {
  const required = state.screenshotsRequired ?? 1;
  const alreadyReceived = state.screenshotsReceived ?? 0;

  if (required <= MAX_ATTACHMENTS_PER_MESSAGE) {
    // ── Small batch — must all arrive in this one message ─────────────────
    if (attachmentCount < required) {
      // Delete the incomplete message so the count stays clean
      if (messageToDelete) {
        await messageToDelete.delete().catch(() => {});
      }

      await channel.send({
        embeds: [
          buildEmbed({
            title: '⚠️ Please Send All Screenshots at Once',
            description: [
              `You sent **${attachmentCount}** screenshot${attachmentCount !== 1 ? 's' : ''}, but **${required}** are required.`,
              '',
              `Please attach **all ${required} screenshot${required !== 1 ? 's' : ''}** in a **single message** and resend.`,
              'Do not split them across multiple messages.',
            ].join('\n'),
            color: COLORS.warning,
            footer: `All ${required} screenshots must be in one message`,
          }),
        ],
      });
      return;
    }

    state.screenshotsReceived = required;
  } else {
    // ── Large batch — accumulate across multiple messages ─────────────────
    const newTotal = Math.min(alreadyReceived + attachmentCount, required);
    state.screenshotsReceived = newTotal;

    if (newTotal < required) {
      const remaining = required - newTotal;
      await channel.send({
        embeds: [
          buildEmbed({
            title: '📸 Screenshots Received',
            description: [
              `Got **${attachmentCount}** screenshot${attachmentCount !== 1 ? 's' : ''}. Total so far: **${newTotal}/${required}**.`,
              '',
              `Please upload **${remaining} more screenshot${remaining !== 1 ? 's' : ''}** (up to ${MAX_ATTACHMENTS_PER_MESSAGE} per message) to finish.`,
            ].join('\n'),
            color: COLORS.neutral,
            footer: `${newTotal}/${required} screenshots received`,
          }),
        ],
      });
      return; // stay in awaiting_screenshots — wait for the rest
    }
  }

  // ── All screenshots received ────────────────────────────────────────────
  state.invitePhase = 'awaiting_game_choice';

  const inviteCount = state.autoDetectedInvites ?? required;

  await sendGameChoiceMenu(channel, state, inviteCount);
}

// ─── Game choice ──────────────────────────────────────────────────────────────

async function sendGameChoiceMenu(
  channel: TextChannel,
  state: TicketState,
  inviteCount: number,
): Promise<void> {
  // Every game — Grow a Garden, Pet Simulator 99, Robux, and anything custom
  // — is a regular dashboard-managed entry now. Nothing about this menu is
  // hardcoded; it's built entirely from data/inviteGames.ts.
  const games = getGames(channel.guildId);

  const buttons = games.map((game, i) =>
    new ButtonBuilder()
      .setCustomId(`choose_game_custom_${game.id}`)
      .setLabel(game.label)
      .setEmoji(game.emoji || '🎮')
      .setStyle(i === 0 ? ButtonStyle.Primary : ButtonStyle.Success),
  );

  // Discord caps action rows at 5 buttons each and messages at 5 rows —
  // chunk into rows (25 games max, which is far more than any server needs).
  const rows: ActionRowBuilder<ButtonBuilder>[] = [];
  for (let i = 0; i < buttons.length; i += 5) {
    rows.push(new ActionRowBuilder<ButtonBuilder>().addComponents(buttons.slice(i, i + 5)));
  }

  await channel.send({
    embeds: [
      buildEmbed({
        title: '🎮 Choose Your Game',
        description: [
          `All **${inviteCount} screenshot${inviteCount !== 1 ? 's' : ''}** verified! You have **${inviteCount} invite${inviteCount !== 1 ? 's' : ''}**.`,
          '',
          'Which game would you like rewards for?',
          '',
          ...games.map((g) => `${g.emoji || '🎮'} **${g.label}**`),
        ].join('\n'),
        color: COLORS.success,
        footer: 'Select your game to see available rewards',
      }),
    ],
    components: rows,
  });
}

export async function handleGameChoice(
  interaction: ButtonInteraction,
  game: string,
): Promise<void> {
  const state = ticketStates.get(interaction.channelId);
  if (!state || state.ticketType !== 'invite-rewards') return;

  if (interaction.user.id !== state.ownerId) {
    await interaction.reply({ content: '❌ Only the ticket owner can choose a game.', ephemeral: true });
    return;
  }
  if (state.invitePhase !== 'awaiting_game_choice') {
    await interaction.reply({ content: '❌ Game selection is not available right now.', ephemeral: true });
    return;
  }

  const guildId  = interaction.guildId!;
  const gameInfo = getGame(guildId, game);
  if (!gameInfo) {
    await interaction.reply({ content: '❌ That game no longer exists.', ephemeral: true });
    return;
  }

  const inviteCount = state.autoDetectedInvites ?? state.screenshotsRequired ?? 1;

  state.gameChoice  = game;
  state.invitePhase = 'awaiting_reward';

  await interaction.update({
    embeds: [
      buildEmbed({
        title: `${gameInfo.emoji || '🎮'} ${gameInfo.label} Selected`,
        description: `You chose **${gameInfo.label}**! Please select your reward below.`,
        color: COLORS.primary,
      }),
    ],
    components: [],
  });

  const channel = interaction.channel as TextChannel;
  await sendCatalogRewardMenu(channel, state, inviteCount, game, gameInfo.label);
}

// ─── Dynamic catalog reward menu (every game — Grow a Garden, Pet Sim 99, Robux, custom) ────────────

/** Small deterministic emoji rotation so category selects still look distinct without hardcoding labels. */
const CATEGORY_EMOJIS = ['⚙️', '🐶', '🌱', '💎', '🎁', '🧪', '🏆', '✨'];

function categorySlug(category: string): string {
  return category.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'misc';
}

async function sendCatalogRewardMenu(
  channel: TextChannel,
  state: TicketState,
  inviteCount: number,
  gameId: string,
  gameName: string,
): Promise<void> {
  const allOptions = buildRewardOptions(channel.guildId, gameId, inviteCount);

  // Group dynamically by whatever category label each reward was given —
  // no fixed gear/pets/seeds list any more, so a server can use any
  // categories it wants (or none at all, if every reward is uncategorized).
  const byCategory = new Map<string, RewardOption[]>();
  for (const option of allOptions) {
    const category = getReward(channel.guildId, option.rewardId)?.category ?? 'General';
    if (!byCategory.has(category)) byCategory.set(category, []);
    byCategory.get(category)!.push(option);
  }

  const categories = [...byCategory.entries()];
  const selects: StringSelectMenuBuilder[] = categories.map(([category, options], i) => {
    const emoji = CATEGORY_EMOJIS[i % CATEGORY_EMOJIS.length];
    return new StringSelectMenuBuilder()
      .setCustomId(`reward_select_${gameId}__${categorySlug(category)}`)
      .setPlaceholder(`${emoji} ${category} — Pick a reward`)
      .addOptions(capOptionsFairly(options).map((o) => ({
        label:       `${o.qty}× ${baseRewardName(o.rewardName)}`,
        value:       `${o.rewardId}:${o.qty}`,
        description: `${o.inviteCost} invite${o.inviteCost !== 1 ? 's' : ''}`,
        emoji,
      })));
  });

  if (selects.length === 0) {
    await channel.send({
      embeds: [buildEmbed({ description: '❌ No rewards available for your invite count.', color: COLORS.danger })],
    });
    return;
  }

  // Discord caps messages at 5 action rows — if a server has configured more
  // than 5 categories for one game, split across multiple messages rather
  // than silently dropping any.
  const introText = [
    `<@${state.ownerId}> — all screenshots verified! You have **${inviteCount} invite${inviteCount !== 1 ? 's' : ''}**.`,
    '',
    '**Select your reward below.** Each option shows how many invites it costs.',
    'You can pick a quantity option if you have enough invites.',
  ].join('\n');

  for (let i = 0; i < selects.length; i += 5) {
    const rows = selects
      .slice(i, i + 5)
      .map((s) => new ActionRowBuilder<StringSelectMenuBuilder>().addComponents(s));

    await channel.send({
      embeds: i === 0
        ? [buildEmbed({
            title: '🎁 Choose Your Reward',
            description: introText,
            color: COLORS.success,
            footer: `${gameName} · ${inviteCount} invite${inviteCount !== 1 ? 's' : ''} available`,
          })]
        : [],
      components: rows,
    });
  }
}

// ─── Reward selection handler ─────────────────────────────────────────────────

export async function handleRewardSelect(
  interaction: StringSelectMenuInteraction,
): Promise<void> {
  const state = ticketStates.get(interaction.channelId);
  if (!state || state.ticketType !== 'invite-rewards') return;

  if (interaction.user.id !== state.ownerId) {
    await interaction.reply({ content: '❌ Only the ticket owner can select a reward.', ephemeral: true });
    return;
  }

  // value format: "rewardId:qty"
  const [rewardId, qtyStr] = (interaction.values[0] ?? ':').split(':');
  const qty    = parseInt(qtyStr ?? '1', 10);
  const reward = getReward(interaction.guildId!, rewardId!);
  if (!reward) return;

  state.invitePhase    = 'reward_selected';
  state.selectedReward = reward.name;
  state.selectedQty    = qty;

  const displayName = `${qty}× ${baseRewardName(reward.name)}`;

  await interaction.update({
    embeds: [
      buildEmbed({
        title: '🎁 Reward Selected!',
        description: [
          `<@${state.ownerId}> has selected: **${displayName}**`,
          '',
          `Roblox Username: \`${state.robloxUsername ?? 'Not provided'}\``,
          '',
          '✅ Your reward request has been submitted.',
          'This channel is now **locked** pending staff delivery.',
          '',
          'A Ticket Staff member will deliver your reward shortly.',
        ].join('\n'),
        color: COLORS.success,
        footer: 'Thank you for your patience!',
      }),
    ],
    components: [],
  });

  const channel = interaction.channel as TextChannel;

  // Ping staff now that the reward is finalised
  await channel.send(
    `<@&${getGuildConfig(interaction.guildId!).staffRoleId}>\n\n` +
    `**Reward selected — ready for delivery.**\n\n` +
    `Discord User: <@${state.ownerId}>\n` +
    `Roblox Username: \`${state.robloxUsername ?? 'Not provided'}\`\n` +
    `Game: **Grow a Garden**\n` +
    `Reward: **${displayName}**`,
  );

  // Rename THEN lock — rename uses rate-limited Discord API, do it first
  // so if it's briefly rate-limited we still rename before locking.
  await renameToReward(channel, state);
  await lockChannel(channel, state.ownerId);
}

// ─── Zero invites / expiry ────────────────────────────────────────────────────

export async function closeTicketForZeroInvites(
  channel: TextChannel,
  state: TicketState,
  channelId: string,
): Promise<void> {
  ticketStates.delete(channelId);
  if (state.timeoutHandle) {
    clearTimeout(state.timeoutHandle);
    state.timeoutHandle = undefined;
  }

  await channel.send({
    embeds: [
      buildEmbed({
        title: '❌ Ticket Closed — 0 Verified Invites',
        description: [
          `<@${state.ownerId}> — Falcon Bot detected **0 invites**.`,
          '',
          'You do not qualify for Invite Rewards at this time.',
          'Please invite members and try again when you have at least 1 verified invite.',
          '',
          'This ticket will be deleted in **5 seconds**.',
        ].join('\n'),
        color: COLORS.danger,
        footer: 'Ticket auto-closed: 0 invites',
      }),
    ],
  });

  setTimeout(() => channel.delete('0 invites detected').catch(() => {}), 5_000);
}

export function startFalconWaitTimeout(
  channelId: string,
  channel: TextChannel,
  ownerId: string,
): ReturnType<typeof setTimeout> {
  return setTimeout(async () => {
    const state = ticketStates.get(channelId);
    if (!state || state.invitePhase !== 'awaiting_falcon_response') return;
    // Reset to awaiting_command so they can try again
    state.invitePhase = 'awaiting_command';
    await channel.send({
      embeds: [
        buildEmbed({
          description: [
            `⏰ <@${ownerId}>, Falcon Bot didn't respond in time.`,
            '',
            'Please type **`.i`** again to retry.',
          ].join('\n'),
          color: COLORS.warning,
        }),
      ],
    });
  }, 60_000);
}
