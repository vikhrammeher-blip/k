import { type ButtonInteraction, type GuildMember } from 'discord.js';
import { createTicketChannel } from '../utils/channel.js';
import { buildEmbed, buildTicketControls, COLORS } from '../utils/embeds.js';
import { ticketStates } from '../state.js';
import { getGuildConfig } from '../config.js';
import { logger } from '../../lib/logger.js';

type RestockSubtype = 'gear' | 'pets' | 'seeds' | 'all' | 'ps99';

const LABELS: Record<RestockSubtype, string> = {
  gear:  '⚙️ Gear Stock',
  pets:  '🐶 Pet Stock',
  seeds: '🌱 Seed Stock',
  all:   '📦 All GAG Stock',
  ps99:  '🎮 PS99 Stock',
};

export async function openRestockTicket(
  interaction: ButtonInteraction,
  subtype: RestockSubtype,
): Promise<void> {
  await interaction.deferReply({ ephemeral: true });
  const guild  = interaction.guild!;
  const member = interaction.member as GuildMember;
  const label  = LABELS[subtype];

  const guildConfig  = getGuildConfig(guild.id);
  const staffRoleId  = guildConfig.staffRoleId;
  const pingRoleId   = guildConfig.restockPingRoleId;
  const categoryId   = guildConfig.categories['restock'];

  if (!staffRoleId) {
    await interaction.editReply({
      content: '❌ This server hasn\'t been set up yet. Ask an admin to run `/setup staff-role`.',
    });
    return;
  }

  try {
    const channel = await createTicketChannel({
      guild,
      member,
      ticketType: 'restock',
      staffRoleId,
      categoryId,
    });

    ticketStates.set(channel.id, {
      ticketType:     'restock',
      ownerId:        member.id,
      ownerUsername:  member.user.username,
      createdAt:      new Date(),
      restockSubtype: subtype,
    });

    // Permanent ping — not deleted (falls back to Ticket Staff if no dedicated role is set)
    await channel.send(`<@&${pingRoleId ?? staffRoleId}>`);

    await channel.send({
      embeds: [
        buildEmbed({
          title: `🏪 Restock Request — ${label}`,
          description: [
            `**Requested by:** <@${member.id}>`,
            `**Category:** ${label}`,
            '',
            subtype === 'ps99'
              ? 'Please describe the **Pet Simulator 99** items you need restocked (pets, gems, etc.) so they can be used to fulfil PS99 Invite Reward claims.'
              : 'Please describe the specific items you need restocked so they can be used to fulfil Invite Reward claims.',
            '',
            'Include quantities and priority level if known.',
          ].join('\n'),
          color: COLORS.warning,
          footer: 'Restock handlers have been notified',
        }),
      ],
      components: [buildTicketControls(true)],
    });

    await interaction.editReply({ content: `✅ Restock ticket created: ${channel}` });
  } catch (err) {
    logger.error({ err }, `Failed to create restock ticket (${subtype})`);
    await interaction.editReply({
      content: '❌ Failed to create ticket. Please contact a staff member.',
    });
  }
}
